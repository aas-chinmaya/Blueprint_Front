// const mongoose = require("mongoose");

// const meetingSchema = new mongoose.Schema(
//   {
//     meetingId: {
//       type: String,
//       unique: true,
//       trim: true,
//     },
//     title: {
//       type: String,
//       required: true,
//       trim: true,
//     },
//     agenda: {
//       type: String,
//       trim: true,
//     },
//     date: {
//       type: Date,
//       required: true,
//     },
//     startTime: {
//       type: Date,
//       required: true,
//     },
//     endTime: {
//       type: Date,
//       required: true,
//     },
//     duration: {
//       type: Number, // in minutes
//     },
//     mode: {
//       type: String,
//       enum: ["online", "offline"],
//       required: true,
//     },
//     meetingLink: {
//       type: String,
//       trim: true,
//       validate: {
//         validator: function (value) {
//           if (this.mode === "online") {
//             return !!value;
//           }
//           return true;
//         },
//         message: "Meeting link is required for online meetings.",
//       },
//     },
//     endNote: {
//       type: String,
//       trim: true,
//     },
//     contactId: {
//       type: String,
//       ref: "Contact",
//     },
//     momId: {
//       type:String,
//       ref: "MOM",
//     },
//     quotationId: {
//       type: String,
//       ref: "Quotation",
//     },
//     events: [
//       {
//         actionType: {
//           type: String, // created, extended, rescheduled, ended
//           required: true,
//         },
//         note: String,
//         previousStartTime: Date,
//         previousEndTime: Date,
//         newStartTime: Date,
//         newEndTime: Date,
//         performedBy: {
//           type: mongoose.Schema.Types.ObjectId,
//           ref: "User",
//         },
//         timestamp: {
//           type: Date,
//           default: Date.now,
//         },
//       },
//     ],
//   },
//   { timestamps: true }
// );

// // Auto-calculate duration
// meetingSchema.pre("save", function (next) {
//   if (this.startTime && this.endTime) {
//     this.duration = Math.round((this.endTime - this.startTime) / (1000 * 60));
//   }
//   next();
// });

// // Auto-generate Meeting ID
// meetingSchema.pre("save", async function (next) {
//   if (this.meetingId) return next();

//   const lastMeeting = await mongoose.models.Meet.findOne({})
//     .sort({ createdAt: -1 })
//     .select("meetingId");

//   let nextNumber = 1;
//   if (lastMeeting && lastMeeting.meetingId) {
//     const match = lastMeeting.meetingId.match(/\d+$/);
//     if (match) nextNumber = parseInt(match[0]) + 1;
//   }

//   this.meetingId = `meetingid${nextNumber}`;
//   next();
// });

// module.exports = mongoose.model("Meet", meetingSchema);

const mongoose = require("mongoose");

const meetingSchema = new mongoose.Schema(
  {
    meetingId: {
      type: String,
      unique: true,
      trim: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    agenda: {
      type: String,
      trim: true,
    },
    date: {
      type: Date,
      required: true,
    },
    startTime: {
      type: Date,
      required: true,
    },
    endTime: {
      type: Date,
      required: true,
    },
    duration: {
      type: Number, // in minutes
    },
    mode: {
      type: String,
      enum: ["online", "offline"],
      required: true,
    },
    meetingLink: {
      type: String,
      trim: true,
      validate: {
        validator: function (value) {
          if (this.mode === "online") {
            return !!value;
          }
          return true;
        },
        message: "Meeting link is required for online meetings.",
      },
    },
    endNote: {
      type: String,
      trim: true,
    },

    // Plain text fields instead of ObjectIds
    contactId: { type: String, trim: true },
    momId: { type: String, trim: true },
    quotationId: { type: String, trim: true },

    events: [
      {
        actionType: {
          type: String, // created, extended, rescheduled, ended
          required: true,
        },
        note: String,
        previousStartTime: Date,
        previousEndTime: Date,
        newStartTime: Date,
        newEndTime: Date,
        performedBy: { type: String, trim: true }, // no ObjectId
        timestamp: {
          type: Date,
          default: Date.now,
        },
      },
    ],
  },
  { timestamps: true }
);

// Auto-calculate duration
meetingSchema.pre("save", function (next) {
  if (this.startTime && this.endTime) {
    this.duration = Math.round((this.endTime - this.startTime) / (1000 * 60));
  }
  next();
});

// Auto-generate Meeting ID
meetingSchema.pre("save", async function (next) {
  if (this.meetingId) return next();

  const lastMeeting = await mongoose.models.Meet.findOne({})
    .sort({ createdAt: -1 })
    .select("meetingId");

  let nextNumber = 1;
  if (lastMeeting && lastMeeting.meetingId) {
    const match = lastMeeting.meetingId.match(/\d+$/);
    if (match) nextNumber = parseInt(match[0]) + 1;
  }

  this.meetingId = `meetingid${nextNumber}`;
  next();
});

module.exports = mongoose.model("Meet", meetingSchema);
