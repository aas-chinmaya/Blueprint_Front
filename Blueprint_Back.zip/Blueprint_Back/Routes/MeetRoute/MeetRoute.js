const express = require("express");
const router = express.Router();
const meetingController = require("../../Controller/MeetController/MeetController");

// Create a new meeting
router.post("/create", meetingController.createMeeting);

// Get all meetings
router.get("/all", meetingController.getAllMeetings);

// Get meeting by meetingId
router.get("/getMeetByMeetId/:meetingId", meetingController.getMeetingById);

// Update meeting
router.put("/update/:meetingId", meetingController.updateMeeting);

// Delete meeting
router.delete("/delete/:meetingId", meetingController.deleteMeeting);

router.get("/contact/:contactId", meetingController.getMeetingsByContactId);

router.patch("/updatestatus/:meetingId", meetingController.updateMeetingStatus);
module.exports = router;
