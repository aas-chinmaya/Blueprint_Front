// const nodemailer = require("nodemailer");
// const bcrypt = require("bcryptjs");
// const crypto = require("crypto");
// // Configure Gmail transporter
// const transporter = nodemailer.createTransport({
//   service: "gmail",
//   auth: {
//     user: "arunak47.b@gmail.com",
//     pass: "dhppstzoissvxshp", // ensure no spaces
//   },
// });

// /**
//  * Send Email using Gmail via Nodemailer
//  * @param {string} Subject - Email subject
//  * @param {string} Body - HTML body content
//  * @param {string|string[]} ToRecipient - Recipient(s)
//  * @param {string|string[]} [CcRecipients=[]] - Optional CC recipient(s)
//  */
// exports.sendEmail = async (Subject, Body, ToRecipient, CcRecipients = []) => {
//   console.log("gfwrgwrgwr");
  
//   try {
//     // Handle single or multiple recipients
//     const toRecipients = Array.isArray(ToRecipient) ? ToRecipient : [ToRecipient];
//     const ccRecipients = Array.isArray(CcRecipients) ? CcRecipients : [CcRecipients];

//     const mailOptions = {
//       from: `"AAS Technology" <arunak47.b@gmail.com>`,
//       to: toRecipients.join(", "),
//       cc: ccRecipients.length > 0 ? ccRecipients.join(", ") : undefined,
//       subject: Subject,
//       html: Body,
//     };

//     const info = await transporter.sendMail(mailOptions);
//     console.log("Email sent successfully:", info.response);
//   } catch (error) {
//     console.error("Error sending email:", error);
//   }
// };





// const nodemailer = require("nodemailer");

// // ✅ Create transporter with Gmail SMTP (modern config)
// const transporter = nodemailer.createTransport({
//   host: "smtp.gmail.com",
//   port: 465,
//   secure: true, // true for 465, false for 587
//   auth: {
//     user: "arunak47.b@gmail.com",
//     pass: "dhppstzoissvxshp", // App password (not your real Gmail password)
//   },
//   tls: {
//     rejectUnauthorized: false, // helps avoid SSL handshake errors
//   },
// });

// /**
//  * Send Email using Gmail SMTP
//  */
// async function sendEmail(subject, htmlBody, toRecipient) {
//   try {
//     const mailOptions = {
//       from: '"AAS Technology" <arunak47.b@gmail.com>',
//       to: toRecipient,
//       subject,
//       html: htmlBody,
//     };

//     const info = await transporter.sendMail(mailOptions);
//     console.log("✅ Email sent successfully:", info.response);
//     return true;
//   } catch (error) {
//     console.error("❌ Failed to send email:", error.message);
//     return false;
//   }
// }

// module.exports = { sendEmail };


















// const nodemailer = require("nodemailer");

// // Set up the Nodemailer transport using environment variables
// const transporter = nodemailer.createTransport({
//   // host: process.env.MAIL_HOST,
//   // port: process.env.MAIL_PORT,
//   service: "gmail",
//   auth: {
//     user: 'arunak47.b@gmail.com',
//     pass: 'dhppstzo issv xshp',
//   },
// });

// module.exports = transporter;


// const { Client } = require('@microsoft/microsoft-graph-client');
// const { ClientSecretCredential } = require('@azure/identity');
// const { isArray } = require('util');
// require('isomorphic-fetch');
 
// // Your app's credentials
// const tenantId = '296a8ad9-383e-4412-9bcd-0f4f86e00a8c';
// const clientId = 'a25bbd8f-9e41-4631-99b6-b38a2245805f';
// const clientSecret = 'zkr8Q~_hKrg83CzYsGKTo9H.YIVhCRQRjr5TVaim';
// const senderEmail = 'no-reply@aas.technology'; // Must be licensed mailbox
 
// // Authenticate
// const credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
 
// const graphClient = Client.initWithMiddleware({
//   authProvider: {
//     getAccessToken: async () => {
//       const token = await credential.getToken('https://graph.microsoft.com/.default');
//       return token.token;
//     },
//   },
// });
 
 
// exports.sendEmail = async (Subject, Body, ToRecipient, CcRecipients = []) => {
//   let ToRecipients
//   if(Array.isArray(ToRecipient)){
//      ToRecipients=ToRecipient
//   }else{
//     ToRecipients=[ToRecipient]
//   }
//   const message = {
//     subject: Subject,
//     body: {
//       contentType: 'HTML',
//       content: Body,
//     },
//     toRecipients: ToRecipients.map(email => ({
//       emailAddress: { address: email }
//     })),
   
//   };
 
//   if (CcRecipients.length > 0) {
//     message.ccRecipients = CcRecipients.map(email => ({
//       emailAddress: { address: email }
//     }));
//   }
 
//   const mail = {
//     message,
//     saveToSentItems: 'true',
//   };
 
//   try {
//     await graphClient.api(`/users/${senderEmail}/sendMail`).post(mail);
//     console.log('Email sent successfully');
//   } catch (error) {
//     console.error('Error sending email:', error);
//   }
// };
 

const { Client } = require('@microsoft/microsoft-graph-client');
const { ClientSecretCredential } = require('@azure/identity');
const { isArray } = require('util');
require('isomorphic-fetch');
 
// Your app's credentials
const tenantId = '296a8ad9-383e-4412-9bcd-0f4f86e00a8c';
const clientId = 'a25bbd8f-9e41-4631-99b6-b38a2245805f';
const clientSecret = 'ONq8Q~XjNhSp.jUyVyklsgv0iDop83q11iLotb6Y';
const senderEmail = 'no-reply@aas.technology'; // Must be licensed mailbox
 
// Authenticate
const credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
 
const graphClient = Client.initWithMiddleware({
  authProvider: {
    getAccessToken: async () => {
      const token = await credential.getToken('https://graph.microsoft.com/.default');
      return token.token;
    },
  },
});
 
 
exports.sendEmail = async (Subject, Body, ToRecipient, CcRecipients = []) => {
  let ToRecipients
  if(Array.isArray(ToRecipient)){
     ToRecipients=ToRecipient
  }else{
    ToRecipients=[ToRecipient]
  }
  const message = {
    subject: Subject,
    body: {
      contentType: 'HTML',
      content: Body,
    },
    toRecipients: ToRecipients.map(email => ({
      emailAddress: { address: email }
    })),
   
  };
 
  if (CcRecipients.length > 0) {
    message.ccRecipients = CcRecipients.map(email => ({
      emailAddress: { address: email }
    }));
  }
 
  const mail = {
    message,
    saveToSentItems: 'true',
  };
 
  try {
    await graphClient.api(`/users/${senderEmail}/sendMail`).post(mail);
    console.log('Email sent successfully');
  } catch (error) {
    console.error('Error sending email:', error);
  }
};