// const Task = require('../../Model/TaskModel/Task');
// const Bug = require('../../Model/BugModel/Bug');
// const Notification = require('../../Model/NotificationModel/notificationModel');
// const Team=require('../../Model/TeamModel/Team')
 
 
// exports.assignTask = async (req, res) => {
//   try {
//     const {
//       title,
//       description,
//       assignedTo,
//       assignedBy,
//       priority,
//       deadline,
//       projectId,
//       projectName,
//       memberId
//     } = req.body;
 
//     if (!title || !assignedTo || !assignedBy || !projectId) {
//       return res.status(400).json({
//         message: 'Title, assignedTo, assignedBy, and projectId are required.'
//       });
//     }
 
//     // Create the task with a custom ID generator
//     const task = await Task.createTaskWithId({
//       title,
//       description,
//       assignedTo,
//       assignedBy,
//       priority,
//       deadline,
//       projectId,
//       projectName,
//       memberId
//     });
 
//     // Create a notification for the assignee
//     const notification = new Notification({
//       recipientId: assignedTo.toString(),
//       message: `You have been assigned a new task: "${title}" in project "${projectName}".`,
//       link: `/tasks/${task.task_id}` // Adjust path format if necessary
//     });
 
//     await notification.save();
 
//     res.status(201).json({
//       message: 'Task assigned successfully',
//       task
//     });
//   } catch (err) {
//     res.status(500).json({
//       message: 'Internal server error',
//       error: err.message
//     });
//   }
// };
 
 
// exports.getAllTasks = async (req, res) => {
//   try {
//     const todayStart = new Date();
//     todayStart.setHours(0, 0, 0, 0);
 
//     const todayEnd = new Date();
//     todayEnd.setHours(23, 59, 59, 999);
 
//     // Fetch all tasks (not just today’s)
//     const tasks = await Task.find({ isDeleted: false }).sort({ createdAt: -1 }).lean();
 
//     // Count tasks with today's deadline
//     const todayDeadlineTasksCount = tasks.filter(task =>
//       task.deadline &&
//       new Date(task.deadline) >= todayStart &&
//       new Date(task.deadline) <= todayEnd
//     ).length;
 
//     // Get all teams and build a memberId -> memberName map
//     const teams = await Team.find({ isDeleted: false }).lean();
//     const memberMap = {};
//     for (const team of teams) {
//       for (const member of team.teamMembers) {
//         memberMap[member.memberId] = member.memberName;
//       }
//     }
 
//     // Add assignedToName to each task
//     const tasksWithMemberNames = tasks.map(task => ({
//       ...task,
//       assignedToName: memberMap[task.assignedTo] || 'Unknown'
//     }));
 
//     res.status(200).json({
//       totalTasks: tasks.length,
//       todayDeadlineTasks: todayDeadlineTasksCount,
//       tasks: tasksWithMemberNames
//     });
 
//   } catch (err) {
//     console.error('Error fetching tasks:', err);
//     res.status(500).json({ message: 'Failed to fetch tasks', error: err.message });
//   }
// };
//  // Get all tasks for a specific memberId
// // exports.getTasksByMemberId = async (req, res) => {
// //   const { memberId } = req.params;
 
// //   try {
// //     if (!memberId) {
// //       return res.status(400).json({ message: "memberId is required" });
// //     }
 
// //     const tasks = await Task.find({ 
// //       memberId, 
// //       isDeleted: false 
// //     }).populate('bugIds'); // Optional: populate bugs if needed
 
// //     if (!tasks.length) {
// //       return res.status(404).json({ message: "No tasks found for this member" });
// //     }
 
// //     res.status(200).json({ success: true, data: tasks });
 
// //   } catch (error) {
// //     console.error("Error fetching tasks by memberId:", error);
// //     res.status(500).json({ success: false, message: "Server Error", error: error.message });
// //   }
// // };
// exports.getTasksByMemberId = async (req, res) => {
//   const { memberId } = req.params;

//   try {
//     if (!memberId) {
//       return res.status(400).json({ message: "memberId is required" });
//     }

//     // Step 1: Fetch tasks where assignedTo = memberId
//     const tasks = await Task.find({
//       assignedTo: memberId,
//       isDeleted: false
//     }).populate('bugIds').lean(); // lean returns plain JS objects

//     if (!tasks.length) {
//       return res.status(404).json({ message: "No tasks found for this member" });
//     }

//     // Step 2: Fetch all teams
//     const teams = await Team.find({ isDeleted: false }).lean();

//     // Step 3: Build memberId -> { name, role, email } map
//     const memberMap = {};
//     teams.forEach(team => {
//       team.teamMembers.forEach(member => {
//         memberMap[member.memberId] = {
//           name: member.memberName,
//           role: member.role,
//           email: member.email
//         };
//       });
//     });

//     // Step 4: Enrich each task with assignedToName, assignedToRole, assignedToEmail
//     const enrichedTasks = tasks.map(task => {
//       const memberInfo = memberMap[task.assignedTo] || {};
//       return {
//         ...task,
//         assignedToName: memberInfo.name || 'Unknown',
//         assignedToRole: memberInfo.role || 'Unknown',
//         assignedToEmail: memberInfo.email || 'Unknown'
//       };
//     });

//     // Step 5: Send response
//     res.status(200).json({
//       success: true,
//       data: enrichedTasks
//     });

//   } catch (error) {
//     console.error("Error fetching tasks by memberId:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server Error",
//       error: error.message
//     });
//   }
// };








// // Get Single Task by task_id
// // exports.getTaskById = async (req, res) => {
// //   try {
// //     const task = await Task.findOne({ task_id: req.params.task_id });
 
// //     if (!task) {
// //       return res.status(404).json({ message: 'Task not found' });
// //     }
 
// //     res.status(200).json({ task });
 
// //   } catch (err) {
// //     res.status(500).json({ message: 'Failed to get task', error: err.message });
// //   }
// // };
 
// exports.getTaskById = async (req, res) => {

//   try {

//     const task = await Task.findOne({ task_id: req.params.task_id });
 
//     if (!task) {

//       return res.status(404).json({ message: 'Task not found' });

//     }
 
//     // Fetch teams for the project

//     const teams = await Team.find({ projectId: task.projectId, isDeleted: false });

//     const allMembers = teams.flatMap(team => team.teamMembers);

//     const allTeamLeads = teams.map(team => ({

//       memberId: team.teamLeadId,

//       memberName: team.teamLeadName,

//       role: 'Team Lead',

//       email: '', // Optional: Store teamLeadEmail in your Team schema if available

//       _id: null

//     }));
 
//     const everyone = [...allMembers, ...allTeamLeads];
 
//     // Find assignedTo member

//     const assignedToMember = everyone.find(member => member.memberId === task.assignedTo);
 
//     // Find assignedBy member (match by name or ID)

//     const assignedByMember = everyone.find(

//       member => member.memberId === task.assignedBy || member.memberName === task.assignedBy

//     );
 
//     const enrichedTask = {

//       ...task.toObject(),

//       assignedToDetails: assignedToMember

//         ? {

//             _id: assignedToMember._id,

//             memberId: assignedToMember.memberId,

//             memberName: assignedToMember.memberName,

//             email: assignedToMember.email,

//             role: assignedToMember.role

//           }

//         : null,

//       assignedByDetails: assignedByMember

//         ? {

//             _id: assignedByMember._id,

//             memberId: assignedByMember.memberId,

//             memberName: assignedByMember.memberName,

//             email: assignedByMember.email,

//             role: assignedByMember.role

//           }

//         : null

//     };
 
//     res.status(200).json({ task: enrichedTask });
 
//   } catch (err) {

//     console.error('Error in getTaskById:', err);

//     res.status(500).json({ message: 'Failed to get task', error: err.message });

//   }

// };
 
//  exports.updateTask = async (req, res) => {

//   try {

//     const taskId = req.params.task_id;

//     // Find the existing task first

//     const existingTask = await Task.findOne({ task_id: taskId });

//     if (!existingTask) {

//       return res.status(404).json({ message: 'Task not found' });

//     }
 
//     // Update the task

//     const updatedTask = await Task.findOneAndUpdate(

//       { task_id: taskId },

//       req.body,

//       { new: true }

//     );
 
//     // Create a notification message based on what was updated

//     let message = `Task "${updatedTask.title}" has been updated.`;

//     // Check if reassigned

//     if (req.body.assignedTo && req.body.assignedTo !== existingTask.assignedTo.toString()) {

//       message = `You have been assigned a new task: "${updatedTask.title}".`;

//       const reassignedNotification = new Notification({

//         recipientId: req.body.assignedTo.toString(),

//         message,

//         link: `/tasks/${updatedTask.task_id}`

//       });

//       await reassignedNotification.save();

//     } else {

//       // Generic update notification for the current assignee

//       const updateNotification = new Notification({

//         recipientId: updatedTask.assignedTo.toString(),

//         message,

//         link: `/tasks/${updatedTask.task_id}`

//       });

//       await updateNotification.save();

//     }
 
//     res.status(200).json({

//       message: 'Task updated successfully',

//       task: updatedTask

//     });
 
//   } catch (err) {

//     res.status(500).json({

//       message: 'Failed to update task',

//       error: err.message

//     });

//   }

// };
 
// // Delete Task permanenly
// exports.deleteTaskPermanent= async (req, res) => {
//   try {
//     const deletedTask = await Task.findOneAndDelete({ task_id: req.params.task_id });
 
//     if (!deletedTask) {
//       return res.status(404).json({ message: 'Task not found' });
//     }
 
//     res.status(200).json({ message: 'Task deleted successfully' });
 
//   } catch (err) {
//     res.status(500).json({ message: 'Failed to delete task', error: err.message });
//   }
// };
 
 
// // Soft Delete Task
// exports.deleteTask = async (req, res) => {
//   try {
//     const deletedTask = await Task.findOneAndUpdate(
//       { task_id: req.params.task_id },
//       { isDeleted: true },
//       { new: true }
//     );
 
//     if (!deletedTask) {
//       return res.status(404).json({ message: 'Task not found' });
//     }
 
//     res.status(200).json({ message: 'Task soft-deleted successfully' });
 
//   } catch (err) {
//     res.status(500).json({ message: 'Failed to delete task', error: err.message });
//   }
// };
 
 
// // Update Task Status
// exports.updateTaskStatus = async (req, res) => {
//   const { task_id } = req.params;
//   const { status, feedback } = req.body;
 
//   try {
//     const task = await Task.findOne({ task_id, isDeleted: false });
//     if (!task) {
//       return res.status(404).json({ message: 'Task not found' });
//     }
 
//     // If changing to 'Completed'
//    if (status === 'Completed') {
//   const now = new Date();
//   const todayStr = now.toISOString().split('T')[0];
//   const deadlineStr = task.deadline?.toISOString().split('T')[0];
 
//   const isLate = deadlineStr && todayStr > deadlineStr;
 
//   if (isLate && (!feedback || feedback.trim() === '')) {
//     return res.status(400).json({
//       message: 'Task is completed after the deadline. Feedback is required for the delay.'
//     });
//   }
 
//   task.completedAt = now;
//   task.isLate = isLate;
//   task.completionFeedback = isLate ? feedback : undefined;
// }
 
//     task.status = status;
//     await task.save();
 
//     res.json({ message: 'Task status updated successfully', task });
//   } catch (error) {
//     res.status(500).json({ message: 'Server error', error: error.message });
//   }
// };
 
 
// // Get tasks by assignee
// exports.getTasksByAssignee = async (req, res) => {
//   try {
//     const { assignedTo } = req.body;
//     const tasks = await Task.find({ assignedTo }).sort({ dueDate: 1 });
//     res.json(tasks);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// };
 
 
 

 
// exports.reviewTask = async (req, res) => {
//   try {
//     const { task_id } = req.params;
//     const { reviewedBy, reviewStatus } = req.body;
 
//     const task = await Task.findOne({ task_id });
//     if (!task) return res.status(404).json({ message: 'Task not found' });
 
//     task.reviewedBy = reviewedBy;
//     task.reviewStatus = reviewStatus;
 
//     if (reviewStatus === 'Accepted') {
//       task.status = 'Completed';
//       task.completedAt = new Date();
//     }
 
//     await task.save();
 
//     // Send notification to the task assignee
//     const notificationMessage = `Your task "${task.title}" has been reviewed and marked as "${reviewStatus}".`;
 
//     const notification = new Notification({
//       recipientId: task.assignedTo.toString(), // Make sure this is a string ID
//       message: notificationMessage,
//       link: `/tasks/${task.task_id}`, // Adjust the link format as needed
//     });
 
//     await notification.save();
 
//     res.status(200).json({ message: 'Task reviewed successfully', task });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
 
// // Get all tasks by projectiD AND projectName
// exports. getAllTask = async (req, res) => {
//   try {
//     const tasks = await Task.find().populate('projectId', 'projectName');
//     res.status(200).json(tasks);
//   } catch (error) {
//     res.status(500).json({ message: 'Error retrieving tasks', error });
//   }
// };
 
 
 
 
 

//  exports.getTasksByDeadline = async (req, res) => {
//   try {
//     // Set start of today
//     const startOfToday = new Date();
//     startOfToday.setHours(0, 0, 0, 0); // 00:00:00
 
//     // Set end of 7th day from today
//     const endOfNext7Days = new Date();
//     endOfNext7Days.setDate(startOfToday.getDate() + 7);
//     endOfNext7Days.setHours(23, 59, 59, 999); // 23:59:59
 
//     const tasks = await Task.find({
//       deadline: {
//         $gte: startOfToday,
//         $lte: endOfNext7Days
//       },
//       isDeleted: false
//     });
 
//     res.status(200).json({
//       success: true,
//       count: tasks.length,
//       data: tasks
//     });
//   } catch (error) {
//     console.error('Error fetching upcoming deadline tasks:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Internal Server Error'
//     });
//   }
// };
// // Link a bug to a task
// exports.linkBugToTask = async (req, res) => {
//   try {
//     const { task_id } = req.params;
//     const { bug_id } = req.body;
 
//     const task = await Task.findOne({ task_id });
//     if (!task) return res.status(404).json({ message: 'Task not found' });
 
//     const bug = await Bug.findOne({ bug_id });
//     if (!bug) return res.status(404).json({ message: 'Bug not found' });
 
//     // prevent duplicate
//     if (!task.bugIds.includes(bug_id)) {
//       task.bugIds.push(bug_id);
//     }
 
//     task.status = 'In Progress';
//     task.reviewStatus = 'Rejected';
//     await task.save();
 
//     res.status(200).json({ message: 'Bug linked to task successfully', task });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
 
 
 
// // Get project task summary
// exports.getProjectTaskSummary = async (req, res) => {
//   try {
//     const { projectId } = req.params;
 
//     const now = new Date();
//     const threeDaysLater = new Date();
//     threeDaysLater.setDate(now.getDate() + 3);
 
//     const totalTasks = await Task.countDocuments({ projectId });
//     const completedTasks = await Task.countDocuments({ projectId, status: 'Completed' });
//     const inProgressTasks = await Task.countDocuments({ projectId, status: 'In Progress' });
//     const pendingTasks = await Task.countDocuments({ projectId, status: 'Pending' });
 
//     const tasksExpiringSoon = await Task.countDocuments({
//       projectId,
//       deadline: { $gte: now, $lte: threeDaysLater }
//     });
 
//     res.status(200).json({
//       projectId,
//       totalTasks,
//       completedTasks,
//       inProgressTasks,
//       pendingTasks,
//       tasksExpiringSoon
//     });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
 
 
 
// // exports.getTasksByprojectId = async (req, res) => {
// //   try {
// //     const { projectId } = req.params;
// //     const tasks = await Task.find({ projectId }).sort({ dueDate: 1 });
// //     res.json(tasks);
// //   } catch (err) {
// //     res.status(500).json({ error: err.message });
// //   }
// // };

//  exports.getTasksByprojectId = async (req, res) => {
//   try {
//     const { projectId } = req.params;
 
//     // 1. Fetch tasks for the project
//     const tasks = await Task.find({ projectId }).sort({ dueDate: 1 });
 
//     // 2. Fetch team by projectId
//     const team = await Team.findOne({ projectId, isDeleted: false });
//     if (!team) {
//       return res.status(404).json({ message: 'Team not found for this project' });
//     }
 
//     // 3. Map over tasks and attach member details from team
//     const enrichedTasks = tasks.map(task => {
//       const assignedMember = team.teamMembers.find(member => member.memberId === task.assignedTo);
 
//       return {
//         ...task.toObject(),
//         assignedToDetails: assignedMember ? {
//           _id: assignedMember._id,
//           memberId: assignedMember.memberId,
//           memberName: assignedMember.memberName,
//           email: assignedMember.email,
//           role: assignedMember.role
//         } : null
//       };
//     });
 
//     res.json(enrichedTasks);
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: err.message });
//   }
// };
 
 
 
// exports.getTaskCounts = async (req, res) => {
//     try {
//         // Get today's date boundaries
//         const today = new Date();
//         today.setHours(0, 0, 0, 0);
//         const tomorrow = new Date(today);
//         tomorrow.setDate(tomorrow.getDate() + 1);
 
//         // Count all tasks (excluding deleted ones)
//         const totalTasks = await Task.countDocuments({ isDeleted: false });
 
//         // Count tasks with deadline today
//         const todayTasks = await Task.countDocuments({
//             isDeleted: false,
//             deadline: {
//                 $gte: today,
//                 $lt: tomorrow
//             }
//         });
 
//         res.status(200).json({
//             success: true,
//             data: {
//                 totalTasks,
//                 todayDeadlineTasks: todayTasks
//             }
//         });
//     } catch (error) {
//         res.status(500).json({
//             success: false,
//             message: 'Error fetching task counts',
//             error: error.message
//         });
//     }
// };

// exports.updateTaskStatusById = async (req, res) => {
//   try {
//     const { task_id } = req.params;
//     const { status } = req.body;
 
//     // Validate status
//     const validStatuses = ['Pending', 'In Progress', 'Completed'];
//     if (!validStatuses.includes(status)) {
//       return res.status(400).json({
//         success: false,
//         message: 'Invalid status. Must be Pending, In Progress, or Completed.',
//       });
//     }
 
//     const task = await Task.findOne({ task_id });
 
//     if (!task) {
//       return res.status(404).json({
//         success: false,
//         message: 'Task not found',
//       });
//     }
 
//     task.status = status;
 
//     // If task is marked completed, set completedAt
//     if (status === 'Completed' && !task.completedAt) {
//       task.completedAt = new Date();
 
//       if (task.deadline && new Date() > new Date(task.deadline)) {
//         task.isLate = true;
//       }
//     }
 
//     await task.save();
 
//     res.status(200).json({
//       success: true,
//       message: 'Task status updated successfully',
//       task,
//     });
//   } catch (err) {
//     console.error('Error updating task status:', err);
//     res.status(500).json({
//       success: false,
//       message: 'Internal server error',
//     });
//   }
// };
 const Task = require('../../Model/TaskModel/Task');
const Bug = require('../../Model/BugModel/Bug');
const Notification = require('../../Model/NotificationModel/notificationModel');
const Team=require('../../Model/TeamModel/Team')
const pushTaskHistory=require("../../utils/pushTaskHistory")
const moment = require('moment'); // for date handling
 const ExcelJS = require("exceljs");
 
//  exports.assignTask = async (req, res) => {
//   try {
//     const {
//       title,
//       description,
//       assignedTo,
//       assignedBy,
//       priority,
//       deadline,
//       projectId,
//       projectName,
//       memberId
//     } = req.body;
 
//     if (!title || !assignedTo || !assignedBy || !projectId) {
//       return res.status(400).json({
//         message: 'Title, assignedTo, assignedBy, and projectId are required.'
//       });
//     }
 
//     // Create the task with per-project ID generator
//     const task = await Task.createTaskWithId({
//       title,
//       description,
//       assignedTo,
//       assignedBy,
//       priority,
//       deadline,
//       projectId,
//       projectName,
//       memberId
//     });
 
//     // Create a notification for the assignee
//     const notification = new Notification({
//       recipientId: assignedTo.toString(),
//       message: `You have been assigned a new task: "${title}" in project "${projectName}".`,
//       link: `/tasks/${task.task_id}` 
//     });
 
//     await notification.save();
 
//     res.status(201).json({
//       message: 'Task assigned successfully',
//       task
//     });
//   } catch (err) {
//     res.status(500).json({
//       message: 'Internal server error',
//       error: err.message
//     });
//   }
// };
const mongoose = require('mongoose');


// exports.assignTask = async (req, res) => {
//   try {
//     const {
//       title,
//       description,
//       assignedTo,
//       assignedBy,
//       priority,
//       deadline,
//       projectId,
//       projectName,
//       memberId,
//       subtasks // <-- array of subtasks (optional)
//     } = req.body;
 
//     if (!title || !assignedTo || !assignedBy || !projectId) {
//       return res.status(400).json({
//         message: 'Title, assignedTo, assignedBy, and projectId are required.'
//       });
//     }
 
//     // Create the main task with a custom ID generator
//     const task = await Task.createTaskWithId({
//       title,
//       description,
//       assignedTo,
//       assignedBy,
//       priority,
//       deadline,
//       projectId,
//       projectName,
//       memberId
//     });
 
//     // If subtasks are provided, add them to the task
//     if (Array.isArray(subtasks) && subtasks.length > 0) {
//       for (let subtaskData of subtasks) {
//         await task.addSubtask(subtaskData);
//       }
//     }
 
//     // Create a notification for the main assignee
//     const notification = new Notification({
//       recipientId: assignedTo.toString(),
//       message: `You have been assigned a new task: "${title}" in project "${projectName}".`,
//       link: `/tasks/${task.task_id}`
//     });
 
//     await notification.save();
 
//     res.status(201).json({
//       message: 'Task (and subtasks if provided) assigned successfully',
//       task
//     });
//   } catch (err) {
//       console.log(err),
//     res.status(500).json({
    
//       message: 'Internal server error',
//       error: err.message
//     });
//   }
// };
 
exports.assignTask = async (req, res) => {
  try {
    const {
      title,
      description,
      assignedTo,
      assignedBy,
      priority,
      deadline,
      projectId,
      projectName,
      memberId,
      subtasks
    } = req.body;
 
    if (!title || !assignedTo || !assignedBy || !projectId) {
      return res.status(400).json({ message: "Missing required fields" });
    }
 
    // 🔥 Convert single object → array
    let assignedMembers = [];
    if (Array.isArray(assignedTo)) {
      assignedMembers = assignedTo;
    } else {
      assignedMembers = [assignedTo];  // single user
    }
 
    // 1️⃣ Create Task
    const task = await Task.createTaskWithId({
      title,
      description,
      assignedTo: assignedMembers,
      assignedBy,
      priority,
      deadline,
      projectId,
      projectName,
      memberId
    });
 
    // 2️⃣ Add Subtasks
    if (Array.isArray(subtasks) && subtasks.length > 0) {
      for (let sub of subtasks) {
        await task.addSubtask(sub);
      }
    }
 
    // 3️⃣ Notification for ALL assigned members
    for (let user of assignedMembers) {
      await Notification.create({
        recipientId: user.memberId,
        message: `You have been assigned a new task: "${title}" in project "${projectName}".`,
        link: `/tasks/${task.task_id}`
      });
    }
 
    res.status(201).json({
      message: "Task assigned successfully",
      task
    });
 
  } catch (err) {
    res.status(500).json({ message: "Internal server error", error: err.message });
  }
};


exports.getAllTasks = async (req, res) => {
  try {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
 
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);
 
    // Fetch all tasks (not just today’s)
    const tasks = await Task.find({ isDeleted: false }).sort({ createdAt: -1 }).lean();
 
    // Count tasks with today's deadline
    const todayDeadlineTasksCount = tasks.filter(task =>
      task.deadline &&
      new Date(task.deadline) >= todayStart &&
      new Date(task.deadline) <= todayEnd
    ).length;
 
    // Get all teams and build a memberId -> memberName map
    const teams = await Team.find({ isDeleted: false }).lean();
    const memberMap = {};
    for (const team of teams) {
      for (const member of team.teamMembers) {
        memberMap[member.memberId] = member.memberName;
      }
    }
 
    // Add assignedToName to each task
    const tasksWithMemberNames = tasks.map(task => ({
      ...task,
      assignedToName: memberMap[task.assignedTo] || 'Unknown'
    }));
 
    res.status(200).json({
      totalTasks: tasks.length,
      todayDeadlineTasks: todayDeadlineTasksCount,
      tasks: tasksWithMemberNames
    });
 
  } catch (err) {
    console.error('Error fetching tasks:', err);
    res.status(500).json({ message: 'Failed to fetch tasks', error: err.message });
  }
};

// exports.getTasksByMemberId = async (req, res) => {

// };


 exports.getTasksByMemberId = async (req, res) => {
  const { memberId } = req.params;
 
  try {
    if (!memberId) {
      return res.status(400).json({ message: "memberId is required" });
    }
 
    // Step 1: Fetch tasks where assignedTo = memberId
    const tasks = await Task.find({
      assignedTo: memberId,
      isDeleted: false
    }).populate('bugIds').lean()  .sort({ createdAt: -1 }); // lean returns plain JS objects
 
    if (!tasks.length) {
      return res.status(404).json({ message: "No tasks found for this member" });
    }
 
    // Step 2: Fetch all teams
    const teams = await Team.find({ isDeleted: false }).lean();
 
    // Step 3: Build memberId -> { name, role, email } map
    const memberMap = {};
    teams.forEach(team => {
      team.teamMembers.forEach(member => {
        memberMap[member.memberId] = {
          name: member.memberName,
          role: member.role,
          email: member.email
        };
      });
    });
 
    // Step 4: Enrich each task with assignedToName, assignedToRole, assignedToEmail
    const enrichedTasks = tasks.map(task => {
      const memberInfo = memberMap[task.assignedTo] || {};
      return {
        ...task,
        assignedToName: memberInfo.name || 'Unknown',
        assignedToRole: memberInfo.role || 'Unknown',
        assignedToEmail: memberInfo.email || 'Unknown'
      };
    });
 
    // Step 5: Send response
    res.status(200).json({
      success: true,
      data: enrichedTasks
    });
 
  } catch (error) {
    console.error("Error fetching tasks by memberId:", error);
    res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message
    });
  }
};
 
//  exports.getTasksByMemberId = async (req, res) => {
//   const { memberId } = req.params;
 
//   try {
//     if (!memberId) {
//       return res.status(400).json({ message: "memberId is required" });
//     }
 
//     // Step 1: Fetch tasks where assignedTo = memberId
//     const tasks = await Task.find({
//       assignedTo: memberId,
//       isDeleted: false
//     }).populate('bugIds').lean()  .sort({ createdAt: -1 }); // lean returns plain JS objects
 
//     if (!tasks.length) {
//       return res.status(404).json({ message: "No tasks found for this member" });
//     }
 
//     // Step 2: Fetch all teams
//     const teams = await Team.find({ isDeleted: false }).lean();
 
//     // Step 3: Build memberId -> { name, role, email } map
//     const memberMap = {};
//     teams.forEach(team => {
//       team.teamMembers.forEach(member => {
//         memberMap[member.memberId] = {
//           name: member.memberName,
//           role: member.role,
//           email: member.email
//         };
//       });
//     });
 
//     // Step 4: Enrich each task with assignedToName, assignedToRole, assignedToEmail
//     const enrichedTasks = tasks.map(task => {
//       const memberInfo = memberMap[task.assignedTo] || {};
//       return {
//         ...task,
//         assignedToName: memberInfo.name || 'Unknown',
//         assignedToRole: memberInfo.role || 'Unknown',
//         assignedToEmail: memberInfo.email || 'Unknown'
//       };
//     });
 
//     // Step 5: Send response
//     res.status(200).json({
//       success: true,
//       data: enrichedTasks
//     });
 
//   } catch (error) {
//     console.error("Error fetching tasks by memberId:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server Error",
//       error: error.message
//     });
//   }
// };
 
//  exports.getTaskById = async (req, res) => {
//   try {
//     // 1. Find the task by task_id
//     const task = await Task.findOne({ task_id: req.params.task_id, isDeleted: false });

//     if (!task) {
//       return res.status(404).json({ message: 'Task not found' });
//     }

//     // 2. Get projectId from task and fetch team(s)
//     const projectId = task.projectId;
//     const teams = await Team.find({ projectId, isDeleted: false });

//     if (!teams || teams.length === 0) {
//       return res.status(404).json({ message: 'No team found for this project' });
//     }

//     // 3. Find the team that contains the assigned member
//     let assignedMember = null;
//     let assignedTeam = null;

//     for (const team of teams) {
//       const member = team.teamMembers.find(m => m.memberId === task.assignedTo);
//       if (member) {
//         assignedMember = member;
//         assignedTeam = team;
//         break;
//       }
//     }

//     // 4. Build assignedToDetails
//     const assignedToDetails = assignedMember
//       ? {
//           _id: assignedMember._id,
//           memberId: assignedMember.memberId,
//           memberName: assignedMember.memberName,
//           email: assignedMember.email,
//           role: assignedMember.role,
//         }
//       : null;

//     // 5. Fetch bugs related to this task (taskRef = task.task_id)
//     const bugs = await Bug.find({ taskRef: task.task_id }).sort({ createdAt: -1 });

//     // 6. Final enriched task with teamLeadId, assignedToDetails, and bugs
//     const enrichedTask = {
//       ...task.toObject(),
//       teamLeadId: assignedTeam ? assignedTeam.teamLeadId : null,
//       assignedToDetails,
//       bugs, // only bugs belonging to this task
//     };

//     res.status(200).json({ task: enrichedTask });
//   } catch (err) {
//     console.error('Error in getTaskById:', err);
//     res.status(500).json({ message: 'Failed to get task', error: err.message });
//   }
// };

exports.getTaskById = async (req, res) => {
  try {
    const taskId = req.params.task_id;

    // 1. Find the main task
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    // 2. Fetch subtasks of this task
    const subtasks = await Task.find({ taskRef: taskId, isDeleted: false }).sort({ createdAt: 1 });

    // 3. Fetch project teams to get assigned member details
    const projectId = task.projectId;
    const teams = await Team.find({ projectId, isDeleted: false });

    let assignedMember = null;
    let assignedTeam = null;

    for (const team of teams) {
      const member = team.teamMembers.find(m => m.memberId === task.assignedTo);
      if (member) {
        assignedMember = member;
        assignedTeam = team;
        break;
      }
    }

    const assignedToDetails = assignedMember
      ? {
          _id: assignedMember._id,
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
          email: assignedMember.email,
          role: assignedMember.role,
        }
      : null;

    // 4. Fetch only bugs related to the main task (exclude bugs linked to subtasks)
    const bugs = await Bug.find({ taskRef: taskId, subtaskRef: { $in: [null, undefined] } }).sort({ createdAt: -1 });

    // 5. Build enriched task object
    const enrichedTask = {
      ...task.toObject(),
      teamLeadId: assignedTeam ? assignedTeam.teamLeadId : null,
      assignedToDetails,
      subtasks, // all subtasks of this task
      bugs,     // only main task bugs, exclude subtask bugs
    };

    res.status(200).json({ task: enrichedTask });
  } catch (err) {
    console.error('Error in getTaskById:', err);
    res.status(500).json({ message: 'Failed to get task', error: err.message });
  }
};



 
// exports.getTaskById = async (req, res) => {
//   try {
//     // 1. Find the task by task_id
//     const task = await Task.findOne({ task_id: req.params.task_id, isDeleted: false });

//     if (!task) {
//       return res.status(404).json({ message: 'Task not found' });
//     }

//     // 2. Get projectId from task and fetch team(s)
//     const projectId = task.projectId;
//     const teams = await Team.find({ projectId, isDeleted: false });

//     if (!teams || teams.length === 0) {
//       return res.status(404).json({ message: 'No team found for this project' });
//     }

//     // 3. Find the team that contains the assigned member
//     let assignedMember = null;
//     let assignedTeam = null;

//     for (const team of teams) {
//       const member = team.teamMembers.find(m => m.memberId === task.assignedTo);
//       if (member) {
//         assignedMember = member;
//         assignedTeam = team;
//         break;
//       }
//     }

//     // 4. Build assignedToDetails
//     const assignedToDetails = assignedMember
//       ? {
//           _id: assignedMember._id,
//           memberId: assignedMember.memberId,
//           memberName: assignedMember.memberName,
//           email: assignedMember.email,
//           role: assignedMember.role,
//         }
//       : null;

//     // 5. Final enriched task with teamLeadId at root + assignedToDetails
//     const enrichedTask = {
//       ...task.toObject(),
//       teamLeadId: assignedTeam ? assignedTeam.teamLeadId : null,
//       assignedToDetails,
//     };

//     res.status(200).json({ task: enrichedTask });
//   } catch (err) {
//     console.error('Error in getTaskById:', err);
//     res.status(500).json({ message: 'Failed to get task', error: err.message });
//   }
// };

// exports.updateTask = async (req, res) => {
//   try {
//     const taskId = req.params.task_id;

//     // Find the existing task first
//     const existingTask = await Task.findOne({ task_id: taskId });

//     if (!existingTask) {
//       return res.status(404).json({ message: 'Task not found' });
//     }

//     // If status is updated to "Completed"
//     if (req.body.status && req.body.status === 'Completed') {
//       const currentTime = new Date();
      
//       // Create a date object without the time part for the current date and deadline
//       const currentDateOnly = new Date(currentTime.setHours(0, 0, 0, 0));
//       const deadlineDateOnly = new Date(existingTask.deadline).setHours(0, 0, 0, 0);

//       // Check if task is completed after the deadline
//       if (existingTask.deadline && currentDateOnly > deadlineDateOnly) {
//         // It's late
//         if (!req.body.delayReason || req.body.delayReason.trim() === '') {
//           return res.status(400).json({
//             message: 'Task is completed after the deadline. Please provide a delayReason.'
//           });
//         }

//         req.body.isLate = true;
//         req.body.completedAt = currentTime;
//       } else if (existingTask.deadline && currentDateOnly === deadlineDateOnly) {
//         // Task is completed today, which is the deadline
//         req.body.isLate = false; // No late status
//         req.body.delayReason = ''; // Clear delay reason if any
//         req.body.completedAt = currentTime;
//       } else {
//         // Not late and not completed today
//         req.body.isLate = false;
//         req.body.delayReason = ''; // Clear old reason if any
//         req.body.completedAt = currentTime;
//       }
//     }

//     // Update the task
//     const updatedTask = await Task.findOneAndUpdate(
//       { task_id: taskId },
//       req.body,
//       { new: true }
//     );

//     // Create a notification message
//     let message = `Task "${updatedTask.title}" has been updated.`;

//     if (
//       req.body.assignedTo &&
//       req.body.assignedTo !== existingTask.assignedTo?.toString()
//     ) {
//       message = `You have been assigned a new task: "${updatedTask.title}".`;

//       const reassignedNotification = new Notification({
//         recipientId: req.body.assignedTo.toString(),
//         message,
//         link: `/tasks/${updatedTask.task_id}`,
//       });

//       await reassignedNotification.save();
//     } else {
//       const updateNotification = new Notification({
//         recipientId: updatedTask.assignedTo?.toString(),
//         message,
//         link: `/tasks/${updatedTask.task_id}`,
//       });

//       await updateNotification.save();
//     }

//     res.status(200).json({
//       message: 'Task updated successfully',
//       task: updatedTask,
//     });
//   } catch (err) {
//     res.status(500).json({
//       message: 'Failed to update task',
//       error: err.message,
//     });
//   }
// };

 
 
exports.updateTask = async (req, res) => {

  try {

    const taskId = req.params.task_id;
 
    // Step 1: Find the existing task first

    const existingTask = await Task.findOne({ task_id: taskId });
 
    if (!existingTask) {

      return res.status(404).json({ message: 'Task not found' });

    }
 
    // Step 2: Check subtasks status before updating main task to "Completed"

    if (req.body.status && req.body.status === 'Completed') {

      let canComplete = false;
 
      if (existingTask.subtasks.length === 0) {

        // ✅ No subtasks, allow completion

        canComplete = true;

      } else {

        // ✅ Subtasks exist → check if all completed or all deleted

        const allSubtasksCompleted = existingTask.subtasks.every(

          (st) => st.status === 'Completed' || st.isDeleted === true

        );
 
        canComplete = allSubtasksCompleted;

      }
 
      if (!canComplete) {

        return res.status(200).json({

          message:

            'Task cannot be marked as Completed until all subtasks are either completed or deleted.',

        });

      }
 
      const currentTime = new Date();
 
      // Prepare date objects for deadline check

      const currentDateOnly = new Date(currentTime.setHours(0, 0, 0, 0));

      const deadlineDateOnly = existingTask.deadline

        ? new Date(existingTask.deadline).setHours(0, 0, 0, 0)

        : null;
 
      // Handle late completion logic

      if (deadlineDateOnly && currentDateOnly > deadlineDateOnly) {

        if (!req.body.delayReason || req.body.delayReason.trim() === '') {

          return res.status(400).json({

            message:

              'Task is completed after the deadline. Please provide a delayReason.',

          });

        }
 
        req.body.isLate = true;

        req.body.completedAt = currentTime;

      } else if (deadlineDateOnly && currentDateOnly === deadlineDateOnly) {

        req.body.isLate = false;

        req.body.delayReason = '';

        req.body.completedAt = currentTime;

      } else {

        req.body.isLate = false;

        req.body.delayReason = '';

        req.body.completedAt = currentTime;

      }

    }
 
    // Step 3: Update the task

    const updatedTask = await Task.findOneAndUpdate(

      { task_id: taskId },

      req.body,

      { new: true }

    );
 
    // Step 4: Create a notification

    let message = `Task "${updatedTask.title}" has been updated.`;
 
    if (

      req.body.assignedTo &&

      req.body.assignedTo !== existingTask.assignedTo?.toString()

    ) {

      message = `You have been assigned a new task: "${updatedTask.title}".`;
 
      const reassignedNotification = new Notification({

        recipientId: req.body.assignedTo.toString(),

        message,

        link: `/tasks/${updatedTask.task_id}`,

      });
 
      await reassignedNotification.save();

    } else {

      const updateNotification = new Notification({

        recipientId: updatedTask.assignedTo?.toString(),

        message,

        link: `/tasks/${updatedTask.task_id}`,

      });
 
      await updateNotification.save();

    }
 
    res.status(200).json({

      message: 'Task updated successfully',

      task: updatedTask,

    });

  } catch (err) {

    res.status(500).json({

      message: 'Failed to update task',

      error: err.message,

    });

  }

};

 
// Delete Task permanenly
exports.deleteTaskPermanent= async (req, res) => {
  try {
    const deletedTask = await Task.findOneAndDelete({ task_id: req.params.task_id });
 
    if (!deletedTask) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    res.status(200).json({ message: 'Task deleted successfully' });
 
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete task', error: err.message });
  }
};
 
 
// Soft Delete Task
exports.deleteTask = async (req, res) => {
  try {
    const deletedTask = await Task.findOneAndUpdate(
      { task_id: req.params.task_id },
      { isDeleted: true },
      { new: true }
    );
 
    if (!deletedTask) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    res.status(200).json({ message: 'Task soft-deleted successfully' });
 
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete task', error: err.message });
  }
};
 
 
// Update Task Status
exports.updateTaskStatus = async (req, res) => {
  const { task_id } = req.params;
  const { status, feedback } = req.body;
 
  try {
    const task = await Task.findOne({ task_id, isDeleted: false });
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    // If changing to 'Completed'
   if (status === 'Completed') {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const deadlineStr = task.deadline?.toISOString().split('T')[0];
 
  const isLate = deadlineStr && todayStr > deadlineStr;
 
  if (isLate && (!feedback || feedback.trim() === '')) {
    return res.status(400).json({
      message: 'Task is completed after the deadline. Feedback is required for the delay.'
    });
  }
 
  task.completedAt = now;
  task.isLate = isLate;
  task.completionFeedback = isLate ? feedback : undefined;
}
 
    task.status = status;
    await task.save();
 
    res.json({ message: 'Task status updated successfully', task });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
 
 
// Get tasks by assignee
exports.getTasksByAssignee = async (req, res) => {
  try {
    const { assignedTo } = req.body;
    const tasks = await Task.find({ assignedTo }).sort({ dueDate: 1 });
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
 

 
exports.reviewTask = async (req, res) => {
  try {
    const { task_id } = req.params;
    const { reviewedBy, reviewStatus } = req.body;
 
    const task = await Task.findOne({ task_id });
    if (!task) return res.status(404).json({ message: 'Task not found' });
 
    task.reviewedBy = reviewedBy;
    task.reviewStatus = reviewStatus;
 
    if (reviewStatus === 'Accepted') {
      task.status = 'Completed';
      task.completedAt = new Date();
    }
 
    await task.save();
 
    // Send notification to the task assignee
    const notificationMessage = `Your task "${task.title}" has been reviewed and marked as "${reviewStatus}".`;
 
    const notification = new Notification({
      recipientId: task.assignedTo.toString(), // Make sure this is a string ID
      message: notificationMessage,
      link: `/tasks/${task.task_id}`, // Adjust the link format as needed
    });
 
    await notification.save();
 
    res.status(200).json({ message: 'Task reviewed successfully', task });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
 
// Get all tasks by projectiD AND projectName
exports. getAllTask = async (req, res) => {
  try {
    const tasks = await Task.find({isDeleted: false}).populate('projectId', 'projectName');
    res.status(200).json(tasks);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving tasks', error });
  }
};
 
 exports.getTasksByDeadline = async (req, res) => {

 try {
    const today = new Date();
 
    const tasks = await Task.find({
      isDeleted: false,
      deadline: { $lt: today },
      status: { $ne: 'Completed' }
    }).sort({ deadline: 1 }); // optional: sort by deadline
 
    return res.status(200).json({ success: true, tasks });
  } catch (error) {
    console.error('Error fetching overdue tasks:', error);
    return res.status(500).json({ success: false, message: 'Server Error' });
  }

};

exports.getTodayAndOverdueTasks = async (req, res) => {
  try {
    const { employeeId } = req.params;
 
    if (!employeeId) {
      return res.status(400).json({ message: 'employeeId is required' });
    }
 
    // Get today's date in YYYY-MM-DD format
    const today = moment().startOf('day');
    const tomorrow = moment(today).add(1, 'days');
 
    // Query tasks
    const tasks = await Task.find({
      memberId: employeeId,
      isDeleted: false,
      $or: [
        {
          // Tasks whose deadline is today
          deadline: {
            $gte: today.toDate(),
            $lt: tomorrow.toDate()
          }
        },
        {
          // Tasks past deadline but not completed
          deadline: { $lt: today.toDate() },
          status: { $ne: 'Completed' }
        }
      ]
    }).sort({ deadline: 1 }); // optional: sort by deadline
 
    return res.status(200).json({ success: true, tasks });
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return res.status(500).json({ success: false, message: 'Server Error' });
  }
};
//  exports.getTasksByDeadline = async (req, res) => {
//   try {
//     // Set start of today
//     const startOfToday = new Date();
//     startOfToday.setHours(0, 0, 0, 0); // 00:00:00
 
//     // Set end of 7th day from today
//     const endOfNext7Days = new Date();
//     endOfNext7Days.setDate(startOfToday.getDate() + 7);
//     endOfNext7Days.setHours(23, 59, 59, 999); // 23:59:59
 
//     const tasks = await Task.find({
//       deadline: {
//         $gte: startOfToday,
//         $lte: endOfNext7Days
//       },
//       isDeleted: false
//     });
 
//     res.status(200).json({
//       success: true,
//       count: tasks.length,
//       data: tasks
//     });
//   } catch (error) {
//     console.error('Error fetching upcoming deadline tasks:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Internal Server Error'
//     });
//   }
// };
// Link a bug to a task
exports.linkBugToTask = async (req, res) => {
  try {
    const { task_id } = req.params;
    const { bug_id } = req.body;
 
    const task = await Task.findOne({ task_id });
    if (!task) return res.status(404).json({ message: 'Task not found' });
 
    const bug = await Bug.findOne({ bug_id });
    if (!bug) return res.status(404).json({ message: 'Bug not found' });
 
    // prevent duplicate
    if (!task.bugIds.includes(bug_id)) {
      task.bugIds.push(bug_id);
    }
 
    task.status = 'In Progress';
    task.reviewStatus = 'Rejected';
    await task.save();
 
    res.status(200).json({ message: 'Bug linked to task successfully', task });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
 
 
 
// Get project task summary
exports.getProjectTaskSummary = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    const now = new Date();
    const threeDaysLater = new Date();
    threeDaysLater.setDate(now.getDate() + 3);
 
    const totalTasks = await Task.countDocuments({ projectId });
    const completedTasks = await Task.countDocuments({ projectId, status: 'Completed' });
    const inProgressTasks = await Task.countDocuments({ projectId, status: 'In Progress' });
    const pendingTasks = await Task.countDocuments({ projectId, status: 'Pending' });
 
    const tasksExpiringSoon = await Task.countDocuments({
      projectId,
      deadline: { $gte: now, $lte: threeDaysLater }
    });
 
    res.status(200).json({
      projectId,
      totalTasks,
      completedTasks,
      inProgressTasks,
      pendingTasks,
      tasksExpiringSoon
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
 

// Get tasks by projectId and enrich with assigned member details
// exports.getTasksByprojectId = async (req, res) => {
//   try {
//     const { projectId } = req.params;
 
//     // 1. Fetch tasks for the project
//     const tasks = await Task.find({ projectId, isDeleted: false }).sort({ createdAt: -1 });
 
//     // 2. Fetch team by projectId
//     const team = await Team.findOne({ projectId, isDeleted: false });
//     if (!team) {
//       return res.status(404).json({ message: 'Team not found for this project' });
//     }
 
//     // Debug: Log available members
//     console.log("Team Members:", team.teamMembers.map(m => ({
//       id: String(m.memberId),
//       name: m.memberName
//     })));
 
//     // 3. Map over tasks and attach member details from team
//     const enrichedTasks = tasks.map(task => {
//       const assignedMember = team.teamMembers.find(
//         member => String(member.memberId) === String(task.assignedTo) // fixed type mismatch
//       );
 
//       if (!assignedMember) {
//         console.warn(`No matching member found for task ${task._id}, assignedTo=${task.assignedTo}`);
//       }
 
//       return {
//         ...task.toObject(),
//         assignedToDetails: assignedMember
//           ? {
//               _id: assignedMember._id,
//               memberId: assignedMember.memberId,
//               memberName: assignedMember.memberName,
//               email: assignedMember.email,
//               role: assignedMember.role,
//             }
//           : null,
//       };
//     });
 
//     // 4. Send tasks + team details
//     res.json({
//       team: {
//         _id: team._id,
//         teamId: team.teamId,
//         projectId: team.projectId,
//         teamName: team.teamName,
//         projectName: team.projectName,
//         teamLeadId: team.teamLeadId,
//         teamLeadName: team.teamLeadName,
//         teamMembers: team.teamMembers,
//         createdAt: team.createdAt,
//         updatedAt: team.updatedAt,
//       },
//       tasks: enrichedTasks,
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: err.message });
//   }
// };
// exports.getTasksByprojectId = async (req, res) => {
//   try {
//     const { projectId } = req.params;

//     // 1. Fetch tasks for the project
//     const tasks = await Task.find({ projectId, isDeleted: false }).sort({ createdAt: -1 });

//     // 2. Fetch all teams for this project
//     const teams = await Team.find({ projectId, isDeleted: false });

//     if (!teams || teams.length === 0) {
//       return res.status(404).json({ message: 'No teams found for this project' });
//     }

//     // 3. Combine all team members into a single map for fast lookup
//     const memberMap = {};
//     teams.forEach(team => {
//       team.teamMembers.forEach(member => {
//         memberMap[String(member.memberId).trim()] = {
//           _id: member._id,
//           memberId: member.memberId,
//           memberName: member.memberName,
//           email: member.email,
//           role: member.role
//         };
//       });
//     });

//     // Debug: Log all member IDs
//     console.log('All project members:', Object.keys(memberMap));

//     // 4. Map over tasks and attach member details
//     const enrichedTasks = tasks.map(task => {
//       const assignedToStr = task.assignedTo ? String(task.assignedTo).trim() : null;
//       const assignedMember = assignedToStr ? memberMap[assignedToStr] || null : null;

//       if (!assignedMember) {
//         console.warn(`Task ${task._id} assignedTo=${task.assignedTo} not found in any team`);
//       }

//       return {
//         ...task.toObject(),
//         assignedToDetails: assignedMember
//           ? assignedMember
//           : { warning: "Assigned member not in any team", assignedTo: task.assignedTo }
//       };
//     });

//     // 5. Return all teams + enriched tasks
//     res.json({
//       teams,
//       tasks: enrichedTasks
//     });

//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: err.message });
//   }
// };

exports.getTasksByprojectId = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    // 1️⃣ Fetch tasks for the project
    const tasks = await Task.find({ projectId, isDeleted: false }).sort({ createdAt: -1 });
 
    // 2️⃣ Fetch all teams for this project
    const teams = await Team.find({ projectId, isDeleted: false });
 
    if (!teams || teams.length === 0) {
      return res.status(404).json({ message: "No teams found for this project" });
    }
 
    // 3️⃣ Combine all team members into a single map for quick lookup
    const memberMap = {};
    teams.forEach(team => {
      team.teamMembers.forEach(member => {
        memberMap[String(member.memberId).trim()] = {
          _id: member._id,
          memberId: member.memberId,
          memberName: member.memberName,
          email: member.email,
          role: member.role,
        };
      });
    });
 
    // 4️⃣ Fetch all bugs for the given project (linked via taskRef)
    const allBugs = await Bug.find({ projectId }).sort({ createdAt: -1 });
 
    // 5️⃣ Group bugs by taskRef for quick lookup
    const bugMap = {};
    allBugs.forEach(bug => {
      if (!bugMap[bug.taskRef]) bugMap[bug.taskRef] = [];
      bugMap[bug.taskRef].push(bug);
    });
 
    // 6️⃣ Map over tasks and attach details + resolution status
    const enrichedTasks = tasks.map(task => {
      const assignedToStr = task.assignedTo ? String(task.assignedTo).trim() : null;
      const assignedMember = assignedToStr ? memberMap[assignedToStr] || null : null;
 
      // 🐞 Find all bugs linked to this task
      const taskBugs = bugMap[task.task_id] || [];
 
      // 🧠 Determine if all bugs are resolved
      const isResolved = taskBugs.length === 0
        ? true // No bugs means resolved
        : taskBugs.every(b => b.status.toLowerCase() === "resolved" || b.status.toLowerCase() === "closed");
 
      return {
        ...task.toObject(),
        assignedToDetails: assignedMember
          ? assignedMember
          : { warning: "Assigned member not found in any team", assignedTo: task.assignedTo },
        bugs: taskBugs.map(bug => ({
          bug_id: bug.bug_id,
          title: bug.title,
          description: bug.description,
          status: bug.status,
          priority: bug.priority,
          assignedTo: bug.assignedTo,
          deadline: bug.deadline,
          createdAt: bug.createdAt,
        })),
        isResolved, // ✅ Whether all bugs in this task are resolved
      };
    });
 
    // ✅ Final response
    res.status(200).json({
      success: true,
      teams,
      tasks: enrichedTasks,
    });
 
  } catch (err) {
    console.error("Error in getTasksByprojectId:", err);
    res.status(500).json({ success: false, error: err.message });
  }
};

exports.getTaskCounts = async (req, res) => {
    try {
        // Get today's date boundaries
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
 
        // Count all tasks (excluding deleted ones)
        const totalTasks = await Task.countDocuments({ isDeleted: false });
 
        // Count tasks with deadline today
        const todayTasks = await Task.countDocuments({
            isDeleted: false,
            deadline: {
                $gte: today,
                $lt: tomorrow
            }
        });
 
        res.status(200).json({
            success: true,
            data: {
                totalTasks,
                todayDeadlineTasks: todayTasks
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching task counts',
            error: error.message
        });
    }
};

exports.updateTaskStatusById = async (req, res) => {
  try {
    const { task_id } = req.params;
    const { status } = req.body;
 
    // Validate status
    const validStatuses = ['Pending', 'In Progress', 'Completed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be Pending, In Progress, or Completed.',
      });
    }
 
    const task = await Task.findOne({ task_id });
 
    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'Task not found',
      });
    }
 
    task.status = status;
 
    // If task is marked completed, set completedAt
    if (status === 'Completed' && !task.completedAt) {
      task.completedAt = new Date();
 
      if (task.deadline && new Date() > new Date(task.deadline)) {
        task.isLate = true;
      }
    }
 
    await task.save();
 
    res.status(200).json({
      success: true,
      message: 'Task status updated successfully',
      task,
    });
  } catch (err) {
    console.error('Error updating task status:', err);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};


exports.updateReviewStatus = async (req, res) => {
  try {
    const { task_id } = req.params;
    const { reviewStatus } = req.body;
 
    const validStatuses = ['N/A', 'InReview', 'BugReported', 'Resolved'];
    if (!validStatuses.includes(reviewStatus)) {
      return res.status(400).json({ message: 'Invalid review status value' });
    }
 
    const task = await Task.findOne({ task_id });
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    task.reviewStatus = reviewStatus;
    await task.save();
 
    //  Push to history (skip if already Resolved)
    await pushTaskHistory(task_id, {
      action: 'Review Status Updated',
      reviewStatus
    });
 
    //  Send notification if status is "Resolved"
    if (reviewStatus === 'Resolved') {
      const notification = new Notification({
        recipientId: task.assignedTo?.toString(), // Dynamic recipient
        message: `Your task "${task.title}" has been marked as Resolved.`,
        link: `/tasks/${task.task_id}`
      });
      await notification.save();
    }
 
    return res.status(200).json({
      message: 'Review status updated successfully',
      updatedReviewStatus: task.reviewStatus
    });
 
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server error', error: error.message });
  }
};


// exports.exportTasks = async (req, res) => {
//   try {
//     const { projectId, assignedTo, filterObj = {} } = req.body;
 
//     if (!projectId) {
//       return res.status(400).json({ message: "projectId is required" });
//     }
 
//     // Build query
//     let query = { projectId };
 
//     if (assignedTo) {
//       query.assignedTo = assignedTo;
//     }
 
//     if (filterObj.priority) {
//       query.priority = filterObj.priority;
//     }
 
//     if (filterObj.status) {
//       query.status = filterObj.status;
//     }
 
//     if (filterObj.assignedTo) {
//       query.assignedTo = { $regex: filterObj.assignedTo.trim(), $options: "i" };
//     }
 
//     if (filterObj.dateFrom || filterObj.dateTo) {
//       query.createdAt = {};
//       if (filterObj.dateFrom) {
//         query.createdAt.$gte = new Date(filterObj.dateFrom);
//       }
//       if (filterObj.dateTo) {
//         query.createdAt.$lte = new Date(filterObj.dateTo);
//       }
//     }
 
//     // Fetch tasks
//     const tasks = await Task.find(query).lean();
 
//     if (!tasks.length) {
//       return res.status(404).json({ message: "No tasks found for given filters" });
//     }
 
//     //  Fetch team for this project
//     const team = await Team.findOne({ projectId, isDeleted: false }).lean();
 
//     // Helper: map memberId → memberName
//     let memberMap = {};
//     if (team && team.teamMembers) {
//       team.teamMembers.forEach(member => {
//         memberMap[member.memberId] = member.memberName;
//       });
//     }
 
//     // Create Excel workbook
//     const workbook = new ExcelJS.Workbook();
//     const worksheet = workbook.addWorksheet("Tasks");
 
//     worksheet.columns = [
//       { header: "Task ID", key: "task_id", width: 15 },
//       { header: "Project ID", key: "projectId", width: 20 },
//       { header: "Project Name", key: "projectName", width: 20 },
//       { header: "Title", key: "title", width: 25 },
//       { header: "Description", key: "description", width: 30 },
//       { header: "Status", key: "status", width: 15 },
//       { header: "Priority", key: "priority", width: 15 },
//       { header: "Assigned To", key: "assignedTo", width: 20 },
//       { header: "Assigned By", key: "assignedBy", width: 20 },
//       { header: "Deadline", key: "deadline", width: 20 },
//       { header: "Created At", key: "createdAt", width: 20 },
//       { header: "Completed At", key: "completedAt", width: 20 },
//       { header: "Is Late", key: "isLate", width: 10 },
//       { header: "Review Status", key: "reviewStatus", width: 15 },
//       { header: "Delay Reason", key: "delayReason", width: 25 }
//     ];
 
//     // Add rows (no MongoID now ✅)
//     tasks.forEach(task => {
//       worksheet.addRow({
//         task_id: task.task_id,
//         projectId: task.projectId,
//         projectName: task.projectName,
//         title: task.title,
//         description: task.description,
//         status: task.status,
//         priority: task.priority,
//         assignedTo: memberMap[task.assignedTo] || task.assignedTo,
//         assignedBy: task.assignedBy,
//         deadline: task.deadline ? task.deadline.toISOString().split("T")[0] : "",
//         createdAt: task.createdAt ? task.createdAt.toISOString().split("T")[0] : "",
//         completedAt: task.completedAt ? task.completedAt.toISOString().split("T")[0] : "",
//         isLate: task.isLate ? "Yes" : "No",
//         reviewStatus: task.reviewStatus || "",
//         delayReason: task.delayReason || ""
//       });
//     });
 
//     res.setHeader(
//       "Content-Type",
//       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
//     );
//     res.setHeader(
//       "Content-Disposition",
//       `attachment; filename=tasks_${Date.now()}.xlsx`
//     );
 
//     await workbook.xlsx.write(res);
//     res.end();
 
//   } catch (error) {
//     console.log("Error exporting tasks:", error);
//     res.status(500).json({ message: "Error generating Excel file" });
//   }
// };

//
exports.exportTasks = async (req, res) => {
  try {
    const { projectId, assignedTo, filterObj = {} } = req.body;

    if (!projectId) {
      return res.status(400).json({ message: "projectId is required" });
    }

    // --------------------------
    // Build query
    // --------------------------
    let query = { projectId };

    if (assignedTo) {
      query.assignedTo = assignedTo;
    }

    if (filterObj.priority) {
      query.priority = filterObj.priority;
    }

    if (filterObj.status) {
      query.status = filterObj.status;
    }

    if (filterObj.assignedTo) {
      query.assignedTo = { $regex: filterObj.assignedTo.trim(), $options: "i" };
    }

    if (filterObj.dateFrom || filterObj.dateTo) {
      query.createdAt = {};
      if (filterObj.dateFrom) {
        query.createdAt.$gte = new Date(filterObj.dateFrom);
      }
      if (filterObj.dateTo) {
        query.createdAt.$lte = new Date(filterObj.dateTo);
      }
    }

    // --------------------------
    // Fetch tasks
    // --------------------------
    const tasks = await Task.find(query).lean();

    if (!tasks.length) {
      return res.status(404).json({ message: "No tasks found for given filters" });
    }

    // --------------------------
    // Fetch team (for member names)
    // --------------------------
    const team = await Team.findOne({ projectId, isDeleted: false }).lean();

    let memberMap = {};
    if (team && team.teamMembers) {
      team.teamMembers.forEach(member => {
        memberMap[member.memberId] = member.memberName;
      });
    }

    // --------------------------
    // Safe date formatter
    // --------------------------
    const formatDate = (date) => {
      if (!date) return "";
      const d = new Date(date);
      return isNaN(d) ? "" : d.toISOString().split("T")[0];
    };

    // --------------------------
    // Excel workbook setup
    // --------------------------
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Tasks");

    worksheet.columns = [
      { header: "Task ID", key: "task_id", width: 15 },
      { header: "Project ID", key: "projectId", width: 20 },
      { header: "Project Name", key: "projectName", width: 20 },
      { header: "Title", key: "title", width: 25 },
      { header: "Description", key: "description", width: 30 },
      { header: "Status", key: "status", width: 15 },
      { header: "Priority", key: "priority", width: 15 },
      { header: "Assigned To", key: "assignedTo", width: 20 },
      { header: "Assigned By", key: "assignedBy", width: 20 },
      { header: "Deadline", key: "deadline", width: 20 },
      { header: "Created At", key: "createdAt", width: 20 },
      { header: "Completed At", key: "completedAt", width: 20 },
      { header: "Is Late", key: "isLate", width: 10 },
      { header: "Review Status", key: "reviewStatus", width: 15 },
      { header: "Delay Reason", key: "delayReason", width: 25 }
    ];

    // --------------------------
    // Add rows
    // --------------------------
    tasks.forEach(task => {
      worksheet.addRow({
        task_id: task.task_id,
        projectId: task.projectId,
        projectName: task.projectName,
        title: task.title,
        description: task.description,
        status: task.status,
        priority: task.priority,
        assignedTo: memberMap[task.assignedTo] || task.assignedTo,
        assignedBy: task.assignedBy,
        deadline: formatDate(task.deadline),
        createdAt: formatDate(task.createdAt),
        completedAt: formatDate(task.completedAt),
        isLate: task.isLate ? "Yes" : "No",
        reviewStatus: task.reviewStatus || "",
        delayReason: task.delayReason || ""
      });
    });

    // --------------------------
    // Send file as response
    // --------------------------
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename=tasks_${Date.now()}.xlsx`
    );

    await workbook.xlsx.write(res);
    res.end();

  } catch (error) {
    console.error("Error exporting tasks:", error);
    res.status(500).json({ message: "Error generating Excel file" });
  }
};
// exports.getTasksByMemberIdAndProjectId = async (req, res) => {
//   const { memberId, projectId } = req.params;
 
//   try {
//     // Step 1: Check if memberId and projectId are provided
//     if (!memberId || !projectId) {
//       return res.status(400).json({ message: "memberId and projectId are required" });
//     }

//     // Step 2: Fetch tasks for the given memberId and projectId
//     const tasks = await Task.find({
//       assignedTo: memberId,
//       projectId,
//       isDeleted: false
//     })
//       .populate('bugIds', 'title description') // Specify only necessary fields
//       .lean()
//       .sort({ createdAt: -1 });

//     if (!tasks.length) {
//       return res.status(404).json({ message: "No tasks found for this member in this project" });
//     }

//     // Step 3: Fetch all teams and build memberId to details map
//     const teams = await Team.find({ projectId, isDeleted: false }).lean();
//     const memberMap = {};

//     teams.forEach(team => {
//       team.teamMembers.forEach(member => {
//         memberMap[member.memberId] = {
//           _id: member._id,
//           memberId: member.memberId,
//           memberName: member.memberName,
//           email: member.email,
//           role: member.role
//         };
//       });
//     });

//     // Step 4: Enrich each task with assignedToDetails (member details)
//     const enrichedTasks = tasks.map(task => {
//       const memberInfo = memberMap[task.assignedTo] || { 
//         _id: null, 
//         memberId: task.assignedTo, 
//         memberName: 'Unknown', 
//         email: 'Unknown', 
//         role: 'Unknown' 
//       };

//       return {
//         ...task,
//         assignedToDetails: memberInfo // Assign the whole member details object
//       };
//     });

//     // Step 5: Send enriched tasks in response
//     res.status(200).json({
//       success: true,
//       data: enrichedTasks
//     });
 
//   } catch (error) {
//     console.error("Error fetching tasks by memberId and projectId:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server Error",
//       error: error.message
//     });
//   }
// };



exports.getTasksByMemberIdAndProjectId = async (req, res) => {

  const { memberId, projectId } = req.params;
 
  try {

    // 1️⃣ Validate params

    if (!memberId || !projectId) {

      return res.status(400).json({ message: "memberId and projectId are required" });

    }
 
    // 2️⃣ Fetch tasks assigned to this member under the given project

    const tasks = await Task.find({

      assignedTo: memberId,

      projectId,

      isDeleted: false

    })

      .lean()

      .sort({ createdAt: -1 });
 
    if (!tasks.length) {

      return res.status(404).json({ message: "No tasks found for this member in this project" });

    }
 
    // 3️⃣ Fetch all teams and build a member details map

    const teams = await Team.find({ projectId, isDeleted: false }).lean();

    const memberMap = {};
 
    teams.forEach(team => {

      team.teamMembers.forEach(member => {

        memberMap[member.memberId] = {

          _id: member._id,

          memberId: member.memberId,

          memberName: member.memberName,

          email: member.email,

          role: member.role

        };

      });

    });
 
    // 4️⃣ Fetch all bugs for this project

    const allBugs = await Bug.find({ projectId }).sort({ createdAt: -1 }).lean();
 
    // 5️⃣ Group bugs by taskRef

    const bugMap = {};

    allBugs.forEach(bug => {

      if (!bugMap[bug.taskRef]) bugMap[bug.taskRef] = [];

      bugMap[bug.taskRef].push(bug);

    });
 
    // 6️⃣ Enrich each task

    const enrichedTasks = tasks.map(task => {

      const memberInfo = memberMap[task.assignedTo] || {

        _id: null,

        memberId: task.assignedTo,

        memberName: "Unknown",

        email: "Unknown",

        role: "Unknown"

      };
 
      const taskBugs = bugMap[task.task_id] || [];
 
      // 🧠 Determine bug resolution status

      const isResolved = taskBugs.length === 0

        ? true

        : taskBugs.every(

            b => b.status.toLowerCase() === "resolved" || b.status.toLowerCase() === "closed"

          );
 
      return {

        ...task,

        assignedToDetails: memberInfo,

        bugs: taskBugs.map(bug => ({

          _id: bug._id,

          bug_id: bug.bug_id,

          title: bug.title,

          description: bug.description,

          taskRef: bug.taskRef,

          assignedTo: bug.assignedTo,

          projectId: bug.projectId,

          deadline: bug.deadline,

          priority: bug.priority,

          status: bug.status,

          attachment: bug.attachment || null,

          createdAt: bug.createdAt

        })),

        isResolved // ✅ true/false based on bug status

      };

    });
 
    // 7️⃣ Send response

    res.status(200).json({

      success: true,

      data: enrichedTasks

    });
 
  } catch (error) {

    console.error("Error fetching tasks by memberId and projectId:", error);

    res.status(500).json({

      success: false,

      message: "Server Error",

      error: error.message

    });

  }

};

 