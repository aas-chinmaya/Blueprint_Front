const Meet = require("../../Model/MeetModel/Meet");



// exports.createMeeting = async (req, res) => {
//   try {
//     // Ensure meetingStatus defaults to "scheduled" if not provided
//     const meetingData = {
//       ...req.body,
//       meetingStatus: req.body.meetingStatus || "scheduled",
//     };

//     const meeting = new Meet(meetingData);

//     // Add initial history entry
//     meeting.history.push({
//       action: meeting.meetingStatus, // logs actual status (e.g., scheduled)
//       data: { ...meeting.toObject() },
//     });

//     const savedMeeting = await meeting.save();

//     res.status(201).json({
//       message: "Meeting created successfully",
//       meeting: savedMeeting,
//     });
//   } catch (error) {
//     console.error("Error creating meeting:", error);
//     res.status(500).json({
//       message: "Error creating meeting",
//       error: error.message,
//     });
//   }
// };

const {sendEmail}=require("../../middlewares/nodemailer")
const { scheduleMeetingReminder } = require("../../middlewares/reminderScheduler");
 exports.createMeeting = async (req, res) => {
  try {
    const meetingData = {
      ...req.body,
      meetingStatus: req.body.meetingStatus || "scheduled",
    };
 
    const meeting = new Meet(meetingData);
    meeting.history.push({
      action: meeting.meetingStatus,
      data: { ...meeting.toObject() },
    });
 
    const savedMeeting = await meeting.save();
 
    // Prepare recipients
    let recipients = [];
 
    // Our Party emails
    if (savedMeeting.ourParty?.length > 0) {
      recipients = savedMeeting.ourParty
        .map(p => p.email)
        .filter(Boolean);
    }
 
    // Contact Party emails
    if (savedMeeting.contactParty?.length > 0) {
      const contactEmails = savedMeeting.contactParty
        .map(c => c.email)
        .filter(Boolean);
      recipients = [...recipients, ...contactEmails];
    }
 
    // Fallback: request email
    if (recipients.length === 0 && req.body.email) {
      recipients.push(req.body.email);
    }
 
    // Send initial meeting creation email
//     const subject = `📅 Meeting Scheduled: ${savedMeeting.title}`;
//     const htmlBody = `
// <html>
// <body style="font-family: Arial, sans-serif; color: #333;">
// <h2 style="color: #0073e6;">Meeting Scheduled Successfully!</h2>
// <p><strong>Title:</strong> ${savedMeeting.title}</p>
// <p><strong>Date:</strong> ${new Date(savedMeeting.date).toLocaleDateString()}</p>
// <p><strong>Start Time:</strong> ${savedMeeting.startTime}</p>
// <p><strong>End Time:</strong> ${savedMeeting.endTime}</p>
// <p><strong>Mode:</strong> ${savedMeeting.mode}</p>
//           ${
//             savedMeeting.mode === "online"
//               ? `<p><strong>Link:</strong> <a href="${savedMeeting.meetingLink}" target="_blank">${savedMeeting.meetingLink}</a></p>`
//               : ""
//           }
// <p><strong>Reminder Times:</strong> 5m, 10m, 15m, 30m, 45m, 50m before meeting start.</p>
// </body>
// </html>
//     `;

const subject = `📅 Meeting Scheduled: ${savedMeeting.title}`;
 
const htmlBody = `
<div style="font-family: Arial, sans-serif; max-width: 650px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px; background-color: #ffffff;">
<!-- Header -->
<div style="text-align: center; margin-bottom: 20px;">
<img src="https://aas.technology/assets/aaslogo.png" alt="AAS International Logo" style="max-width: 150px; margin-bottom: 10px;">
<h2 style="color: #333; margin-bottom: 5px;">Meeting Scheduled Successfully</h2>
<p style="color: #777; font-size: 14px;">Organized by AAS International</p>
</div>
 
  <!-- Meeting Info -->
<div style="background-color: #f9f9f9; padding: 20px; border-left: 5px solid #AF9A57; border-radius: 4px;">
<h3 style="color: #AF9A57; margin-top: 0;">Meeting Details</h3>
<p style="color: #555; margin: 5px 0;"><strong>Title:</strong> ${savedMeeting.title}</p>
<p style="color: #555; margin: 5px 0;"><strong>Agenda:</strong> ${savedMeeting.agenda || "Not specified"}</p>
<p style="color: #555; margin: 5px 0;"><strong>Date:</strong> ${new Date(savedMeeting.date).toLocaleDateString()}</p>
<p style="color: #555; margin: 5px 0;"><strong>Start Time:</strong> ${savedMeeting.startTime}</p>
<p style="color: #555; margin: 5px 0;"><strong>End Time:</strong> ${savedMeeting.endTime}</p>
<p style="color: #555; margin: 5px 0;"><strong>Mode:</strong> ${savedMeeting.mode}</p>

    ${

      savedMeeting.mode === "online"

        ? `
<p style="color: #555; margin: 5px 0;"><strong>Meeting Link:</strong></p>
<div style="text-align: center; margin-top: 10px;">
<a href="${savedMeeting.meetingLink}" target="_blank" 

            style="background-color: #AF9A57; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">

            Join Meeting
</a>
</div>`

        : ""

    }
<p style="color: #555; margin: 10px 0;"><strong>Reminder Times:</strong> 5m, 10m, 15m, 30m, 45m, and 50m before meeting start.</p>
</div>
 
  <!-- Info -->
<div style="margin-top: 25px; padding: 15px; background-color: #f9f9f9; border-left: 4px solid #AF9A57; border-radius: 3px;">
<p style="margin: 0; color: #666;">If you have questions or need assistance, please contact our Bhubaneswar office:</p>
<p style="margin: 5px 0; color: #666;">Phone: <a href="tel:+916742571111" style="color: #AF9A57; text-decoration: none;">+91 6742571111</a></p>
<p style="margin: 5px 0; color: #666;">Email: <a href="mailto:contact@aasint.com" style="color: #AF9A57; text-decoration: none;">contact@aasint.com</a></p>
<p style="margin: 5px 0; color: #666;">Address: Plot 52, 2nd Floor, Bapuji Nagar, Bhubaneswar</p>
</div>
 
  <!-- Footer -->
<div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; text-align: center; font-size: 12px; color: #999;">
<p>© ${new Date().getFullYear()} AAS International Pvt. Ltd. All rights reserved.</p>
<div style="margin-top: 10px;">
<a href="https://facebook.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Facebook</a> |
<a href="https://twitter.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Twitter</a> |
<a href="https://linkedin.com/company/aasinternational" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">LinkedIn</a> |
<a href="https://www.youtube.com/channel/UCPgsMheOi91WOsLnMn9LCmg" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">YouTube</a>
</div>
</div>
</div>

`;

 
 
    if (recipients.length > 0) {
      await sendEmail(subject, htmlBody, recipients);
    }
 
    // Schedule all reminders
    await scheduleMeetingReminder(savedMeeting, recipients);
 
    res.status(201).json({
      success: true,
      message: "Meeting created successfully and reminders scheduled",
      meeting: savedMeeting,
    });
  } catch (error) {
    console.error("❌ Error creating meeting:", error);
    res.status(500).json({
      success: false,
      message: "Error creating meeting",
      error: error.message,
    });
  }
};
// exports.createMeeting = async (req, res) => {
//   try {
//     const meetingData = {
//       ...req.body,
//       meetingStatus: req.body.meetingStatus || "scheduled",
//     };
 
//     const meeting = new Meet(meetingData);
//     meeting.history.push({
//       action: meeting.meetingStatus,
//       data: { ...meeting.toObject() },
//     });
 
//     const savedMeeting = await meeting.save();
 
//     // Prepare recipients list (for now, use the email from request or ourParty if populated)
//     let recipients = [];
//     if (savedMeeting.ourParty && savedMeeting.ourParty.length > 0) {
//       recipients = savedMeeting.ourParty.map(p => p.email).filter(Boolean);
//     }
//     if (recipients.length === 0 && req.body.email) {
//       recipients.push(req.body.email);
//     }
 
//     // Send initial meeting creation mail
//     const subject = `📅 Meeting Scheduled: ${savedMeeting.title}`;
//     const htmlBody = `
//       <html>
//         <body style="font-family: Arial, sans-serif; color: #333;">
//           <h2 style="color: #0073e6;">Meeting Scheduled Successfully!</h2>
//           <p><strong>Title:</strong> ${savedMeeting.title}</p>
//           <p><strong>Date:</strong> ${new Date(savedMeeting.date).toLocaleDateString()}</p>
//           <p><strong>Start Time:</strong> ${savedMeeting.startTime}</p>
//           <p><strong>Mode:</strong> ${savedMeeting.mode}</p>
//           ${
//             savedMeeting.mode === "online"
//               ? `<p><strong>Link:</strong> <a href="${savedMeeting.meetingLink}">${savedMeeting.meetingLink}</a></p>`
//               : ""
//           }
//           <p><strong>Reminder:</strong> ${savedMeeting.reminder}</p>
//         </body>
//       </html>
//     `;
 
//     if (recipients.length > 0) {
//       await sendEmail(subject, htmlBody, recipients);
//     }
 
//     // Schedule the reminder email
//     await scheduleMeetingReminder(savedMeeting, recipients);
 
//     res.status(201).json({
//       success: true,
//       message: "Meeting created successfully and reminder scheduled",
//       meeting: savedMeeting,
//     });
//   } catch (error) {
//     console.error("❌ Error creating meeting:", error);
//     res.status(500).json({
//       success: false,
//       message: "Error creating meeting",
//       error: error.message,
//     });
//   }
// };









// Get all meetings (optional filter by mode or date)
exports.getAllMeetings = async (req, res) => {
  try {
    const { mode, date } = req.query;
    const filter = {};
    if (mode) filter.mode = mode;
    if (date) filter.date = new Date(date);

    const meetings = await Meet.find(filter).sort({ createdAt: -1 });
    res.status(200).json(meetings);
  } catch (error) {
    console.error(" Error fetching meetings:", error);
    res.status(500).json({ message: "Error fetching meetings", error: error.message });
  }
};

// Get a single meeting by ID
exports.getMeetingById = async (req, res) => {
  try {
    const meeting = await Meet.findOne({ meetingId: req.params.meetingId });
    if (!meeting) return res.status(404).json({ message: "Meeting not found" });
    res.status(200).json(meeting);
  } catch (error) {
    console.error(" Error fetching meeting:", error);
    res.status(500).json({ message: "Error fetching meeting", error: error.message });
  }
};

// Update meeting details
// exports.updateMeeting = async (req, res) => {
//   try {
//     const meeting = await Meet.findOneAndUpdate(
//       { meetingId: req.params.meetingId },
//       req.body,
//       { new: true }
//     );
//     if (!meeting) return res.status(404).json({ message: "Meeting not found" });
//     res.status(200).json({ message: " Meeting updated successfully", meeting });
//   } catch (error) {
//     console.error(" Error updating meeting:", error);
//     res.status(500).json({ message: "Error updating meeting", error: error.message });
//   }
// };

// exports.updateMeeting = async (req, res) => {
//   try {
//     const existingMeeting = await Meet.findOne({ meetingId: req.params.meetingId });
//     if (!existingMeeting) return res.status(404).json({ message: "Meeting not found" });

//     // Update fields
//     Object.assign(existingMeeting, req.body);

//     // Recalculate duration if times changed
//     if (req.body.startTime || req.body.endTime) {
//       const [sh, sm] = existingMeeting.startTime.split(":").map(Number);
//       const [eh, em] = existingMeeting.endTime.split(":").map(Number);
//       const duration = (eh * 60 + em) - (sh * 60 + sm);
//       existingMeeting.duration = duration >= 0 ? duration : 0;
//     }

//     // Push update history snapshot
//     existingMeeting.history.push({
//       action: "updated",
//       data: { ...existingMeeting.toObject() },
//     });

//     const updatedMeeting = await existingMeeting.save();

//     res.status(200).json({
//       message: "Meeting updated successfully",
//       meeting: updatedMeeting,
//     });
//   } catch (error) {
//     console.error("Error updating meeting:", error);
//     res.status(500).json({ message: "Error updating meeting", error: error.message });
//   }
// };

exports.updateMeeting = async (req, res) => {
  try {
    const existingMeeting = await Meet.findOne({ meetingId: req.params.meetingId });
    if (!existingMeeting) return res.status(404).json({ message: "Meeting not found" });

    // Update fields safely
    Object.assign(existingMeeting, req.body);

    // Recalculate duration only if valid start & end times exist
    const { startTime, endTime } = existingMeeting;

    if (startTime && endTime) {
      const [sh, sm] = startTime.split(":").map(Number);
      const [eh, em] = endTime.split(":").map(Number);

      const duration = (eh * 60 + em) - (sh * 60 + sm);
      existingMeeting.duration = duration >= 0 ? duration : 0;
    }

    // Add update history snapshot
    existingMeeting.history.push({
      action: "updated",
      data: { ...existingMeeting.toObject() },
      updatedAt: new Date(),
    });

    const updatedMeeting = await existingMeeting.save();

    res.status(200).json({
      message: "Meeting updated successfully",
      meeting: updatedMeeting,
    });
  } catch (error) {
    console.error("Error updating meeting:", error);
    res.status(500).json({ message: "Error updating meeting", error: error.message });
  }
};





// Delete a meeting
exports.deleteMeeting = async (req, res) => {
  try {
    const meeting = await Meet.findOneAndDelete({ meetingId: req.params.meetingId });
    if (!meeting) return res.status(404).json({ message: "Meeting not found" });
    res.status(200).json({ message: "Meeting deleted successfully" });
  } catch (error) {
    console.error(" Error deleting meeting:", error);
    res.status(500).json({ message: "Error deleting meeting", error: error.message });
  }
};

// Get all meetings by contactId
exports.getMeetingsByContactId = async (req, res) => {
  try {
    const { contactId } = req.params;

    if (!contactId) {
      return res.status(400).json({ message: " contactId is required" });
    }

    const meetings = await Meet.find({ contactId }).sort({ createdAt: -1 });

    if (!meetings || meetings.length === 0) {
      return res.status(404).json({ message: "No meetings found for this contactId" });
    }

    res.status(200).json({
      message: " Meetings fetched successfully",
      count: meetings.length,
      meetings,
    });
  } catch (error) {
    console.error("Error fetching meetings by contactId:", error);
    res.status(500).json({
      message: "Error fetching meetings by contactId",
      error: error.message,
    });
  }
};



exports.updateMeetingStatus = async (req, res) => {
  try {
    const { meetingId } = req.params;
    const { meetingStatus, endNote } = req.body;

    // Find existing meeting by meetingId
    const meeting = await Meet.findOne({ meetingId });
    if (!meeting) {
      return res.status(404).json({ message: "Meeting not found" });
    }

    let historyAction = "";

    // 1️⃣ Update meeting status if provided
    if (meetingStatus && meetingStatus !== meeting.meetingStatus) {
      meeting.meetingStatus = meetingStatus;
      historyAction = meetingStatus; // e.g., "rescheduled", "completed", etc.
    }

    // 2️⃣ Update end note if provided
    if (endNote) {
      meeting.endNote = endNote;
      // If only endNote is changed and not status, mark action as "updated"
      if (!historyAction) historyAction = "updated";
    }

    if (!historyAction) {
      return res.status(400).json({ message: "No valid updates provided" });
    }

    // Push to history with full snapshot
    meeting.history.push({
      action: historyAction,
      data: { ...meeting.toObject() },
    });

    const updatedMeeting = await meeting.save();

    res.status(200).json({
      message: `Meeting ${historyAction} successfully`,
      meeting: updatedMeeting,
    });
  } catch (error) {
    console.error("Error updating meeting status:", error);
    res.status(500).json({
      message: "Error updating meeting status",
      error: error.message,
    });
  }
};

