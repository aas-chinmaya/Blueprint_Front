// const mongoose = require('mongoose');
 
// const contactSchema = new mongoose.Schema({
//  contactId:{type: String, unique: true},
//   fullName: { type: String, required: true },
//   email: { type: String, required: true },
//   phone: { type: String, required: true },
//   companyName: { type: String, required: true },
//   designation: { type: String }, //  New field added here
//   industry: { type: String },
//   location: { type: String },
//  Companylocation: { type: String },
//   serviceInterest: [{ type: String }],
//   referralSource: { type: String },
//   message: { type: String, required: true },
//   status: { type: String, enum: ['Pending', 'Accepted', 'Rejected'], default: 'Pending' },
//   internalNotes: { type: String },
//   assignedAdmin: { type: String },
//   feedback: { type: String },
//    isDeleted: { type: Boolean, default: false },
 
// }, { timestamps: true });
 
// module.exports = mongoose.model('Contact', contactSchema);







//last file
// const mongoose = require('mongoose');
 
// const contactSchema = new mongoose.Schema(
//   {
//     // Auto-generated unique contact ID
//     contactId: { type: String, unique: true },
 
//     //  Mandatory fields
//     fullName: { type: String, required: true, trim: true },
//     email: { type: String, required: true, trim: true, lowercase: true },
//     phone: { type: String, required: true, trim: true },
//     companyName: { type: String, trim: true },
//     brandCategory: { type: String,  trim: true }, // New mandatory field
//     sourceDomain: { type: String, required: true, trim: true },
 
//     //  Optional business/contact info
//     designation: { type: String, trim: true }, // Job title or designation
//     jobTitleOrRole: { type: String, trim: true }, // Duplicate kept for flexibility
//     industry: { type: String, trim: true },
//     organizationName: { type: String, trim: true },
//     location: { type: String, trim: true },
//     addressLocation: { type: String, trim: true },
//     Companylocation: { type: String, trim: true },
 
//     //  Communication details
//     serviceInterest: [{ type: String, trim: true }],
//     referralSource: { type: String, trim: true },
//     inquirySource: { type: String, trim: true },
//     message: { type: String, required: true, trim: true },
//     requirementSummary: { type: String, trim: true },
//     feedback: { type: String, trim: true },
//     internalNotes: { type: String, trim: true },
 
//     //  CRM status (merged enum values)
//     status: {
//       type: String,
//       enum: [
  
//         'Contact Received',
//         'Conversion Made',
//         'Follow-up Taken',
//         'Converted to Lead',
//         "Ready for Meeting",
//         'Closed',
//       ],
//       default: 'Contact Received',
//     },
 
//     //  Assigned admin
//     assignedAdmin: { type: String, trim: true },
 
//     //  Conversation / follow-up history
//     // conversations: [
//     //   {
//     //     note: { type: String,  trim: true },
//     //     recordedBy: { type: String,  trim: true },
//     //     timestamp: { type: Date, default: Date.now },
//     //   },
//     // ],
//       conversations: [
//       {
//         status: { type: String, trim: true },
//         feedback: { type: String, trim: true },
//         timestamp: { type: Date, default: Date.now },
//       },
//     ],
 
//     // Soft delete flag
//     isDeleted: { type: Boolean, default: false },
//   },
//   {
//     timestamps: true, // Automatically adds createdAt & updatedAt
//   }
// );
 
// module.exports = mongoose.model('Contact', contactSchema);




//last file updated with minor changes
const mongoose = require('mongoose');
 
const contactSchema = new mongoose.Schema(
  {
    // Auto-generated unique contact ID
    contactId: { type: String, unique: true },
 
    //  Mandatory fields
    fullName: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true, lowercase: true },
    phone: { type: String, required: true, trim: true },
    companyName: { type: String, trim: true },
    brandCategory: { type: String,  trim: true }, // New mandatory field
    sourceDomain: { type: String, required: true, trim: true },
 
    //  Optional business/contact info
    designation: { type: String, trim: true }, // Job title or designation
    jobTitleOrRole: { type: String, trim: true }, // Duplicate kept for flexibility
    industry: { type: String, trim: true },
    organizationName: { type: String, trim: true },
    location: { type: String, trim: true },
    addressLocation: { type: String, trim: true },
    Companylocation: { type: String, trim: true },
     internalNotes: { type: String, trim: true },
    //  Communication details
    serviceInterest: [{ type: String, trim: true }],
    referralSource: { type: String, trim: true },
    inquirySource: { type: String, trim: true },
    message: { type: String, required: true, trim: true },
    requirementSummary: { type: String, trim: true },
    feedback: { type: String, trim: true },
    
    hostedDomain: {
         type: String,
          trim: true,
       },
    //  CRM status (merged enum values)
    status: {
      type: String,
      enum: [
 
        'Contact Received',
        'Conversion Made',
        'Follow-up Taken',
        'Converted to Lead',
        "Ready for Meeting",
        'Closed',
      ],
      default: 'Contact Received',
    },
 
    //  Assigned admin
    assignedAdmin: { type: String, trim: true },
 
    //  Conversation / follow-up history
    // conversations: [
    //   {
    //     note: { type: String,  trim: true },
    //     recordedBy: { type: String,  trim: true },
    //     timestamp: { type: Date, default: Date.now },
    //   },
    // ],
      conversations: [
      {
        status: { type: String, trim: true },
        feedback: { type: String, trim: true },
        timestamp: { type: Date, default: Date.now },
        internalNotes: { type: String, trim: true },
        actionedBy: {
      employeeId: { type: String, trim: true },
      name: { type: String, trim: true },
      role: { type: String, trim: true },
    },
 
      },
    ],
       
 
    // Soft delete flag
    isDeleted: { type: Boolean, default: false },
  },
  {
    timestamps: true, // Automatically adds createdAt & updatedAt
  }
);
 
module.exports = mongoose.model('Contact', contactSchema);