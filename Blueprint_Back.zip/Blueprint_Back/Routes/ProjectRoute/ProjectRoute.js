
const express = require('express');
const multer = require('multer');
const {getProjectSummary,softDeleteProjectById,getEmployeeProjectSummary,getNearEndingProjects,getTeamEmailsByProjectAndLead,getProjectsWithTasks,getAllProjectsByEmployeeOrLeadId,getReview,submitReview,updateProject,getAllProjectsByTeamLeadId,getAllProjectsWithTeams,createProject ,getAllProjects ,downloadFile, getProjectById, getAllProjectsByClientId ,updateProjectStatusById} = require('../../Controller/ProjectController/ProjectController');
 
const router = express.Router();
const validateToken=require("../../middlewares/authMiddleware")
 
// Multer configuration (to store files in memory)
const storage = multer.memoryStorage();
const upload = multer({ storage });
 
// // POST: Onboard a Project
router.post('/onboard', upload.array('attachments', 10),validateToken, createProject);
 
router.get('/getallprojects',getAllProjects);
 
router.get('/downloadfile/:projectId/:fileIndex',validateToken, downloadFile);
 
router.get('/getProjectById/:projectId',validateToken, getProjectById );
 
router.get('/getallprojectsbyclientid/:clientId', validateToken,getAllProjectsByClientId);
 
 router.get('/getall/:teamLeadId',validateToken, getAllProjectsByTeamLeadId);
 
 router.put('/status/:projectId',validateToken, updateProjectStatusById);
 router.get('/by-person/:id',validateToken, getAllProjectsByEmployeeOrLeadId);
router.get('/getallprojectswithallteams', validateToken,getAllProjectsWithTeams);
 
// Route to update project

// router.put('/updateproject/:projectId', validateToken,updateProject);
router.put('/updateproject/:projectId',validateToken, upload.any(), updateProject);


router.put('/updateproject/:projectId', validateToken,updateProject);
 

// Submit review by Team Lead
router.post('/sendreview/:projectId',validateToken, submitReview);
 
// View review (e.g. CPC)
router.get('/getreview/:projectId',validateToken, getReview);
     
 
router.get('/projectswithtasks', validateToken,getProjectsWithTasks);
 
router.get('/near-ending', validateToken,getNearEndingProjects);
router.get('/emails/:projectId/:teamLeadId',validateToken, getTeamEmailsByProjectAndLead);
router.post('/soft-delete/:projectId',validateToken, softDeleteProjectById);
router.get('/analytics/:projectId', getProjectSummary);
router.get('/analytics/:projectId/:employeeId', getEmployeeProjectSummary);
module.exports = router;
 