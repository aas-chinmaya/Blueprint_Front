const express = require("express");
const router = express.Router();
const budgetAccountController = require("../../Controller/BudgetController/budgetAccountController");

// Budget Account Routes
router.post("/createBudgetAccount/:projectId", budgetAccountController.createBudgetAccount);

// router.get("/:id", budgetController.getBudgetAccountById);
// Fetch all accounts for a project
router.get("/fetchBudgetAccountById/:accountId", budgetAccountController.getBudgetAccountById);

// Fetch single account by accountId
router.get("/fetchBudgetAccountsByProject/:projectId", budgetAccountController.fetchBudgetAccountsByProject);

// Add budget allocation (transaction)
router.post("/addBudgetAllocation/:accountId", budgetAccountController.addBudgetAllocation);

// Soft delete a transaction
router.delete("/deleteTransaction/:accountId/:txnId", budgetAccountController.softDeleteTransaction);

// Soft delete a budget account
router.delete("/deleteBudgetAccount/:accountId", budgetAccountController.softDeleteBudgetAccount);



module.exports = router;
