
// const mongoose = require("mongoose");

// const meetingSchema = new mongoose.Schema(
//   {
//     meetingId: {
//       type: String,
//       unique: true,
//       trim: true,
//     },
//     title: {
//       type: String,
//       required: true,
//       trim: true,
//     },
//     agenda: {
//       type: String,
//       trim: true,
//     },
//     date: {
//       type: Date,
//       required: true,
//     },
//     startTime: {
//       type: String,
//       required: true,
//     },
//     endTime: {
//       type: String,
//       required: true,
//     },
//     duration: {
//       type: Number, // in minutes
//     },
//     mode: {
//       type: String,
//       enum: ["online", "offline"],
//       required: true,
//     },
//     meetingStatus: {
//       default:"scheduled",
//       type: String,
//       enum: ["scheduled","rescheduled", "canceled","completed"],
//       required: true,
//     },
//     meetingLink: {
//       type: String,
//       trim: true,
//       validate: {
//         validator: function (value) {
//           if (this.mode === "online") {
//             return !!value;
//           }
//           return true;
//         },
//         message: "Meeting link is required for online meetings.",
//       },
//     },
//     endNote: {
//       type: String,
//       trim: true,
//     },

//     // Linked references (text form)
//     contactId: { type: String, trim: true },
//     momId: { type: String, trim: true },
//     quotationId: { type: String, trim: true },

//     // ⏳ History array — store all past versions here
//     history: [
//       {
//         updatedAt: { type: Date, default: Date.now },
//         action: { type: String, enum: ["scheduled","rescheduled", "canceled","completed","updated"], required: true },
//         data: { type: Object, required: true }, // full snapshot of the meeting data
//       },
//     ],
//   },
//   { timestamps: true }
// );

// // Auto-calculate duration
// meetingSchema.pre("save", function (next) {
//   if (this.startTime && this.endTime) {
//     const [sh, sm] = this.startTime.split(":").map(Number);
//     const [eh, em] = this.endTime.split(":").map(Number);
//     const duration = (eh * 60 + em) - (sh * 60 + sm);
//     this.duration = duration >= 0 ? duration : 0;
//   }
//   next();
// });

// // Auto-generate Meeting ID
// meetingSchema.pre("save", async function (next) {
//   if (this.meetingId) return next();

//   const lastMeeting = await mongoose.models.Meet.findOne({})
//     .sort({ createdAt: -1 })
//     .select("meetingId");

//   let nextNumber = 1;
//   if (lastMeeting && lastMeeting.meetingId) {
//     const match = lastMeeting.meetingId.match(/\d+$/);
//     if (match) nextNumber = parseInt(match[0]) + 1;
//   }

//   this.meetingId = `meetingid${nextNumber}`;
//   next();
// });

// module.exports = mongoose.model("Meet", meetingSchema);




// const mongoose = require("mongoose");
 
// const meetingSchema = new mongoose.Schema(
//   {
//     meetingId: {
//       type: String,
//       unique: true,
//       trim: true,
//     },
//     title: {
//       type: String,
//       required: true,
//       trim: true,
//     },
//     agenda: {
//       type: String,
//       trim: true,
//     },
//     date: {
//       type: Date,
//       required: true,
//     },
//     startTime: {
//       type: String,
//       required: true,
//     },
//     endTime: {
//       type: String,
//       required: true,
//     },
//     duration: {
//       type: Number, // in minutes
//     },
//     mode: {
//       type: String,
//       enum: ["online", "offline"],
//       required: true,
//     },
//     meetingStatus: {
//       default:"scheduled",
//       type: String,
//       enum: ["scheduled","rescheduled", "canceled","completed"],
//       required: true,
//     },
//     meetingLink: {
//       type: String,
//       trim: true,
//       validate: {
//         validator: function (value) {
//           if (this.mode === "online") {
//             return !!value;
//           }
//           return true;
//         },
//         message: "Meeting link is required for online meetings.",
//       },
//     },
//     endNote: {
//       type: String,
//       trim: true,
//     },
 
//     // Linked references (text form)
//     contactId: { type: String, trim: true },
//     momId: { type: String, trim: true },
//     quotationId: { type: String, trim: true },
 
//     // History array — store all past versions here
//     history: [
//       {
//         updatedAt: { type: Date, default: Date.now },
//         action: { type: String, enum: ["scheduled","rescheduled", "canceled","completed","updated"], required: true },
//         data: { type: Object, required: true }, // full snapshot of the meeting data
//       },
//     ],
//       ourParty: [
//       {
//         userId:{type:String},
//         role: {
//           type: String,
//           enum: ["Organizer", "Co-Organizer"],
//           default: "Organizer",
//         },
//       },
//     ],
 
// reminder: {
//   type: String,
//   enum: ["5m", "10m", "15m", "30m", "45m", "50m", "None"],
//   default: "15m",
// },
 
 
 
//   },
//   { timestamps: true }
// );
 
// // Auto-calculate duration
// meetingSchema.pre("save", function (next) {
//   if (this.startTime && this.endTime) {
//     const [sh, sm] = this.startTime.split(":").map(Number);
//     const [eh, em] = this.endTime.split(":").map(Number);
//     const duration = (eh * 60 + em) - (sh * 60 + sm);
//     this.duration = duration >= 0 ? duration : 0;
//   }
//   next();
// });
 
// // Auto-generate Meeting ID
// meetingSchema.pre("save", async function (next) {
//   if (this.meetingId) return next();
 
//   const lastMeeting = await mongoose.models.Meet.findOne({})
//     .sort({ createdAt: -1 })
//     .select("meetingId");
 
//   let nextNumber = 1;
//   if (lastMeeting && lastMeeting.meetingId) {
//     const match = lastMeeting.meetingId.match(/\d+$/);
//     if (match) nextNumber = parseInt(match[0]) + 1;
//   }
 
//   this.meetingId = `meetingid${nextNumber}`;
//   next();
// });
 
// module.exports = mongoose.model("Meet", meetingSchema);













const mongoose = require("mongoose");
 
const meetingSchema = new mongoose.Schema(
  {
    meetingId: {
      type: String,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    agenda: {
      type: String,
      trim: true,
    },
    date: {
      type: Date,
      required: true,
    },
    startTime: {
      type: String,
      required: true,
    },
    endTime: {
      type: String,
      required: true,
    },
    duration: {
      type: Number, // in minutes
    },
    mode: {
      type: String,
      enum: ["online", "offline"],
      required: true,
    },
    meetingStatus: {
      default:"scheduled",
      type: String,
      enum: ["scheduled","rescheduled", "canceled","completed"],
      required: true,
    },
    meetingLink: {
      type: String,
      trim: true,
      validate: {
        validator: function (value) {
          if (this.mode === "online") {
            return !!value;
          }
          return true;
        },
        message: "Meeting link is required for online meetings.",
      },
    },
    endNote: {
      type: String,
      trim: true,
    },
 
    // Linked references (text form)
    contactId: { type: String, trim: true },
    momId: { type: String, trim: true },
    quotationId: { type: String, trim: true },
 
    // History array — store all past versions here
    history: [
      {
        updatedAt: { type: Date, default: Date.now },
        action: { type: String, enum: ["scheduled","rescheduled", "canceled","completed","updated"], required: true },
        data: { type: Object, required: true }, // full snapshot of the meeting data
      },
    ],
      ourParty: [
      {
        employeeID:{type:String},
        email:{type:String},
        name:{type:String},
        role: {
          type: String,
          enum: ["Organizer", "Attendee"],
          default: "Attendee",
        },

      },
    ],
      contactParty: [
    {
      contactId: { type: String },
      fullName: String,
      email: String,
      phone: String,
    },
  ],
 
reminder: {
  type: String,
  enum: ["5m", "10m", "15m", "30m", "45m", "50m", "None"],
  default: "15m",
},
   
       
 
  },
  { timestamps: true }
);
 
// Auto-calculate duration
meetingSchema.pre("save", function (next) {
  if (this.startTime && this.endTime) {
    const [sh, sm] = this.startTime.split(":").map(Number);
    const [eh, em] = this.endTime.split(":").map(Number);
    const duration = (eh * 60 + em) - (sh * 60 + sm);
    this.duration = duration >= 0 ? duration : 0;
  }
  next();
});
 
// Auto-generate Meeting ID
meetingSchema.pre("save", async function (next) {
  if (this.meetingId) return next();
 
  const lastMeeting = await mongoose.models.Meet.findOne({})
    .sort({ createdAt: -1 })
    .select("meetingId");
 
  let nextNumber = 1;
  if (lastMeeting && lastMeeting.meetingId) {
    const match = lastMeeting.meetingId.match(/\d+$/);
    if (match) nextNumber = parseInt(match[0]) + 1;
  }
 
  this.meetingId = `meetingid${nextNumber}`;
  next();
});
 
module.exports = mongoose.model("Meet", meetingSchema);
 