
const Quotation = require('../../Model/QuotationModel/QuotationModel');
const generateQuotationNumber = require('../../utils/quotationNumberGenerator');
const Contact=require("../../Model/ContactModel/Contact")
 const Client=require("../../Model/ClientModel/clientModel")
const generateQuotationPDF = require('../../utils/pdfGeneratorQTN');
const { sendEmail } = require('../../middlewares/nodemailer');
const fs = require('fs');
const path = require('path');







exports.getAllQuotations = async (req, res) => {
  try {
    const quotations = await Quotation.find().sort({ createdAt: -1 });
 
    // Collect all unique client emails
    const clientEmails = quotations
      .map(q => q.clientDetails?.email)
      .filter(email => email); // Remove undefined/null
 
    const uniqueEmails = [...new Set(clientEmails)];
 
    // Fetch all contacts matching these emails
    const contacts = await Contact.find({ email: { $in: uniqueEmails } });
 
    // Map contacts by email for easy lookup
    const contactMap = {};
    contacts.forEach(contact => {
      contactMap[contact.email] = contact;
    });
 
    // Attach matching contact to each quotation
    const enrichedQuotations = quotations.map(q => ({
      ...q._doc,
      contactDetails: contactMap[q.clientDetails?.email] || null
    }));
 
    res.status(200).json(enrichedQuotations);
  } catch (error) {
    console.error('Error fetching quotations with contact details:', error);
    res.status(500).json({ error: error.message });
  }
};


exports.getQuotationByNumber = async (req, res) => {

  try {

    const { quotationNumber } = req.params;
 
    const quotation = await Quotation.findOne({ quotationNumber });
 
    if (!quotation) {

      return res.status(404).json({ message: 'Quotation not found' });

    }
 
    // Extract client email from quotation

    const clientEmail = quotation.clientDetails?.email;
 
    // Fetch matching contact by email

    let contactDetails = null;

    if (clientEmail) {

      contactDetails = await Contact.findOne({ email: clientEmail });

    }
 
    // Send enriched quotation

    res.status(200).json({

      ...quotation._doc,

      contactDetails: contactDetails || null

    });
 
  } catch (error) {

    console.error('Error fetching quotation by number:', error);

    res.status(500).json({ error: error.message });

  }

};
exports.getClientStatusByQuotationId = async (req, res) => {
  try {
    const { quotationId } = req.params;
 
    // 1. Find the quotation using quotationNumber (NOT _id)
    const quotation = await Quotation.findOne({ quotationNumber: quotationId });
 
    if (!quotation) {
      return res.status(404).json({ success: false, message: 'Quotation not found' });
    }
 
    // 2. Extract client email from quotation.clientDetails.email
    const clientEmail = quotation.clientDetails?.email;
    if (!clientEmail) {
      return res.status(400).json({ success: false, message: 'Client email not found in quotation details' });
    }
 
    // 3. Look up the client using email
    const client = await Client.findOne({ contactEmail: clientEmail, isDeleted: false });
 
    // 4. Return result
    if (client) {
      return res.status(200).json({
        success: true,
        onboardStatus: client.Onboardedstatus,
        client
      });
    } else {
      return res.status(200).json({
        success: true,
        onboardStatus: 'notonboard'
      });
    }
 
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
};
 
 exports.createQuotation = async (req, res, next) => {
  try {
    const currentYear = new Date().getFullYear();
    const Status = req.body.Status || 'draft';
 
    let quotationNumber = req.body.quotationNumber;
 
    // Always generate quotation number if not provided
    if (!quotationNumber) {
      const latestQuotation = await Quotation.findOne({
        quotationNumber: new RegExp(`QTN-${currentYear}-`)
      }).sort({ quotationNumber: -1 });
 
      let newNumber = 1;
      if (latestQuotation) {
        const parts = latestQuotation.quotationNumber.split('-');
        const lastNumber = parseInt(parts[2]);
        newNumber = lastNumber + 1;
      }
 
      const formattedNumber = String(newNumber).padStart(3, '0');
      quotationNumber = `QTN-${currentYear}-${formattedNumber}`;
    }
 
    let quotation = await Quotation.findOne({ quotationNumber });
 
    const baseUrl = `${req.protocol}s://${req.get('host')}`;
 
    if (quotation) {
      // Update existing quotation
      quotation.set({ ...req.body, Status });
 
      quotation.subtotal = quotation.items.reduce((sum, item) => sum + item.sellPrice, 0);
      quotation.taxAmount = (quotation.taxPercent / 100) * quotation.subtotal;
      quotation.totalAmount = quotation.subtotal + quotation.taxAmount;
 
      quotation.pdfUrl = null;
 
      if (Status === 'final') {
        const logoPath = path.resolve(__dirname, '../../utils/logo.png');
        const logoData = fs.readFileSync(logoPath);
        const logoBase64 = `data:image/png;base64,${logoData.toString('base64')}`;
 
        const pdfBuffer = await generateQuotationPDF(quotation, logoBase64);
 
        const pdfFilename = `${quotationNumber}.pdf`;
        const pdfFolderPath = path.resolve(__dirname, '../../uploads/quotations');
        const pdfFilePath = path.join(pdfFolderPath, pdfFilename);
 
        if (!fs.existsSync(pdfFolderPath)) {
          fs.mkdirSync(pdfFolderPath, { recursive: true });
        }
 
        fs.writeFileSync(pdfFilePath, pdfBuffer);
 
        quotation.pdfUrl = `${baseUrl}/api/quotation/pdfbyqoutationnumber/${quotationNumber}`;
 
        const actionBaseUrl = `${baseUrl}/api/quotation/status/${quotationNumber}`;
        const subject = `Your Quotation - ${quotationNumber}`;
        const body = `
<p>Dear ${quotation.clientDetails.name},</p>
<p>Your quotation <strong>${quotationNumber}</strong> is ready.</p>
<p><a href="${quotation.pdfUrl}" target="_blank">📄 View Quotation</a></p>
<p>Take action below:</p>
<a href="${actionBaseUrl}?action=accept" style="background:#28a745;padding:10px 20px;color:#fff;text-decoration:none;margin-right:10px;border-radius:5px;">✔ Accept</a>
<a href="${actionBaseUrl}?action=reject" style="background:#dc3545;padding:10px 20px;color:#fff;text-decoration:none;margin-right:10px;border-radius:5px;">❌ Reject</a>
<a href="${actionBaseUrl}?action=request" style="background:#fd7e14;padding:10px 20px;color:#fff;text-decoration:none;border-radius:5px;">🔁 Request Another</a>
        `;
 
        await sendEmail(subject, body, quotation.clientDetails.email);
      }
 
      await quotation.save();
 
      return res.status(200).json({
        message: Status === 'draft'
          ? 'Quotation saved as draft'
          : 'Quotation finalized and emailed to client',
        quotationNumber,
        ...(quotation.pdfUrl && { pdfUrl: quotation.pdfUrl })
      });
 
    } else {
      // Create new quotation
      quotation = new Quotation({
        ...req.body,
        quotationNumber,
        Status
      });
 
      quotation.subtotal = quotation.items.reduce((sum, item) => sum + item.sellPrice, 0);
      quotation.taxAmount = (quotation.taxPercent / 100) * quotation.subtotal;
      quotation.totalAmount = quotation.subtotal + quotation.taxAmount;
 
      quotation.pdfUrl = null;
 
      if (Status === 'final') {
        const logoPath = path.resolve(__dirname, '../../utils/logo.png');
        const logoData = fs.readFileSync(logoPath);
        const logoBase64 = `data:image/png;base64,${logoData.toString('base64')}`;
 
        const pdfBuffer = await generateQuotationPDF(quotation, logoBase64);
 
        const pdfFilename = `${quotationNumber}.pdf`;
        const pdfFolderPath = path.resolve(__dirname, '../../uploads/quotations');
        const pdfFilePath = path.join(pdfFolderPath, pdfFilename);
 
        if (!fs.existsSync(pdfFolderPath)) {
          fs.mkdirSync(pdfFolderPath, { recursive: true });
        }
 
        fs.writeFileSync(pdfFilePath, pdfBuffer);
 
        quotation.pdfUrl = `${baseUrl}/api/quotation/pdfbyqoutationnumber/${quotationNumber}`;
 
        const actionBaseUrl = `${baseUrl}/api/quotation/status/${quotationNumber}`;
        const subject = `Your Quotation - ${quotationNumber}`;
        const body = `
<p>Dear ${quotation.clientDetails.name},</p>
<p>Your quotation <strong>${quotationNumber}</strong> is ready.</p>
<p><a href="${quotation.pdfUrl}" target="_blank">📄 View Quotation</a></p>
<p>Take action below:</p>
<a href="${actionBaseUrl}?action=accept" style="background:#28a745;padding:10px 20px;color:#fff;text-decoration:none;margin-right:10px;border-radius:5px;">✔ Accept</a>
<a href="${actionBaseUrl}?action=reject" style="background:#dc3545;padding:10px 20px;color:#fff;text-decoration:none;margin-right:10px;border-radius:5px;">❌ Reject</a>
<a href="${actionBaseUrl}?action=request" style="background:#fd7e14;padding:10px 20px;color:#fff;text-decoration:none;border-radius:5px;">🔁 Request Another</a>
        `;
 
        await sendEmail(subject, body, quotation.clientDetails.email);
      }
 
      await quotation.save();
 
      return res.status(200).json({
        message: Status === 'draft'
          ? 'Quotation saved as draft'
          : 'Quotation created and emailed to client',
        quotationNumber,
        ...(quotation.pdfUrl && { pdfUrl: quotation.pdfUrl })
      });
    }
  } catch (error) {
    console.error('Error creating quotation:', error);
    res.status(500).json({ error: error.message });
  }
};


exports.getQuotationPDF = async (req, res) => {
  try {
    const quotationNumber = req.params.quotationNumber;
 
    // 1. Check if quotation exists
    const quotation = await Quotation.findOne({ quotationNumber });
 
    if (!quotation) {
      return res.status(404).json({ message: "Quotation not found." });
    }
 
    // 2. Allow only if Status is 'final'
    if (quotation.Status !== 'final') {
      return res.status(403).json({ message: "PDF is only available for finalized quotations." });
    }
 
    // 3. Build PDF path
    const pdfPath = path.resolve(process.cwd(), `uploads/quotations/${quotationNumber}.pdf`);
    console.log('Serving Quotation PDF from:', pdfPath);
 
    if (!fs.existsSync(pdfPath)) {
      return res.status(404).json({ message: "PDF file not found on server." });
    }
 
    // 4. Serve the PDF
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${quotationNumber}.pdf"`);
 
    fs.createReadStream(pdfPath).pipe(res);
  } catch (error) {
    console.error('Error viewing Quotation PDF:', error);
    res.status(500).json({ message: "Failed to view Quotation PDF", error: error.message });
  }
};

exports.downloadQuotationPDF = async (req, res) => {
  try {
    const { quotationNumber } = req.params;

    const quotation = await Quotation.findOne({ quotationNumber });

    if (!quotation || !quotation.pdfUrl) {
      return res.status(404).json({ message: 'PDF not found for this quotation.' });
    }

    const pdfPath = path.resolve(__dirname, '../../uploads/quotations', `${quotationNumber}.pdf`);

    if (!fs.existsSync(pdfPath)) {
      return res.status(404).json({ message: 'PDF file missing from server.' });
    }

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=${quotationNumber}.pdf`);

    const fileStream = fs.createReadStream(pdfPath);
    fileStream.pipe(res);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};



exports.handleStatusAction = async (req, res) => {
  try {
    const { quotationNumber } = req.params;
    const { action } = req.body;

    const statusMap = {
      accept: 'accepted',
      reject: 'rejected',
      request: 'requested'
    };

    const newStatus = statusMap[action];

    if (!newStatus) {
      return res.status(400).send('Invalid action.');
    }

    const quotation = await Quotation.findOneAndUpdate(
      { quotationNumber },
      { status: newStatus },
      { new: true }
    );

    if (!quotation) {
      return res.status(404).send('Quotation not found.');
    }

    await sendResponseToCompany(quotation, newStatus);

    res.send(`
      <html>
        <head><title>Status Updated</title></head>
        <body style="font-family: Arial; text-align: center; padding: 40px;">
          <h2>Thank you!</h2>
          <p>Your response has been recorded as: <strong>${newStatus.toUpperCase()}</strong>.</p>
        </body>
      </html>
    `);
  } catch (err) {
  console.error(' Error in handleStatusAction:', err);
  res.status(500).send('Server error.');
}

};

async function sendResponseToCompany(quotation, status) {
  subject=`Client responded to Quotation - ${quotation.quotationNumber}`;
  const html = `
    <div style="font-family: Arial, sans-serif;">
      <p><strong>Client Response Received</strong></p>
      <p><strong>Quotation Number:</strong> ${quotation.quotationNumber}</p>
      <p><strong>Status:</strong> ${status.toUpperCase()}</p>
      <p><strong>Client Name:</strong> ${quotation.clientDetails.name}</p>
      <p><strong>Client Email:</strong> ${quotation.clientDetails.email}</p>
    </div>
  `;

  await sendEmail(
    
    
    subject,
    html,
    quotation.serviceProviderDetails.email,
  );
  
}
exports.renderStatusPage = async (req, res) => {
  const { quotationNumber } = req.params;
  const { action } = req.query;

  res.send(`
    <html>
      <head><title>Confirm Quotation Response</title></head>
      <body style="font-family: Arial; text-align: center; padding: 40px;">
        <form method="POST" action="/api/quotation/status/${quotationNumber}/update">
          <input type="hidden" name="action" value="${action}" />
          <h2>Confirm your action: <strong>${action.toUpperCase()}</strong></h2>
          <button type="submit" style="padding: 10px 20px; font-size: 16px;">Confirm</button>
        </form>
      </body>
    </html>
  `);
};