const mongoose = require("mongoose");

const budgetCategorySchema = new mongoose.Schema(
  {
    categoryId: {        // Auto-generated unique ID
      type: String,
      unique: true,
      trim: true,
    },
    name: {              // Category name
      type: String,
      required: true,
      trim: true,
    },
    description: {       // Optional description
      type: String,
      trim: true,
    },
    accountId: {                    
      type: String,
      required: true,
      ref: "BudgetAccount",
    },
    entityIds: [         // Reference to BudgetEntity documents
      { type: String, ref: "BudgetEntity" },
    ],
    isActive: {          // Active / Inactive
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

// ============================================
// STATIC METHOD: Create category with auto categoryId
// ============================================
budgetCategorySchema.statics.createCategoryWithId = async function (data) {
  const lastCategory = await this.findOne().sort({ createdAt: -1 });

  let nextNumber = 1;
  if (lastCategory && lastCategory.categoryId) {
    const lastNum = parseInt(lastCategory.categoryId.split("-")[1]);
    if (!isNaN(lastNum)) nextNumber = lastNum + 1;
  }

  const categoryId = `CAT-${String(nextNumber).padStart(3, "0")}`;
  const newCategory = new this({
    categoryId,
    ...data,
  });

  return newCategory.save();
};

module.exports = mongoose.model("BudgetCategory", budgetCategorySchema);
