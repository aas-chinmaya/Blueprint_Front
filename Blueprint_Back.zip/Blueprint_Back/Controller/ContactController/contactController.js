


const Contact = require('../../Model/ContactModel/Contact');
const { sendEmail } = require('../../middlewares/nodemailer');
 
// Helper function to get month name
const getMonthName = (date) => {
  return date.toLocaleString('en-US', { month: 'long' }).toLowerCase();
};





// exports.createContact = async (req, res) => {
//   try {
//     const {
//       fullName,
//       email,
//       phone,
//       companyName,
//       designation,
//       industry,
//       location,
//       Companylocation,
//       serviceInterest,
//       referralSource,
//       message,
//       brandCategory,
//       sourceDomain,
//       organizationName,
//       jobTitleOrRole,
//       addressLocation,
//       inquirySource,
//       requirementSummary,
//       feedback,
//       internalNotes,
//       assignedAdmin,
//       hostedDomain, // Frontend domain field
//     } = req.body;

//     // Generate Contact ID like CId-October-25-001
//     const now = new Date();
//     const month = getMonthName(now);
//     const year = now.getFullYear().toString().slice(-2);

//     const lastContact = await Contact.findOne({
//       contactId: new RegExp(`^CId-${month}-${year}-\\d{3}$`, "i"),
//     }).sort({ createdAt: -1 });

//     let sequence = 1;
//     if (lastContact && lastContact.contactId) {
//       const parts = lastContact.contactId.split("-");
//       const lastSeq = parseInt(parts[3], 10);
//       sequence = lastSeq + 1;
//     }

//     const paddedSeq = sequence.toString().padStart(3, "0");
//     const contactId = `CId-${month}-${year}-${paddedSeq}`;

//     // Capture source domain (fallback to request origin)
//     const finalSourceDomain =
//       sourceDomain || req.get("origin") || req.protocol + "://" + req.get("host");

//     // Capture hosted domain (frontend domain that called API)
//     const finalHostedDomain =
//       hostedDomain || req.get("origin") || req.headers.referer || "Unknown";

//     // Save new contact
//     const newContact = new Contact({
//       contactId,
//       fullName,
//       email,
//       phone,
//       companyName,
//       designation,
//       industry,
//       location,
//       Companylocation,
//       serviceInterest,
//       referralSource,
//       message,
//       brandCategory,
//       sourceDomain: finalSourceDomain,
//       hostedDomain: finalHostedDomain, // new field stored
//       organizationName,
//       jobTitleOrRole,
//       addressLocation,
//       inquirySource,
//       requirementSummary,
//       feedback,
//       internalNotes,
//       assignedAdmin,
//     });

//     await newContact.save();

//     // Determine recipient email based on source domain
//     let recipientEmail;
//     if (
//       finalSourceDomain.includes("hrms.aasint.com") ||
//       finalSourceDomain.includes("blutest.aas.technology") ||
//       finalSourceDomain.includes("blu.aas.technology")||
//       finalSourceDomain.includes("aas.technology")

//     ) {
//       recipientEmail = "it_pujarini@outlook.com";
//     } else {
//       recipientEmail = email;
//     }

//     await sendEmail(
//       "Thank You for Contacting AAS International",
//       `
//       <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
//         <div style="text-align: center; margin-bottom: 20px;">
//           <img src="https://aas.technology/assets/aaslogo.png" alt="AAS International Logo" style="max-width: 150px;">
//         </div>
//         <h2 style="color: #333; text-align: center;">Thank You for Contacting Us</h2>
//         <p style="color: #555; line-height: 1.6;">Dear ${fullName},</p>
//         <p style="color: #555; line-height: 1.6;">
//          We have received your message and our team will get back to you as soon as possible.
//         </p>
//         <p style="color: #555; line-height: 1.6;">
//           In the meantime, feel free to explore our website for more information about our services and solutions.
//         </p>
//         <div style="margin: 30px 0; padding: 15px; background-color: #f9f9f9; border-left: 4px solid #AF9A57; border-radius: 3px;">
//           <p style="margin: 0; color: #666;">If you have any urgent inquiries, please contact our Bhubaneswar office at:</p>
//           <p style="margin: 5px 0 0; color: #666;">Phone: <a href="tel:+916742571111" style="color: #AF9A57; text-decoration: none;">+91 6742571111</a></p>
//           <p style="margin: 5px 0 0; color: #666;">Email: <a href="mailto:contact@aasint.com" style="color: #AF9A57; text-decoration: none;">contact@aasint.com</a></p>
//           <p style="margin: 5px 0 0; color: #666;">Address: Plot 52, 2nd floor, Bapuji Nagar, Bhubaneswar</p>
//         </div>
//         <p style="color: #555; line-height: 1.6;">Best Regards,</p>
//         <p style="color: #555; line-height: 1.6;">The AAS International Team</p>
//         <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; text-align: center; font-size: 12px; color: #999;">
//           <p>© ${new Date().getFullYear()} AAS International Private Limited. All rights reserved.</p>
//           <div style="margin-top: 10px;">
//             <a href="https://facebook.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Facebook</a> |
//             <a href="https://twitter.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Twitter</a> |
//             <a href="https://linkedin.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">LinkedIn</a> |
//             <a href="https://www.youtube.com/channel/UCPgsMheOi91WOsLnMn9LCmg" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">YouTube</a>
//           </div>
//         </div>
//       </div>
//       `,
//       email, // Sender email (or could be system email)
//       [recipientEmail] // Dynamic recipient based on domain
//     );
    

//     res.status(201).json({
//       success: true,
//       message: "Contact submitted successfully",
//       contact: newContact,
//       sentTo: recipientEmail,
//     });
//   } catch (error) {
//     console.error(" Error submitting contact form:", error);
//     res.status(500).json({
//       success: false,
//       message: "An error occurred while submitting the contact form",
//       error: error.message,
//     });
//   }
// };


exports.createContact = async (req, res) => {
  try {
    const {
      fullName,
      email,
      phone,
      companyName,
      designation,
      industry,
      location,
      Companylocation,
      serviceInterest,
      referralSource,
      message,
      brandCategory,
      sourceDomain,
      organizationName,
      jobTitleOrRole,
      addressLocation,
      inquirySource,
      requirementSummary,
      feedback,
      internalNotes,
      assignedAdmin,
      hostedDomain, // Frontend domain field
    } = req.body;

    // Generate Contact ID like CId-October-25-001
    const now = new Date();
    const month = getMonthName(now);
    const year = now.getFullYear().toString().slice(-2);

    const lastContact = await Contact.findOne({
      contactId: new RegExp(`^CId-${month}-${year}-\\d{3}$`, "i"),
    }).sort({ createdAt: -1 });

    let sequence = 1;
    if (lastContact && lastContact.contactId) {
      const parts = lastContact.contactId.split("-");
      const lastSeq = parseInt(parts[3], 10);
      sequence = lastSeq + 1;
    }

    const paddedSeq = sequence.toString().padStart(3, "0");
    const contactId = `CId-${month}-${year}-${paddedSeq}`;

    // Capture source domain (fallback to request origin)
    const finalSourceDomain =
      sourceDomain || req.get("origin") || req.protocol + "://" + req.get("host");

    // Capture hosted domain (frontend domain that called API)
    const finalHostedDomain =
      hostedDomain || req.get("origin") || req.headers.referer || "Unknown";

    // Save new contact
    const newContact = new Contact({
      contactId,
      fullName,
      email,
      phone,
      companyName,
      designation,
      industry,
      location,
      Companylocation,
      serviceInterest,
      referralSource,
      message,
      brandCategory,
      sourceDomain: finalSourceDomain,
      hostedDomain: finalHostedDomain,
      organizationName,
      jobTitleOrRole,
      addressLocation,
      inquirySource,
      requirementSummary,
      feedback,
      internalNotes,
      assignedAdmin,
    });

    await newContact.save();

    // Determine recipient email for admin notification
    let recipientEmail;
    if (
      finalSourceDomain.includes("hrms.aasint.com") ||
      finalSourceDomain.includes("blutest.aas.technology") ||
      finalSourceDomain.includes("blu.aas.technology") ||
      finalSourceDomain.includes("aas.technology")
    ) {
     
    } else {
      recipientEmail = "marketing@aas.technologhy"; // default fallback admin email
    }

    /**
     * 1 Send Thank You mail to the contact person
     */
    // await sendEmail(
    //   "Thank You for Contacting AAS International",
    //   `
    //   <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
    //     <div style="text-align: center; margin-bottom: 20px;">
    //       <img src="https://aas.technology/assets/aaslogo.png" alt="AAS International Logo" style="max-width: 150px;">
    //     </div>
    //     <h2 style="color: #333; text-align: center;">Thank You for Contacting Us</h2>
    //     <p style="color: #555; line-height: 1.6;">Dear ${fullName},</p>
    //     <p style="color: #555; line-height: 1.6;">
    //      We have received your message and our team will get back to you as soon as possible.
    //     </p>
    //     <p style="color: #555; line-height: 1.6;">
    //       In the meantime, feel free to explore our website for more information about our services and solutions.
    //     </p>
    //     <div style="margin: 30px 0; padding: 15px; background-color: #f9f9f9; border-left: 4px solid #AF9A57; border-radius: 3px;">
    //       <p style="margin: 0; color: #666;">If you have any urgent inquiries, please contact our Bhubaneswar office at:</p>
    //       <p style="margin: 5px 0 0; color: #666;">Phone: <a href="tel:+916742571111" style="color: #AF9A57; text-decoration: none;">+91 6742571111</a></p>
    //       <p style="margin: 5px 0 0; color: #666;">Email: <a href="mailto:contact@aasint.com" style="color: #AF9A57; text-decoration: none;">contact@aasint.com</a></p>
    //       <p style="margin: 5px 0 0; color: #666;">Address: Plot 52, 2nd floor, Bapuji Nagar, Bhubaneswar</p>
    //     </div>
    //     <p style="color: #555; line-height: 1.6;">Best Regards,</p>
    //     <p style="color: #555; line-height: 1.6;">The AAS International Team</p>
    //     <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; text-align: center; font-size: 12px; color: #999;">
    //       <p>© ${new Date().getFullYear()} AAS International Private Limited. All rights reserved.</p>
    //       <div style="margin-top: 10px;">
    //         <a href="https://facebook.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Facebook</a> |
    //         <a href="https://twitter.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Twitter</a> |
    //         <a href="https://linkedin.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">LinkedIn</a> |
    //         <a href="https://www.youtube.com/channel/UCPgsMheOi91WOsLnMn9LCmg" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">YouTube</a>
    //       </div>
    //     </div>
    //   </div>
    //   `,
    //   [email] // only to contact person
    // );

    await sendEmail(
  "Thank You for Contacting AAS International",
  `
  <html>
    <head>
      <title>Thank You for Contacting Us</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Poppins:wght@400;500;600&display=swap');

        body {
          margin: 0;
          padding: 0;
          background-color: #f6f5f1;
          font-family: 'Poppins', sans-serif;
          color: #2b2b2b;
        }

        .container {
          max-width: 720px;
          margin: 40px auto;
          background: #ffffff;
          border-radius: 12px;
          box-shadow: 0 6px 24px rgba(0, 0, 0, 0.08);
          overflow: hidden;
          border-top: 6px solid #c6a04f;
          animation: fadeIn 0.9s ease-in-out;
        }

        @keyframes fadeIn {
          0% { opacity: 0; transform: translateY(10px); }
          100% { opacity: 1; transform: translateY(0); }
        }

        .header {
          text-align: center;
          padding: 35px 25px 10px;
        }

        .brand {
          font-family: 'Playfair Display', serif;
          font-size: 28px;
          color: #b9952a;
          font-weight: 600;
        }

        .tagline {
          font-size: 13px;
          color: #7d7d7d;
          letter-spacing: 0.5px;
          margin-top: 4px;
        }

        .hero {
          text-align: center;
          padding: 15px 30px 0;
        }

        .hero h1 {
          font-size: 22px;
          color: #b9952a;
          font-weight: 600;
          margin: 0;
        }

        .divider {
          width: 60px;
          height: 2px;
          background: #e6d6a8;
          margin: 16px auto 20px;
          border-radius: 1px;
        }

        .content {
          padding: 25px 40px 35px;
          font-size: 15.5px;
          color: #444;
          line-height: 1.8;
        }

        .content p {
          margin-bottom: 14px;
        }

        .highlight-box {
          margin: 30px 0;
          padding: 18px 20px;
          background-color: #fdfaf3;
          border-left: 4px solid #c6a04f;
          border-radius: 6px;
          font-size: 15px;
          color: #555;
        }

        .footer {
          background: #fdfaf3;
          text-align: center;
          font-size: 13.5px;
          color: #777;
          border-top: 1px solid #f0e7ce;
          padding: 16px 10px;
        }

        .footer a {
          color: #b9952a;
          text-decoration: none;
          font-weight: 500;
        }

        .footer a:hover {
          text-decoration: underline;
        }

        strong {
          color: #b9952a;
        }
      </style>
    </head>

    <body>
      <div class="container">
        <!-- Header -->
        <div class="header">
          <div class="brand">AAS International Pvt. Ltd.</div>
          <div class="tagline">Customer Relations Team</div>
        </div>

        <!-- Hero -->
        <div class="hero">
          <h1>Thank You for Contacting Us</h1>
          <div class="divider"></div>
        </div>

        <!-- Content -->
        <div class="content">
          <p>Dear <strong>${fullName}</strong>,</p>

          <p>
            Thank you for reaching out to <strong>AAS International</strong>. 
            We’ve received your inquiry and our team will get back to you as soon as possible.
          </p>

          <p>
            In the meantime, feel free to explore our website to learn more about our <strong>services, solutions, and innovations</strong>.
          </p>

          <div class="highlight-box">
            <p>If you have any urgent inquiries, please contact our Bhubaneswar office:</p>
            <p> <a href="tel:+916742571111">+91 6742571111</a><br/>
                <a href="mailto:contact@aasint.com">contact@aasint.com</a><br/>
                Plot 52, 2nd Floor, Bapuji Nagar, Bhubaneswar</p>
          </div>

          <p>
            Warm regards,<br/>
            <strong>The AAS International Team</strong>
          </p>
        </div>

        <!-- Footer -->
        <div class="footer">
          <p>© ${new Date().getFullYear()} AAS International Private Limited. All rights reserved.</p>
          <p>
            <a href="https://aas.technology/">aas.technology</a> |
            <a href="https://www.facebook.com/">Facebook</a> •
            <a href="https://twitter.com/">Twitter</a> •
            <a href="https://linkedin.com/">LinkedIn</a> •
            <a href="https://www.youtube.com/channel/UCPgsMheOi91WOsLnMn9LCmg">YouTube</a>
          </p>
        </div>
      </div>
    </body>
  </html>
  `,
  [email]
);


    /**
     * 2️ Send Inquiry Details to Admin only
     */
    // await sendEmail(
    //   `New Contact Inquiry - ${fullName} (${contactId})`,
    //   `
    //   <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 700px; margin: 0 auto; background: #fff; border: 1px solid #ddd; border-radius: 8px;">
    //     <div style="background-color: #AF9A57; padding: 15px 25px; color: white; font-size: 18px; font-weight: bold;">
    //       New Contact Inquiry Received
    //     </div>
    //     <div style="padding: 25px;">
    //       <p style="font-size: 15px; color: #444;">Hello Admin,</p>
    //       <p style="font-size: 15px; color: #444;">A new contact inquiry has been submitted. Please find the details below:</p>

    //       <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Contact ID</b></td><td style="padding: 8px; border: 1px solid #ddd;">${contactId}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Full Name</b></td><td style="padding: 8px; border: 1px solid #ddd;">${fullName}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Email</b></td><td style="padding: 8px; border: 1px solid #ddd;">${email}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Phone</b></td><td style="padding: 8px; border: 1px solid #ddd;">${phone || "N/A"}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Company Name</b></td><td style="padding: 8px; border: 1px solid #ddd;">${companyName || "N/A"}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Designation</b></td><td style="padding: 8px; border: 1px solid #ddd;">${designation || "N/A"}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Industry</b></td><td style="padding: 8px; border: 1px solid #ddd;">${industry || "N/A"}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Location</b></td><td style="padding: 8px; border: 1px solid #ddd;">${location || "N/A"}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Service Interest</b></td><td style="padding: 8px; border: 1px solid #ddd;">${serviceInterest || "N/A"}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Referral Source</b></td><td style="padding: 8px; border: 1px solid #ddd;">${referralSource || "N/A"}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Requirement Summary</b></td><td style="padding: 8px; border: 1px solid #ddd;">${requirementSummary || "N/A"}</td></tr>
    //         <tr><td style="padding: 8px; border: 1px solid #ddd;"><b>Message</b></td><td style="padding: 8px; border: 1px solid #ddd;">${message || "N/A"}</td></tr>
    //       </table>

    //       <p style="margin-top: 25px; color: #666; font-size: 14px;">
    //         <b>Submitted from:</b> ${finalSourceDomain}<br>
    //         <b>Frontend (Hosted) Domain:</b> ${finalHostedDomain}<br>
    //         <b>Received at:</b> ${now.toLocaleString("en-IN")}
    //       </p>
    //     </div>

    //     <div style="background: #f9f9f9; padding: 15px 25px; font-size: 13px; color: #888; border-top: 1px solid #ddd;">
    //       © ${new Date().getFullYear()} AAS International Pvt. Ltd. | Confidential Inquiry Notification
    //     </div>
    //   </div>
    //   `,
     
    //   [recipientEmail] // only to admin
    // );
     

     await sendEmail(
  `New Contact Inquiry - ${fullName} (${contactId})`,
  `
  <html>
    <head>
      <title>New Contact Inquiry</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Poppins:wght@400;500;600&display=swap');

        body {
          margin: 0;
          padding: 0;
          background-color: #f6f5f1;
          font-family: 'Poppins', sans-serif;
          color: #2b2b2b;
        }

        .container {
          max-width: 740px;
          margin: 40px auto;
          background: #ffffff;
          border-radius: 12px;
          box-shadow: 0 6px 24px rgba(0, 0, 0, 0.08);
          overflow: hidden;
          border-top: 6px solid #c6a04f;
          animation: fadeIn 0.9s ease-in-out;
        }

        @keyframes fadeIn {
          0% { opacity: 0; transform: translateY(10px); }
          100% { opacity: 1; transform: translateY(0); }
        }

        .header {
          text-align: center;
          background: #fdfaf3;
          padding: 35px 25px 10px;
        }

        .brand {
          font-family: 'Playfair Display', serif;
          font-size: 28px;
          color: #b9952a;
          font-weight: 600;
        }

        .tagline {
          font-size: 13px;
          color: #7d7d7d;
          letter-spacing: 0.5px;
          margin-top: 4px;
        }

        .hero {
          text-align: center;
          padding: 15px 30px 0;
        }

        .hero h1 {
          font-size: 22px;
          color: #b9952a;
          font-weight: 600;
          margin: 0;
        }

        .divider {
          width: 60px;
          height: 2px;
          background: #e6d6a8;
          margin: 16px auto 20px;
          border-radius: 1px;
        }

        .content {
          padding: 25px 40px 35px;
          font-size: 15.5px;
          color: #444;
          line-height: 1.8;
        }

        .content p {
          margin-bottom: 14px;
        }

        .details-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 15px;
        }

        .details-table th,
        .details-table td {
          padding: 10px 12px;
          border: 1px solid #eee4c6;
          text-align: left;
          vertical-align: top;
        }

        .details-table th {
          background-color: #fdfaf3;
          font-weight: 600;
          color: #b9952a;
          width: 30%;
        }

        .details-table td {
          background-color: #ffffff;
          color: #333;
        }

        .meta {
          margin-top: 25px;
          font-size: 14px;
          color: #666;
          line-height: 1.6;
        }

        .footer {
          background: #fdfaf3;
          text-align: center;
          font-size: 13.5px;
          color: #777;
          border-top: 1px solid #f0e7ce;
          padding: 16px 10px;
        }

        .footer a {
          color: #b9952a;
          text-decoration: none;
          font-weight: 500;
        }

        .footer a:hover {
          text-decoration: underline;
        }

        strong {
          color: #b9952a;
        }
      </style>
    </head>

    <body>
      <div class="container">
        <!-- Header -->
        <div class="header">
          <div class="brand">AAS International Pvt. Ltd.</div>
          <div class="tagline">Business Development Department</div>
        </div>

        <!-- Hero -->
        <div class="hero">
          <h1> New Contact Inquiry Received</h1>
          <div class="divider"></div>
        </div>

        <!-- Content -->
        <div class="content">
          <p>Hello <strong>Admin</strong>,</p>
          <p>A new contact inquiry has been submitted. Please review the details below:</p>

          <table class="details-table">
            <tr><th>Contact ID</th><td>${contactId}</td></tr>
            <tr><th>Full Name</th><td>${fullName}</td></tr>
            <tr><th>Email</th><td>${email}</td></tr>
            <tr><th>Phone</th><td>${phone || "N/A"}</td></tr>
            <tr><th>Company Name</th><td>${companyName || "N/A"}</td></tr>
            <tr><th>Designation</th><td>${designation || "N/A"}</td></tr>
            <tr><th>Industry</th><td>${industry || "N/A"}</td></tr>
            <tr><th>Location</th><td>${location || "N/A"}</td></tr>
            <tr><th>Service Interest</th><td>${serviceInterest || "N/A"}</td></tr>
            <tr><th>Referral Source</th><td>${referralSource || "N/A"}</td></tr>
            <tr><th>Requirement Summary</th><td>${requirementSummary || "N/A"}</td></tr>
            <tr><th>Message</th><td>${message || "N/A"}</td></tr>
          </table>

          <div class="meta">
            <p><strong>Submitted From:</strong> ${finalSourceDomain}</p>
            <p><strong>Frontend (Hosted) Domain:</strong> ${finalHostedDomain}</p>
            <p><strong>Received At:</strong> ${now.toLocaleString("en-IN")}</p>
          </div>

          <p style="margin-top: 20px;">
            Please assign this inquiry to the respective <strong>Business Executive</strong> for prompt follow-up.
          </p>
        </div>

        <!-- Footer -->
        <div class="footer">
          <p>© ${new Date().getFullYear()} AAS International Private Limited. Confidential Inquiry Notification</p>
          <p><a href="https://aas.technology/">aas.technology</a></p>
        </div>
      </div>
    </body>
  </html>
  `,
  [recipientEmail]
);





    res.status(201).json({
      success: true,
      message: "Contact submitted successfully",
      contact: newContact,
      sentTo: [email, recipientEmail],
    });
  } catch (error) {
    console.error(" Error submitting contact form:", error);
    res.status(500).json({
      success: false,
      message: "An error occurred while submitting the contact form",
      error: error.message,
    });
  }
};




//  exports.createContact = async (req, res) => {
//   try {
//     const {
//       fullName,
//       email,
//       phone,
//       companyName,
//       designation,
//       industry,
//       location,
//       Companylocation,
//       serviceInterest,
//       referralSource,
//       message,
//       // Added new schema fields below
//       brandCategory,
//       sourceDomain,
//       organizationName,
//       jobTitleOrRole,
//       addressLocation,
//       inquirySource,
//       requirementSummary,
//       feedback,
//       internalNotes,
//       assignedAdmin,
//     } = req.body;
 
//     // Generate Contact ID like CId-October-25-001
//     const now = new Date();
//     const month = getMonthName(now);
//     const year = now.getFullYear().toString().slice(-2);
 
//     const lastContact = await Contact.findOne({
//       contactId: new RegExp(`^CId-${month}-${year}-\\d{3}$`, "i"),
//     }).sort({ createdAt: -1 });
 
//     let sequence = 1;
//     if (lastContact && lastContact.contactId) {
//       const parts = lastContact.contactId.split("-");
//       const lastSeq = parseInt(parts[3], 10);
//       sequence = lastSeq + 1;
//     }
 
//     const paddedSeq = sequence.toString().padStart(3, "0");
//     const contactId = `CId-${month}-${year}-${paddedSeq}`;
 
//     // Capture source domain
//     const finalSourceDomain =
//       sourceDomain || req.get("origin") || req.protocol + "://" + req.get("host");
 
//     // Save new contact
//     const newContact = new Contact({
//       contactId,
//       fullName,
//       email,
//       phone,
//       companyName,
//       designation,
//       industry,
//       location,
//       Companylocation,
//       serviceInterest,
//       referralSource,
//       message,
//       brandCategory,
//       sourceDomain: finalSourceDomain,
//       organizationName,
//       jobTitleOrRole,
//       addressLocation,
//       inquirySource,
//       requirementSummary,
//       feedback,
//       internalNotes,
//       assignedAdmin,
//     });
 
//     await newContact.save();
 
//     // Determine recipient email based on source domain
//     let recipientEmail;
//     if (
//       finalSourceDomain.includes("hrms.aasint.com") ||
//       finalSourceDomain.includes("localhost:8080") ||
//       finalSourceDomain.includes("blutest.aas.technology") ||
//       finalSourceDomain.includes("blu.aas.technology")
//     ) {
//       recipientEmail = "contact@aasint.com";
//     } else {
//       recipientEmail = email; // send to contact's own entered email
//     }
 
//     // Send Thank You Email
//     await sendEmail(
//       "Thank You for Contacting AAS International",
//       `
//       <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
//         <div style="text-align: center; margin-bottom: 20px;">
//           <img src="https://aas.technology/assets/aaslogo.png" alt="AAS International Logo" style="max-width: 150px;">
//         </div>
//         <h2 style="color: #333; text-align: center;">Thank You for Contacting Us</h2>
//         <p style="color: #555; line-height: 1.6;">Dear ${fullName},</p>
//         <p style="color: #555; line-height: 1.6;">
//          We have received your message and our team will get back to you as soon as possible.
//         </p>
//         <p style="color: #555; line-height: 1.6;">
//           In the meantime, feel free to explore our website for more information about our services and solutions.
//         </p>
//         <div style="margin: 30px 0; padding: 15px; background-color: #f9f9f9; border-left: 4px solid #AF9A57; border-radius: 3px;">
//           <p style="margin: 0; color: #666;">If you have any urgent inquiries, please contact our Bhubaneswar office at:</p>
//           <p style="margin: 5px 0 0; color: #666;">Phone: <a href="tel:+916742571111" style="color: #AF9A57; text-decoration: none;">+91 6742571111</a></p>
//           <p style="margin: 5px 0 0; color: #666;">Email: <a href="mailto:contact@aasint.com" style="color: #AF9A57; text-decoration: none;">contact@aasint.com</a></p>
//           <p style="margin: 5px 0 0; color: #666;">Address: Plot 52, 2nd floor, Bapuji Nagar, Bhubaneswar</p>
//         </div>
//         <p style="color: #555; line-height: 1.6;">Best Regards,</p>
//         <p style="color: #555; line-height: 1.6;">The AAS International Team</p>
//         <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; text-align: center; font-size: 12px; color: #999;">
//           <p>© ${new Date().getFullYear()} AAS International Private Limited. All rights reserved.</p>
//           <div style="margin-top: 10px;">
//             <a href="https://facebook.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Facebook</a> |
//             <a href="https://twitter.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Twitter</a> |
//             <a href="https://linkedin.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">LinkedIn</a> |
//             <a href="https://www.youtube.com/channel/UCPgsMheOi91WOsLnMn9LCmg" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">YouTube</a>
//           </div>
//         </div>
//       </div>
//       `,
//       email, // Sender email (or could be system email)
//       [recipientEmail] // Dynamic recipient based on domain
//     );
 
//     res.status(201).json({
//       success: true,
//       message: "Contact submitted successfully",
//       contact: newContact,
//       sentTo: recipientEmail,
//     });
//   } catch (error) {
//     console.error("❌ Error submitting contact form:", error);
//     res.status(500).json({
//       success: false,
//       message: "An error occurred while submitting the contact form",
//       error: error.message,
//     });
//   }
// };


//  exports.createContact = async (req, res) => {
//   try {
//     const {
//       fullName,
//       email,
//       phone,
//       companyName,
//       designation,
//       industry,
//       location,
//       Companylocation,
//       serviceInterest,
//       referralSource,
//       message,
//       // Added new schema fields below
//       brandCategory,
//       sourceDomain,
//       organizationName,
//       jobTitleOrRole,
//       addressLocation,
//       inquirySource,
//       requirementSummary,
//       feedback,
//       internalNotes,
//       assignedAdmin,
//     } = req.body;
 
//     // Generate Contact ID like CId-October-25-001
//     const now = new Date();
//     const month = getMonthName(now);
//     const year = now.getFullYear().toString().slice(-2);
 
//     const lastContact = await Contact.findOne({
//       contactId: new RegExp(`^CId-${month}-${year}-\\d{3}$`, "i"),
//     }).sort({ createdAt: -1 });
 
//     let sequence = 1;
//     if (lastContact && lastContact.contactId) {
//       const parts = lastContact.contactId.split("-");
//       const lastSeq = parseInt(parts[3], 10);
//       sequence = lastSeq + 1;
//     }
 
//     const paddedSeq = sequence.toString().padStart(3, "0");
//     const contactId = `CId-${month}-${year}-${paddedSeq}`;
 
//     // Capture source domain
//     const finalSourceDomain =
//       sourceDomain || req.get("origin") || req.protocol + "://" + req.get("host");
 
//     // Save new contact
//     const newContact = new Contact({
//       contactId,
//       fullName,
//       email,
//       phone,
//       companyName,
//       designation,
//       industry,
//       location,
//       Companylocation,
//       serviceInterest,
//       referralSource,
//       message,
//       brandCategory,
//       sourceDomain: finalSourceDomain,
//       organizationName,
//       jobTitleOrRole,
//       addressLocation,
//       inquirySource,
//       requirementSummary,
//       feedback,
//       internalNotes,
//       assignedAdmin,
//     });
 
//     await newContact.save();
 
//     // Determine recipient email based on source domain
//     let recipientEmail;
//     if (
//       finalSourceDomain.includes("hrms.aasint.com") ||
//       finalSourceDomain.includes("localhost:8080") ||
//       finalSourceDomain.includes("blutest.aas.technology") ||
//       finalSourceDomain.includes("blu.aas.technology")
//     ) {
//       recipientEmail = "hr@aasint.com";
//     } else {
//       recipientEmail = email; // send to contact's own entered email
//     }
 
//     // Send Thank You Email
//     await sendEmail(
//       "Thank You for Contacting AAS International",
//       `
//       <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
//         <div style="text-align: center; margin-bottom: 20px;">
//           <img src="https://aas.technology/assets/aaslogo.png" alt="AAS International Logo" style="max-width: 150px;">
//         </div>
//         <h2 style="color: #333; text-align: center;">Thank You for Contacting Us</h2>
//         <p style="color: #555; line-height: 1.6;">Dear ${fullName},</p>
//         <p style="color: #555; line-height: 1.6;">
//          We have received your message and our team will get back to you as soon as possible.
//         </p>
//         <p style="color: #555; line-height: 1.6;">
//           In the meantime, feel free to explore our website for more information about our services and solutions.
//         </p>
//         <div style="margin: 30px 0; padding: 15px; background-color: #f9f9f9; border-left: 4px solid #AF9A57; border-radius: 3px;">
//           <p style="margin: 0; color: #666;">If you have any urgent inquiries, please contact our Bhubaneswar office at:</p>
//           <p style="margin: 5px 0 0; color: #666;">Phone: <a href="tel:+916742571111" style="color: #AF9A57; text-decoration: none;">+91 6742571111</a></p>
//           <p style="margin: 5px 0 0; color: #666;">Email: <a href="mailto:contact@aasint.com" style="color: #AF9A57; text-decoration: none;">contact@aasint.com</a></p>
//           <p style="margin: 5px 0 0; color: #666;">Address: Plot 52, 2nd floor, Bapuji Nagar, Bhubaneswar</p>
//         </div>
//         <p style="color: #555; line-height: 1.6;">Best Regards,</p>
//         <p style="color: #555; line-height: 1.6;">The AAS International Team</p>
//         <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; text-align: center; font-size: 12px; color: #999;">
//           <p>© ${new Date().getFullYear()} AAS International Private Limited. All rights reserved.</p>
//           <div style="margin-top: 10px;">
//             <a href="https://facebook.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Facebook</a> |
//             <a href="https://twitter.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">Twitter</a> |
//             <a href="https://linkedin.com" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">LinkedIn</a> |
//             <a href="https://www.youtube.com/channel/UCPgsMheOi91WOsLnMn9LCmg" style="color: #AF9A57; text-decoration: none; margin: 0 5px;">YouTube</a>
//           </div>
//         </div>
//       </div>
//       `,
//       email, // Sender email (or could be system email)
//       [recipientEmail] // Dynamic recipient based on domain
//     );
 
//     res.status(201).json({
//       success: true,
//       message: "Contact submitted successfully",
//       contact: newContact,
//       sentTo: recipientEmail,
//     });
//   } catch (error) {
//     console.error("❌ Error submitting contact form:", error);
//     res.status(500).json({
//       success: false,
//       message: "An error occurred while submitting the contact form",
//       error: error.message,
//     });
//   }
// };
 

//   exports.createContact = async (req, res) => {
//   try {
//     const {
//       fullName,
//       email,
//       phone,
//       companyName,
//       designation,
//       industry,
//       location,
//       Companylocation,
//       serviceInterest,
//       referralSource,
//       message
//     } = req.body;
 
//     const now = new Date();
//     const month = getMonthName(now); // e.g., 'july'
//     const year = now.getFullYear().toString().slice(-2); // e.g., '25'
 
//     const lastContact = await Contact.findOne({
//       contactId: new RegExp(`^CId-${month}-${year}-\\d{3}$`, 'i')
//     }).sort({ createdAt: -1 });
 
//     let sequence = 1;
//     if (lastContact && lastContact.contactId) {
//       const parts = lastContact.contactId.split('-');
//       const lastSeq = parseInt(parts[3], 10);
//       sequence = lastSeq + 1;
//     }
 
//     const paddedSeq = sequence.toString().padStart(3, '0');
//     const contactId = `CId-${month}-${year}-${paddedSeq}`;
 
//     const newContact = new Contact({
//       contactId,
//       fullName,
//       email,
//       phone,
//       companyName,
//       designation,
//       industry,
//       location,
//       Companylocation,
//       serviceInterest,
//       referralSource,
//       message
//     });
 
//     await newContact.save();
 
//     res.status(201).json({
//       message: 'Contact submitted successfully',
//       contact: newContact
//     });
 
//   } catch (error) {
//     console.error('Error submitting contact form:', error);
//     res.status(500).json({
//       message: 'An error occurred while submitting the contact form',
//       error: error.message
//     });
//   }
// };
 
 
 
// Get All Contacts
exports.getAllContacts = async (req, res) => {
  try {
    const contacts = await Contact.find({ isDeleted: false }).sort({ createdAt: -1 });
    res.status(200).json({ contacts });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch contacts', error: error.message });
  }
};
 // ✅ Get all contacts with status = "Contact Received"
exports.getContactReceived = async (req, res) => {
  try {
    const contacts = await Contact.find({
      status: "Contact Received",
      isDeleted: false,
    }).sort({ createdAt: -1 }); // latest first

    // Always respond with an array, even if empty
    res.status(200).json({
      success: true,
      count: contacts.length,
      data: contacts || [],
    });
  } catch (error) {
    console.error("Error fetching contacts:", error);
    res.status(500).json({
      success: false,
      message: "Server Error",
      data: [],
      error: error.message,
    });
  }
};

// Get Contact by contactId
exports.getContactById = async (req, res) => {
  try {
    const { contactId } = req.params;
    const contact = await Contact.findOne({ contactId, isDeleted: false });
 
    if (!contact) {
      return res.status(404).json({ message: 'Contact not found' });
    }
 
    res.status(200).json({ contact });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch contact', error: error.message });
  }
};

// exports.getContactById = async (req, res) => {
//   try {
//     const { contactId } = req.params;
 
//     // Fetch contact and include conversations
//     const contact = await Contact.findOne(
//       { contactId, isDeleted: false },
//       { conversations: 1, status: 1, feedback: 1, fullName: 1, email: 1, phone: 1, companyName: 1, brandCategory: 1, sourceDomain: 1, jobTitleOrRole: 1, addressLocation: 1, serviceInterest: 1, inquirySource: 1, message: 1, assignedAdmin: 1, createdAt: 1, updatedAt: 1 }
//     );
 
//     if (!contact) {
//       return res.status(404).json({ message: 'Contact not found' });
//     }
 
//     res.status(200).json({
//       contact,
//     });
//   } catch (error) {
//     res.status(500).json({
//       message: 'Failed to fetch contact',
//       error: error.message,
//     });
//   }
// };


// Update contact: status and feedback & log conversation
//last file
// exports.updateContact = async (req, res) => {
//   try {
//     const { contactId } = req.params;
//     const { status, feedback } = req.body;
 
//     const allowedStatuses = [
//      'Pending',

//       'Accepted',

//       'Rejected',

//       'Contact Received',

//       'Conversion Made',

//       'Follow-up Taken',
//        'Contact Received',
//         'Conversion Made',
//         'Follow-up Taken',
//         'Converted to Lead',
//         'Closed',
// "Ready for Meeting",
//       'In Progress',

//       'Converted',

//       'Closed',
//     ];
 
//     if (status && !allowedStatuses.includes(status)) {
//       return res.status(400).json({ message: 'Invalid status value' });
//     }
 
//     const updateData = {};
//     if (status) updateData.status = status;
//     if (feedback) updateData.feedback = feedback;
 
//     // Push status and feedback as a new conversation entry
//     if (status || feedback) {
//       updateData.$push = {
//         conversations: {
//           ...(status && { status }),
//           ...(feedback && { feedback }),
//           timestamp: new Date(),
//         },
//       };
//     }
 
//     const updatedContact = await Contact.findOneAndUpdate(
//       { contactId, isDeleted: false },
//       updateData,
//       { new: true }
//     );
 
//     if (!updatedContact) {
//       return res.status(404).json({ message: 'Contact not found' });
//     }
 
//     res.status(200).json({
//       message: 'Contact updated and changes recorded in conversation history',
//       contact: updatedContact,
//     });
//   } catch (error) {
//     console.error('Error updating contact:', error);
//     res.status(500).json({
//       message: 'Failed to update contact',
//       error: error.message,
//     });
//   }
// };
 //new file updated with minor changes
exports.updateContact = async (req, res) => {
  try {
    const { contactId } = req.params;
    const { status, feedback, internalNote, internalNotes, actionedBy } = req.body;
 
    if (!contactId) {
      return res.status(400).json({ message: "Contact ID is required" });
    }
 
    const allowedStatuses = [
      "Contact Received",
      "Conversion Made",
      "Ready for Meeting",
      "Follow-up Taken",
      "Converted to Lead",
      "Closed",
    ];
 
    if (status && !allowedStatuses.includes(status)) {
      return res.status(400).json({ message: "Invalid status value" });
    }
 
    // Pick whichever is provided
    const noteValue = internalNote || internalNotes;
 
    // Build conversation entry
    const newConversation = {
      ...(status && { status }),
      ...(feedback && { feedback }),
      ...(noteValue && { internalNotes: noteValue }),
      ...(actionedBy && { actionedBy }),
      timestamp: new Date(),
    };
 
    // Prepare update data for top-level fields
    const updateData = {};
    if (status) updateData.status = status;
    if (feedback) updateData.feedback = feedback;
    if (noteValue) updateData.internalNotes = noteValue; // keep parent sync
 
    const updatedContact = await Contact.findOneAndUpdate(
      { contactId, isDeleted: false },
      {
        $set: updateData,
        $push: { conversations: newConversation },
      },
      { new: true }
    );
 
    if (!updatedContact) {
      return res.status(404).json({ message: "Contact not found" });
    }
 
    res.status(200).json({
      message: "Contact updated successfully and conversation history recorded.",
      contact: updatedContact,
    });
  } catch (error) {
    console.error("Error updating contact:", error);
    res.status(500).json({
      message: "Failed to update contact.",
      error: error.message,
    });
  }
};

exports.deleteContact = async (req, res) => {
  try {
    const { contactId } = req.params;
    const deletedContact = await Contact.findOneAndUpdate(
      { contactId },
      { isDeleted: true },
      { new: true }
    );
 
    if (!deletedContact) {
      return res.status(404).json({ message: 'Contact not found' });
    }
 
    res.status(200).json({ message: 'Contact deleted (soft) successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete contact', error: error.message });
  }
};
 
 
// Get all contacts with status 'Accepted'
exports.getApprovedContacts = async (req, res) => {
  try {
    const  contacts  = await Contact.find({ status: 'Accepted', isDeleted: false });
 
    res.status(200).json(
      { contacts }
    );
  } catch (error) {
    console.error('Error fetching approved contacts:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error',
    });
  }
};