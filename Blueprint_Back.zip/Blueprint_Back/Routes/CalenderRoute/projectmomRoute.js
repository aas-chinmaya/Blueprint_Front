const express = require('express');
const multer = require('multer');
const path = require('path');
const {viewProjectMOM,getMomsByProjectId, createProjectMOM,getMomById} = require('../../Controller/CalenderController/projectMomController');
 
const router = express.Router();
const storage = multer.memoryStorage();
 
 
 
const upload = multer({ storage });
 

router.post('/creatprojectmom',  upload.single('signature'), createProjectMOM);

router.get('/view/:momId', viewProjectMOM); // Preview
router.get("/fetchallmom/:projectId", getMomsByProjectId);


router.get('/getmombymomId/:momId', getMomById);
module.exports = router;
 