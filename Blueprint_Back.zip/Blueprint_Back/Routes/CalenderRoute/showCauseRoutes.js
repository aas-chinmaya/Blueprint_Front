// Routes/CalenderRoutes/showCauseRoutes.js
const express = require('express');
const router = express.Router();
const controller = require('../../Controller/CalenderController/showCauseController');

router.post('/submit', controller.submitShowCause);
router.get('/meeting/:meetingId', controller.getShowCauseByMeetingId);
router.get('/all', controller.getAllShowCauses);
// Update show cause status by meetingId
router.put('/updatestatus/:showCauseId', controller.updateShowCauseStatus);
module.exports = router;
