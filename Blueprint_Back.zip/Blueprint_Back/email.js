const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "arunak47.b@gmail.com",
    pass: "dhppstzoissvxshp", // no spaces!
  },
});

async function sendEmail(subject, body, toRecipient) {
  try {
    const mailOptions = {
      from: `"AAS Technology" <arunak47.b@gmail.com>`,
      to: toRecipient,
      subject,
      html: body,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log("✅ Email sent successfully:", info.response);
  } catch (error) {
    console.error("❌ Error sending email:", error.message);
  }
}

function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

(async () => {
  const otp = generateOTP();
  console.log("Generated OTP:", otp);

  const recipient = "it_chinmaya@outlook.com"; // change this
  const subject = "Your Login OTP - AAS Technology";
  const body = `
    <div style="font-family: Arial, sans-serif; padding: 16px;">
      <h2>Login Verification</h2>
      <p>Your OTP for login is:</p>
      <h1 style="color:#007bff;">${otp}</h1>
      <p>This OTP will expire in 5 minutes. Do not share it with anyone.</p>
    </div>
  `;

  await sendEmail(subject, body, recipient);
})();
