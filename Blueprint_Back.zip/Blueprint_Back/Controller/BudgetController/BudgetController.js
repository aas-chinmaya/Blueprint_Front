// const BudgetRequest = require('../../Model/ProjectModel/Budget');

// /* -------------------------
//    Create a Budget Request
// ------------------------- */
// // exports.createBudgetRequest = async (req, res) => {
// //   try {
// //     const { projectId, requestType, title, description, requestedAmount, currency, teamId, teamName, teamLeadId, teamLeadName, teamMembers } = req.body;

// //     const newRequest = new BudgetRequest({
// //       projectId,
// //       requestType,
// //       title,
// //       description,
// //       requestedAmount,
// //       currency,
// //       teamId,
// //       teamName,
// //       teamLeadId,
// //       teamLeadName,
// //       teamMembers
// //     });

// //     // Log creation action
// //     newRequest.actionHistory.push({
// //       action: "created",
// //       by: req.body.userId || "system",
// //       remarks: "Budget request created"
// //     });

// //     await newRequest.save();
// //     res.status(201).json({ success: true, data: newRequest });
// //   } catch (error) {
// //     res.status(500).json({ success: false, message: error.message });
// //   }
// // };
// exports.createBudgetRequest = async (req, res) => {

//   try {

//     const {

//       projectId,

//       requestType,

//       title,

//       description,

//       requestedAmount,

//       currency,

//       teamId,

//       teamName,

//       teamLeadId,

//       teamLeadName,

//       teamMembers

//     } = req.body;
 
//     if (!projectId) {

//       return res.status(400).json({ success: false, message: "projectId is required" });

//     }
 
//     // 1️⃣ Extract the middle part (between dashes) of projectId

//     // Example: "AAS-IT-TES" → "TES"

//     const parts = projectId.split('-');

//     const projectPrefix = parts.length >= 3 ? parts[2].toUpperCase() : parts[0].substring(0, 3).toUpperCase();
 
//     // 2️⃣ Count previous requests for this projectId

//     const count = await BudgetRequest.countDocuments({ projectId });
 
//     // 3️⃣ Create requestId

//     const requestId = `Req-${projectPrefix}-${String(count + 1).padStart(3, '0')}`;
 
//     // 4️⃣ Create new BudgetRequest

//     const newRequest = new BudgetRequest({

//       requestId,

//       projectId,

//       requestType,

//       title,

//       description,

//       requestedAmount,

//       currency,

//       teamId,

//       teamName,

//       teamLeadId,

//       teamLeadName,

//       teamMembers

//     });
 
//     // Log creation action

//     newRequest.actionHistory.push({

//       action: "created",

//       by: req.body.userId || "system",

//       remarks: "Budget request created"

//     });
 
//     await newRequest.save();

//     res.status(201).json({ success: true, data: newRequest });
 
//   } catch (error) {

//     res.status(500).json({ success: false, message: error.message });

//   }

// };

 
// /* -------------------------
//    Get All Budget Requests
// ------------------------- */
// exports.getAllBudgetRequests = async (req, res) => {
//   try {
//     const requests = await BudgetRequest.find({ isDeleted: false });
//     res.status(200).json({ success: true, data: requests });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// /* -------------------------
//    Get Budget Request by ID
// ------------------------- */
// exports.getBudgetRequestById = async (req, res) => {
//   try {
//     const request = await BudgetRequest.findById(req.params.id);
//     if (!request || request.isDeleted) {
//       return res.status(404).json({ success: false, message: "Budget request not found" });
//     }
//     res.status(200).json({ success: true, data: request });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// /* -------------------------
//    Update Budget Request
// ------------------------- */
// exports.updateBudgetRequest = async (req, res) => {
//   try {
//     const request = await BudgetRequest.findById(req.params.id);
//     if (!request || request.isDeleted) {
//       return res.status(404).json({ success: false, message: "Budget request not found" });
//     }

//     const updates = req.body;
//     Object.assign(request, updates);

//     // Log update action
//     request.actionHistory.push({
//       action: "edited",
//       by: req.body.userId || "system",
//       remarks: updates.remarks || "Budget request updated"
//     });

//     await request.save();
//     res.status(200).json({ success: true, data: request });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// /* -------------------------
//    Delete Budget Request (Soft Delete)
// ------------------------- */
// exports.deleteBudgetRequest = async (req, res) => {
//   try {
//     const request = await BudgetRequest.findById(req.params.id);
//     if (!request || request.isDeleted) {
//       return res.status(404).json({ success: false, message: "Budget request not found" });
//     }

//     request.isDeleted = true;

//     // Log deletion
//     request.actionHistory.push({
//       action: "deleted",
//       by: req.body.userId || "system",
//       remarks: "Budget request deleted"
//     });

//     await request.save();
//     res.status(200).json({ success: true, message: "Budget request deleted successfully" });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// /* -------------------------
//    Update Status of Budget Request
// ------------------------- */
// exports.updateBudgetRequestStatus = async (req, res) => {
//   try {
//     const { status, remarks } = req.body;
//     const request = await BudgetRequest.findById(req.params.id);

//     if (!request || request.isDeleted) {
//       return res.status(404).json({ success: false, message: "Budget request not found" });
//     }

//     if (!["created", "pending", "approved", "deleted", "revision"].includes(status)) {
//       return res.status(400).json({ success: false, message: "Invalid status" });
//     }

//     request.status = status;
//     request.statusHistory.push({
//       status,
//       by: req.body.userId || "system",
//       remarks: remarks || ""
//     });

//     // Log status update
//     request.actionHistory.push({
//       action: `status_${status}`,
//       by: req.body.userId || "system",
//       remarks: remarks || `Status changed to ${status}`
//     });

//     await request.save();
//     res.status(200).json({ success: true, data: request });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };







const BudgetRequest = require('../../Model/BudgetModel/Budget');
 
exports.createBudgetRequest = async (req, res) => {
 
  try {
 
    const {
 
      projectId,
 
      requestType,
 
      title,
 
      description,
 
      requestedAmount,
 
      currency,
 
      teamId,
 
      teamName,
 
      teamLeadId,
 
      teamLeadName,
 
      teamMembers
 
    } = req.body;
 
    if (!projectId) {
 
      return res.status(400).json({ success: false, message: "projectId is required" });
 
    }
 
    //  Extract the middle part (between dashes) of projectId
 
    // Example: "AAS-IT-TES" → "TES"
 
    const parts = projectId.split('-');
 
    const projectPrefix = parts.length >= 3 ? parts[2].toUpperCase() : parts[0].substring(0, 3).toUpperCase();
 
    //  Count previous requests for this projectId
 
    const count = await BudgetRequest.countDocuments({ projectId });
 
    //  Create requestId
 
    const requestId = `Req-${projectPrefix}-${String(count + 1).padStart(3, '0')}`;
 
    //  Create new BudgetRequest
 
    const newRequest = new BudgetRequest({
 
      requestId,
 
      projectId,
 
      requestType,
 
      title,
 
      description,
 
      requestedAmount,
 
      currency,
 
      teamId,
 
      teamName,
 
      teamLeadId,
 
      teamLeadName,
 
      teamMembers
 
    });
 
    // Log creation action
 
    newRequest.actionHistory.push({
 
      action: "created",
 
      by: req.body.userId || "system",
 
      remarks: "Budget request created"
 
    });
 
    await newRequest.save();
 
    res.status(201).json({ success: true, data: newRequest });
 
  } catch (error) {
 
    res.status(500).json({ success: false, message: error.message });
 
  }
 
};
 
/* -------------------------
   Get All Budget Requests
------------------------- */
exports.getAllBudgetRequests = async (req, res) => {
  try {
    const requests = await BudgetRequest.find({ isDeleted: false });
    res.status(200).json({ success: true, data: requests });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
 
/* -------------------------
   Get Budget Request by ID
------------------------- */
exports.getBudgetRequestById = async (req, res) => {
  try {
    const { requestId } = req.params;
 
    const request = await BudgetRequest.findOne({ requestId, isDeleted: false });
 
    if (!request) {
      return res.status(404).json({ success: false, message: "Budget request not found" });
    }
 
    res.status(200).json({ success: true, data: request });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
 
/* -------------------------
   Update Budget Request
------------------------- */
exports.updateBudgetRequest = async (req, res) => {
   try {
    const { requestId } = req.params;
 
    const request = await BudgetRequest.findOne({ requestId, isDeleted: false });
    if (!request) {
      return res.status(404).json({ success: false, message: "Budget request not found" });
    }
 
    const updates = req.body;
    Object.assign(request, updates);
 
    // Log update action
    request.actionHistory.push({
      action: "edited",
      by: req.body.userId || "system",
      remarks: updates.remarks || "Budget request updated"
    });
 
    await request.save();
    res.status(200).json({ success: true, data: request });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
 
/* -------------------------
   Delete Budget Request (Soft Delete)
------------------------- */
// exports.deleteBudgetRequest = async (req, res) => {
//    try {
//     const { requestId } = req.params;
 
//     const request = await BudgetRequest.findOne({ requestId, isDeleted: false });
//     if (!request) {
//       return res.status(404).json({ success: false, message: "Budget request not found" });
//     }
 
//     request.isDeleted = true;
 
//     // Log deletion
//     request.actionHistory.push({
//       action: "deleted",
//       by: req.body.userId || "system",
//       remarks: "Budget request deleted"
//     });
 
//     await request.save();
//     res.status(200).json({ success: true, message: "Budget request deleted successfully" });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };
 

exports.deleteBudgetRequest = async (req, res) => {
  try {
    const { requestId } = req.params;
    const { userId } = req.query;

    const request = await BudgetRequest.findOne({ requestId, isDeleted: false });
    if (!request) {
      return res.status(404).json({ success: false, message: "Budget request not found" });
    }

    request.isDeleted = true;

    // Log deletion
    request.actionHistory.push({
      action: "deleted",
      by: userId || "system",
      remarks: "Budget request deleted"
    });

    await request.save();
    res.status(200).json({ success: true, message: "Budget request deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


exports.getAllBudgetRequestsByProjectId = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    //  Validate projectId
    if (!projectId) {
      return res.status(400).json({
        success: false,
        message: "Project ID is required",
      });
    }
 
    // Fetch all active (non-deleted) budget requests for this project
    const budgetRequests = await BudgetRequest.find({
      projectId,
      isDeleted: false,
    })
      .sort({ createdAt: -1 }); // newest first
 
    // If none found
    if (!budgetRequests || budgetRequests.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No budget requests found for project ID: ${projectId}`,
      });
    }
 
    // Return data
    res.status(200).json({
      success: true,
      count: budgetRequests.length,
      data: budgetRequests,
    });
 
  } catch (error) {
    console.error("Error fetching budget requests:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching budget requests",
      error: error.message,
    });
  }
};
 
/* -------------------------
   Update Status of Budget Request
------------------------- */
exports.updateBudgetRequestStatus = async (req, res) => {
  try {
    const { requestId } = req.params;
    const { status, remarks } = req.body;
 
    const request = await BudgetRequest.findOne({ requestId, isDeleted: false });
    if (!request) {
      return res.status(404).json({ success: false, message: "Budget request not found" });
    }
 
    if (!["created", "pending", "approved", "deleted", "rejected","revision"].includes(status)) {
      return res.status(400).json({ success: false, message: "Invalid status" });
    }
 
    request.status = status;
    request.statusHistory.push({
      status,
      by: req.body.userId || "system",
      remarks: remarks || ""
    });
 
    // Log status update
    request.actionHistory.push({
      action: `status_${status}`,
      by: req.body.userId || "system",
      remarks: remarks || `Status changed to ${status}`
    });
 
    await request.save();
    res.status(200).json({ success: true, data: request });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
 
 
