
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "arunak47.b@gmail.com",
    pass: "dhppstzoissvxshp", // ensure no spaces
  },
});
/**
 * Send Email using Gmail via Nodemailer
 * @param {string} subject - Email subject
 * @param {string} body - HTML body content
 * @param {string|string[]} toRecipients - Recipient(s)
 * @param {string|string[]} [ccRecipients=[]] - Optional CC recipient(s)
 */
 exports.sendEmail = async (subject, body, toRecipients, ccRecipients = []) => {
  console.log("called");
  
  try {
     const toList = Array.isArray(toRecipients) ? toRecipients.join(", ") : toRecipients;
    const ccList =
      ccRecipients && ccRecipients.length > 0
        ? Array.isArray(ccRecipients)
          ? ccRecipients.join(", ")
          : ccRecipients
        : undefined;

    const mailOptions = {
      from: `"AAS Technology" <arunak47.b@gmail.com>`,
      to: toList,
      cc: ccList,
      subject,
      html: body,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log("✅ Email sent successfully:", info.response);
    return true;
  } catch (error) {
    console.error("❌ Error sending email:", error.message);
    return false;
  }
};
