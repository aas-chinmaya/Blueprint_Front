const express = require('express');
const router = express.Router();
const slotController = require('../../Controller/MasterController/slotController');

// Create new slot
router.post('/createslot', slotController.createSlot);

// Get all slots
router.get('/getallslots', slotController.getAllSlots);

// Delete slot by slotNo
router.delete('/delteslot/:slotNo', slotController.deleteSlot);

module.exports = router;
