const BudgetCategory = require("../../Model/BudgetModel/BudgetCategory");

// ============================================
// Create Category (auto categoryId)
// ============================================
exports.createCategory = async (req, res) => {
  try {
    const category = await BudgetCategory.createCategoryWithId(req.body);
    res.status(201).json({
      success: true,
      message: "Budget category created successfully",
      data: category,
    });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

// ============================================
// Get All Categories
// ============================================
exports.getAllCategories = async (req, res) => {
  try {
    const { accountId, isActive } = req.query;
    const filter = {};

    if (accountId) filter.accountId = accountId;
    if (isActive !== undefined) filter.isActive = isActive === "true";

    const categories = await BudgetCategory.find(filter).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: categories.length,
      data: categories,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ============================================
// Get Category by categoryId
// ============================================
exports.getCategoryById = async (req, res) => {
  try {
    const category = await BudgetCategory.findOne({
      categoryId: req.params.categoryId,
    });

    if (!category)
      return res.status(404).json({ success: false, message: "Category not found" });

    res.status(200).json({ success: true, data: category });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ============================================
// Update Category by categoryId
// ============================================
exports.updateCategory = async (req, res) => {
  try {
    const category = await BudgetCategory.findOneAndUpdate(
      { categoryId: req.params.categoryId },
      req.body,
      { new: true, runValidators: true }
    );

    if (!category)
      return res.status(404).json({ success: false, message: "Category not found" });

    res.status(200).json({
      success: true,
      message: "Category updated successfully",
      data: category,
    });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

// ============================================
// Soft Delete Category by categoryId
// ============================================
exports.deleteCategory = async (req, res) => {
  try {
    const category = await BudgetCategory.findOneAndUpdate(
      { categoryId: req.params.categoryId },
      { isActive: false },
      { new: true }
    );

    if (!category)
      return res.status(404).json({ success: false, message: "Category not found" });

    res.status(200).json({
      success: true,
      message: "Category deleted successfully",
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};


// =================================================
// GET ALL BUDGET CATEGORIES BY ACCOUNT ID
// =================================================
exports.getCategoriesByAccountId = async (req, res) => {
  try {
    const { accountId } = req.params;

    if (!accountId) {
      return res.status(400).json({ message: "Account ID is required" });
    }

    // Fetch categories for the given accountId
    const categories = await BudgetCategory.find({ accountId }).sort({ createdAt: -1 });

    if (!categories.length) {
      return res.status(404).json({ message: "No categories found for this account ID" });
    }

    res.status(200).json({
      success: true,
      count: categories.length,
      data: categories,
    });
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching budget categories",
    });
  }
};