// utils/reminderScheduler.js
const moment = require("moment");
const sendEmail = require("../middlewares/nodemailer");

// Reminder time map (in minutes)
const reminderMinutes = {
  "5m": 5,
  "10m": 10,
  "15m": 15,
  "30m": 30,
  "45m": 45,
  "50m": 50,
};

/**
 * Schedule reminder email before meeting starts
 * @param {Object} meeting - Meeting document
 * @param {Array} recipients - List of email recipients
 */
const scheduleMeetingReminder = async (meeting, recipients) => {
  try {
    const { title, date, startTime, reminder, mode, meetingLink } = meeting;

    if (!reminder || reminder === "None") {
      console.log(`🚫 No reminder set for meeting "${title}"`);
      return;
    }

    // Calculate meeting start datetime
    const meetingDateTime = moment(
      `${moment(date).format("YYYY-MM-DD")} ${startTime}`,
      "YYYY-MM-DD HH:mm"
    );

    // Calculate reminder time
    const reminderTime = meetingDateTime.clone().subtract(reminderMinutes[reminder], "minutes");
    const now = moment();
    const delay = reminderTime.diff(now);

    if (delay <= 0) {
      console.log(`⚠️ Reminder time already passed for meeting "${title}"`);
      return;
    }

    console.log(
      `⏰ Reminder for "${title}" scheduled at ${reminderTime.format("YYYY-MM-DD HH:mm")}`
    );

    // Schedule the reminder
    setTimeout(async () => {
      try {
        if (!recipients || recipients.length === 0) {
          console.warn("⚠️ No valid recipients for reminder email");
          return;
        }

        const subject = `🔔 Reminder: Upcoming Meeting "${title}"`;
        const htmlBody = `
          <html>
            <body style="font-family: Arial, sans-serif; color: #333;">
              <h2 style="color: #0073e6;">Meeting Reminder</h2>
              <p>This is a reminder that your meeting <strong>${title}</strong> will start soon.</p>
              <p><strong>Date:</strong> ${moment(date).format("DD MMM YYYY")}</p>
              <p><strong>Start Time:</strong> ${startTime}</p>
              <p><strong>Mode:</strong> ${mode}</p>
              ${
                mode === "online" && meetingLink
                  ? `<p><strong>Join Link:</strong> <a href="${meetingLink}">${meetingLink}</a></p>`
                  : ""
              }
              <p><strong>Reminder Sent:</strong> ${reminder} before meeting</p>
              <hr/>
              <p style="color:gray;">Sent automatically by <strong>AAS Technology</strong>.</p>
            </body>
          </html>
        `;

        await sendEmail(subject, htmlBody, recipients);
        console.log(`📧 Reminder email sent for "${title}"`);
      } catch (err) {
        console.error("❌ Error sending reminder email:", err);
      }
    }, delay);
  } catch (error) {
    console.error("❌ Error scheduling reminder:", error);
  }
};

module.exports = { scheduleMeetingReminder };
