require("dotenv").config();
const express = require("express");
const path = require("path");
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const cors = require('cors');
 
const { connectDatabases } = require('./Config/db');            // db connection call
const projectRoutes = require('./Routes/ProjectRoute/ProjectRoute');  
const hrmsRoutes = require("./Routes/HrmsRoute/HrmsRoute");
const clientRoutes = require("./Routes/ClientRoute/clientRoute")
const teamRoutes = require("./Routes/TeamRoute/teamRoutes")
const taskRoutes = require("./Routes/TaskRoute/taskRoutes")
const notificationRoutes = require("./Routes/NotificationRoute/notificationRoute")
const bugRoutes = require("./Routes/BugRoute/bugRoutes")  
const logError=require("./middlewares/errorMiddleware");
const contactRoutes=require("./Routes/ContactRoute/ContactRoute")
const calenderRoutes=require("./Routes/CalenderRoute/calendarRoutes") 
const momRoutes=require("./Routes/CalenderRoute/momRoutes")
const quotationRoutes=require("./Routes/QuotationRoute/QuotationRoute")
const showCauseRoutes = require('./Routes/CalenderRoute/showCauseRoutes');
const paymentRoutes=require("./Routes/CalenderRoute/paymentRoutes")
const projectmomRoute=require("./Routes/CalenderRoute/projectmomRoute");
const subTaskRoutes=require("./Routes/TaskRoute/subTaskRoutes")
const documentRoutes=require("./Routes/ProjectRoute/DocumentRoute")
const BudgetCategoryRoutes=require("./Routes/BudgetRoute/budgetCategoryRoutes")
const BudgetRoutes=require("./Routes/BudgetRoute/BudgetRoute")
const BudgetAccountRoutes=require("./Routes/BudgetRoute/budgetAccountRoutes")
const manpowerRoutes=require("./Routes/BudgetRoute/manpowerMasterRoutes")
 const BugsRoutes=require("./Routes/BugRoute/BugsRoutes")
 const BudgetEntityRoutes=require("./Routes/BudgetRoute/BudgetEntityRoutes")
const MeetRoutes=require("./Routes/MeetRoute/MeetRoute")
 
 
//master routes
const slotRoutes=require("./Routes/MasterRoute/SlotRoute")
const serviceRoutes=require("./Routes/MasterRoute/ServiceRoute")
const industryRoutes=require("./Routes/MasterRoute/IndustryRoute")


 
const app = express();
 
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true }));// Parse JSON body
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

// app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(cookieParser());
 
// db connection call
connectDatabases().then(() => {
  const PORT =  8080;
  app.listen(PORT, () => console.log(` Server  running on port ${PORT}`));
}).catch(err => {
  console.error('Failed to start server due to DB error:', err);
});
 

 
app.use(cors({
  origin: ['http://localhost:8000',"https://aas.technology","https://hrms.aasint.com","https://aasint.com","https://aasit.ae","https://blu.aas.technology","https://tasks.aasint.com","http://localhost:3000" ], // Replace with your frontend URL
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'withCredentials'],
  credentials: true,
}));
 
app.use('/api/projects', projectRoutes);
app.use("/api/hrms", hrmsRoutes);
app.use("/api/client",clientRoutes)
app.use("/api/team",teamRoutes)
app.use("/api/task",taskRoutes)
app.use("/api/notification",notificationRoutes)
app.use('/api/bugs', bugRoutes);
app.use("/api/contact",contactRoutes)
app.use('/',calenderRoutes)

app.use('/api/mom', momRoutes);
app.use('/api/projectmom', projectmomRoute);

app.use('/api/quotation',quotationRoutes)

//masters 
app.use('/api/slot',slotRoutes)
app.use('/api/industry',industryRoutes)
app.use('/api/service',serviceRoutes)
app.use('/api/showcause', showCauseRoutes);
app.use('/api/payment',paymentRoutes);
app.use('/api/subtask', subTaskRoutes);
app.use('/api/document', documentRoutes);
app.use('/api/budget', BudgetRoutes);
app.use('/api/manpower', manpowerRoutes);
app.use('/api/budgetcategory', BudgetCategoryRoutes);
app.use('/api/budgetentity', BudgetEntityRoutes);
app.use('/api/budget', BudgetAccountRoutes);
app.use('/api/meet', MeetRoutes);
app.use('/api/bug', BugsRoutes);
 
 
app.use(logError);