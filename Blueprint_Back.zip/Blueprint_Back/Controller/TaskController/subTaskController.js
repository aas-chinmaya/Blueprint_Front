
const Notification = require('../../Model/NotificationModel/notificationModel');
 const Task = require('../../Model/TaskModel/Task');
const Bug = require('../../Model/BugModel/Bug');
const Team=require('../../Model/TeamModel/Team')
 

// exports.createSubtask = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const { title, description, assignedTo, priority, deadline } = req.body;

//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
//     if (!task) {
//       return res
//         .status(404)
//         .json({ success: false, message: "Parent task not found" });
//     }

//     // Generate subtask_id
//     let nextId = task.subtasks ? task.subtasks.length + 1 : 1;
//     const subtask_id = `${taskId}-${String(nextId).padStart(3, "0")}`;

//     // Ensure assignedTo is an array of objects
//     let assignedArray = [];
//     if (assignedTo) {
//       if (!Array.isArray(assignedTo)) assignedArray = [assignedTo];
//       else assignedArray = assignedTo;

//       assignedArray = assignedArray.map((user) => ({
//         memberId: user.memberId,
//         memberName: user.memberName,
//         role: user.role,
//       }));
//     }

//     const newSubtask = {
//       subtask_id,
//       title,
//       description,
//       assignedTo: assignedArray,
//       priority,
//       deadline,
//       status: "Pending",
//       reviewStatus: "N/A",
//       createdAt: new Date(),
//     };

//     task.subtasks.push(newSubtask);

//     // Add to task history
//     task.taskHistory.push({ action: "Subtask Created", timestamp: new Date() });

//     await task.save();

//     // Send notification to each assigned user
//     for (const user of assignedArray) {
//       const notification = new Notification({
//         recipientId: user.memberId,
//         message: `You have been assigned a new subtask "${title}" under task "${task.title}"`,
//         link: `/tasks/${taskId}/${subtask_id}`,
//       });
//       await notification.save();
//     }

//     res.status(201).json({ success: true, subtask: newSubtask });
//   } catch (error) {
//     console.error("Error creating subtask:", error);
//     res
//       .status(500)
//       .json({ success: false, message: "Error creating subtask", error: error.message });
//   }
// };

exports.createSubtask = async (req, res) => {
  try {
    const { taskId } = req.params;
    const {
      title,
      description,
      assignedTo,
      priority,
      deadline,
      actionedBy     // <-- history from frontend
    } = req.body;

    // ---- FIND PARENT TASK ----
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({ success: false, message: "Parent task not found" });
    }

    // ---- GENERATE SUBTASK ID ----
    const nextId = task.subtasks.length + 1;
    const subtask_id = `${taskId}-${String(nextId).padStart(3, "0")}`;

    // ---- NORMALIZE assignedTo ----
    const assignedArray = assignedTo
      ? (Array.isArray(assignedTo) ? assignedTo : [assignedTo]).map(u => ({
          memberId: u.memberId,
          memberName: u.memberName,
          role: u.role
        }))
      : [];

    // ---- NORMALIZE actionedBy (HISTORY) ----
    let actionedByArray = [];

    if (actionedBy) {
      const arr = Array.isArray(actionedBy) ? actionedBy : [actionedBy];

      arr.forEach(h => {
        if (!h || typeof h !== "object") return;

        actionedByArray.push({
          performedBy: h.performedBy || "System",
          note: h.note || "No note provided",
          timestamp: h.timestamp ? new Date(h.timestamp) : new Date()
        });
      });
    }

    // ---- DEFAULT ENTRY IF EMPTY ----
    if (actionedByArray.length === 0) {
      actionedByArray.push({
        performedBy: "System",
        note: "Subtask created",
        timestamp: new Date()
      });
    }

    // ---- BUILD SUBTASK OBJECT ----
    const newSubtask = {
      subtask_id,
      title,
      description,
      assignedTo: assignedArray,
      priority: priority || "Medium",
      deadline,
      status: "Pending",
      reviewStatus: "N/A",
      createdAt: new Date(),
      actionedBy: actionedByArray,   // <-- PROPER ARRAY STORED
      taskHistory: []                // empty is allowed
    };

    // ---- SAVE INTO PARENT TASK ----
    task.subtasks.push(newSubtask);

    // ---- SAVE HISTORY IN MAIN TASK ----
    task.taskHistory.push({
      action: "Subtask Created",
      timestamp: new Date()
    });

    await task.save();

    // ---- SEND NOTIFICATIONS ----
    if (assignedArray.length > 0) {
      for (const user of assignedArray) {
        await new Notification({
          recipientId: user.memberId,
          message: `You have been assigned a new subtask "${title}" under task "${task.title}"`,
          link: `/tasks/${taskId}/${subtask_id}`
        }).save();
      }
    }

    return res.status(201).json({ success: true, subtask: newSubtask });

  } catch (error) {
    console.error("Error creating subtask:", error);
    return res.status(500).json({
      success: false,
      message: "Error creating subtask",
      error: error.message
    });
  }
};









exports.getAllSubtasks = async (req, res) => {
  try {
    const { taskId } = req.params;

    // Step 1: Find parent task
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({
        success: false,
        message: "Task not found",
      });
    }

    // Step 2: Filter & sort subtasks
    const subtasks = task.subtasks
      .filter(st => st.isDeleted === false)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    // Step 3: Fetch all bugs for this task
    const allBugs = await Bug.find({ taskRef: task.task_id }).sort({ createdAt: -1 }).lean();

    // Step 4: Enrich subtasks with related bugs and resolve flags
    const enrichedSubtasks = subtasks.map(subtask => {
      // 🔹 Get only bugs related to this specific subtask
      const subtaskBugs = allBugs.filter(bug => bug.subtaskRef === subtask.subtask_id);

      // 🔹 Add isResolved flag for each bug
      const formattedBugs = subtaskBugs.map(bug => ({
        _id: bug._id,
        bug_id: bug.bug_id,
        title: bug.title,
        description: bug.description,
        taskRef: bug.taskRef,
        subtaskRef: bug.subtaskRef || null,
        assignedTo: bug.assignedTo,
        projectId: bug.projectId,
        deadline: bug.deadline,
        priority: bug.priority,
        status: bug.status,
        attachment: bug.attachment || null,
        createdAt: bug.createdAt,
        __v: bug.__v,
        isResolved:
          bug.status?.toLowerCase() === "resolved" ||
          bug.status?.toLowerCase() === "closed"
            ? true
            : false,
      }));

      // 🔹 Subtask-level isResolved (true if all bugs resolved/closed)
      const isResolved =
        formattedBugs.length === 0
          ? true
          : formattedBugs.every(b => b.isResolved === true);

      return {
        ...subtask.toObject(),
        bugs: formattedBugs,
        isResolved,
      };
    });

    // Step 5: Response
    return res.status(200).json({
      success: true,
      count: enrichedSubtasks.length,
      subtasks: enrichedSubtasks,
    });
  } catch (error) {
    console.error("Error fetching subtasks:", error);
    return res.status(500).json({
      success: false,
      message: "Error fetching subtasks",
      error: error.message,
    });
  }
};


exports.getSubtaskById = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;

    // Find the parent task
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({ success: false, message: "Task not found" });
    }

    // Find subtask within the task
    const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
    if (!subtask) {
      return res.status(404).json({ success: false, message: "Subtask not found" });
    }

    // Fetch project teams
    const projectId = task.projectId;
    const teams = await Team.find({ projectId, isDeleted: false });

    // Find assigned member + team
    let assignedMember = null;
    let assignedTeam = null;

    for (const team of teams) {
      const member = team.teamMembers.find(m => m.memberId === subtask.assignedTo);
      if (member) {
        assignedMember = member;
        assignedTeam = team;
        break;
      }
    }

    // Assigned member details
    const assignedToDetails = assignedMember
      ? {
          _id: assignedMember._id,
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
          email: assignedMember.email,
          role: assignedMember.role,
        }
      : null;

    // Assigned by (if exists)
    const assignedBy = task.assignedBy ? { assignedBy: task.assignedBy } : null;

    // Fetch bugs for this specific subtask
    const subtaskBugs = await Bug.find({
      taskRef: task.task_id,
      subtaskRef: subtask.subtask_id, // strict match for subtask
    }).sort({ createdAt: -1 });

    // Determine if subtask is fully resolved
    const isResolved =
      subtaskBugs.length === 0
        ? true
        : subtaskBugs.every(
            bug => bug.status.toLowerCase() === "resolved" || bug.status.toLowerCase() === "closed"
          );

    // Prepare enriched subtask
    const enrichedSubtask = {
      ...subtask.toObject(),
      teamLeadId: assignedTeam ? assignedTeam.teamLeadId : null,
      assignedToDetails,
      assignedBy,
      isResolved,
      bugs: subtaskBugs.map(bug => ({
        _id: bug._id,
        bug_id: bug.bug_id,
        title: bug.title,
        description: bug.description,
        taskRef: bug.taskRef,
        subtaskRef: bug.subtaskRef,
        assignedTo: bug.assignedTo,
        projectId: bug.projectId,
        deadline: bug.deadline,
        priority: bug.priority,
        status: bug.status,
        attachment: bug.attachment || null,
        createdAt: bug.createdAt,
        isResolved:
          bug.status.toLowerCase() === "resolved" || bug.status.toLowerCase() === "closed",
        __v: bug.__v,
      })),
    };

    // Enriched parent task (without subtask-level bugs)
    const enrichedTask = {
      task_id: task.task_id,
      title: task.title,
      description: task.description,
      status: task.status,
      priority: task.priority,
      deadline: task.deadline,
      projectId: task.projectId,
      assignedBy: task.assignedBy,
    };

    // Final response
    res.status(200).json({
      success: true,
      task: enrichedTask,
      subtask: enrichedSubtask,
    });
  } catch (error) {
    console.error("Error in getSubtaskById:", error);
    res.status(500).json({
      success: false,
      message: "Failed to get subtask with task & bugs",
      error: error.message,
    });
  }
};


// exports.editSubtask = async (req, res) => {
//   try {
//     const { taskId, subtaskId } = req.params;
//     const updates = { ...req.body };

//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
//     if (!task)
//       return res.status(404).json({ success: false, message: "Task not found" });

//     const subtask = task.subtasks.find(
//       (st) => st.subtask_id === subtaskId && !st.isDeleted
//     );
//     if (!subtask)
//       return res.status(404).json({ success: false, message: "Subtask not found" });

//     // AssignedTo cleanup
//     if (updates.assignedTo) {
//       updates.assignedTo = Array.isArray(updates.assignedTo)
//         ? updates.assignedTo
//         : [updates.assignedTo];

//       updates.assignedTo = updates.assignedTo.map((user) => ({
//         memberId: user.memberId,
//         memberName: user.memberName,
//         role: user.role,
//       }));
//     }

//     // Apply updates
//     Object.assign(subtask, updates, { updatedAt: new Date() });

//     // Add ONLY frontend-sent subtaskHistory (exact format)
//     if (updates.subtaskHistory) {
//       // frontend can send a single object or an array
//       const historyArray = Array.isArray(updates.subtaskHistory)
//         ? updates.subtaskHistory
//         : [updates.subtaskHistory];

//       historyArray.forEach((h) => {
//         subtask.subtaskHistory.push({
//           performedBy: h.performedBy,
//           note: h.note,
//           timestamp: h.timestamp,
//         });
//       });
//     }

//     await task.save();

//     res.json({ success: true, subtask });
//   } catch (error) {
//     console.error("Error updating subtask:", error);
//     res.status(500).json({
//       success: false,
//       message: "Error updating subtask",
//       error: error.message,
//     });
//   }
// };




// exports.editSubtask = async (req, res) => {
//   try {
//     const { taskId, subtaskId } = req.params;
//     const updates = { ...req.body };

//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
//     if (!task)
//       return res.status(404).json({ success: false, message: "Task not found" });

//     const subtask = task.subtasks.find(
//       (st) => st.subtask_id === subtaskId && !st.isDeleted
//     );
//     if (!subtask)
//       return res
//         .status(404)
//         .json({ success: false, message: "Subtask not found" });

//     // If assignedTo is provided, ensure it's an array of objects
//     if (updates.assignedTo) {
//       if (!Array.isArray(updates.assignedTo)) {
//         updates.assignedTo = [updates.assignedTo]; // wrap single object into array
//       }
//       updates.assignedTo = updates.assignedTo.map((user) => ({
//         memberId: user.memberId,
//         memberName: user.memberName,
//         role: user.role,
//       }));
//     }

//     // If reviewStatus is "Approved", ensure it is correctly set
//     if (updates.reviewStatus && updates.reviewStatus === "Approved") {
//       subtask.reviewStatus = "Approved";
//     }

//     // Apply updates to subtask and set updatedAt field
//     Object.assign(subtask, updates, { updatedAt: new Date() });

//     // Add history for task update
//     task.taskHistory.push({
//       action: "Subtask Updated",
//       timestamp: new Date(),
//       reviewStatus: subtask.reviewStatus, // Store the new reviewStatus in history
//     });

//     await task.save();

//     res.json({ success: true, subtask });
//   } catch (error) {
//     console.error("Error updating subtask:", error);
//     res
//       .status(500)
//       .json({ success: false, message: "Error updating subtask", error: error.message });
//   }
// };





 
// Soft delete subtask
// exports.softDeleteSubtask = async (req, res) => {
//   try {
//     const { taskId, subtaskId } = req.params;
 
//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
//     if (!task) return res.status(404).json({ success: false, message: "Task not found" });
 
//     const subtask = task.subtasks.find(st => st.subtask_id === subtaskId);
//     if (!subtask) return res.status(404).json({ success: false, message: "Subtask not found" });
 
//     subtask.isDeleted = true;
 
//     // Add history
//     task.taskHistory.push({ action: "Subtask Deleted", timestamp: new Date() });
 
//     await task.save();
 
//     res.json({ success: true, message: "Subtask deleted successfully" });
//   } catch (error) {
//     res.status(500).json({ success: false, message: "Error deleting subtask", error: error.message });
//   }
// };
 


exports.editSubtask = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;
    const updates = { ...req.body };

    // ---- FIND TASK ----
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task)
      return res.status(404).json({ success: false, message: "Task not found" });

    // ---- FIND SUBTASK ----
    const subtask = task.subtasks.find(
      (st) => st.subtask_id === subtaskId && !st.isDeleted
    );
    if (!subtask)
      return res.status(404).json({ success: false, message: "Subtask not found" });

    // ---- ENSURE ARRAYS ----
    if (!Array.isArray(subtask.actionedBy)) subtask.actionedBy = [];
    if (!Array.isArray(subtask.taskHistory)) subtask.taskHistory = [];

    // ---- NORMALIZE assignedTo ----
    if (updates.assignedTo) {
      const arr = Array.isArray(updates.assignedTo)
        ? updates.assignedTo
        : [updates.assignedTo];

      updates.assignedTo = arr.map((user) => ({
        memberId: user.memberId,
        memberName: user.memberName,
        role: user.role
      }));
    }

    // ❗❗ IMPORTANT FIX — prevent overwrite of actionedBy
    const actionHistory = updates.actionedBy;
    delete updates.actionedBy;

    // ---- APPLY UPDATES (SAFE) ----
    Object.assign(subtask, updates, { updatedAt: new Date() });

    // ---- ADD NEW ACTION HISTORY ENTRY ----
    let entry = null;

    if (actionHistory) {
      const h = Array.isArray(actionHistory)
        ? actionHistory[0]
        : actionHistory;

      entry = {
        performedBy: h.performedBy || "System",
        note: h.note || "Updated subtask",
        timestamp: h.timestamp ? new Date(h.timestamp) : new Date()
      };
    } else {
      entry = {
        performedBy: "System",
        note: "Updated subtask",
        timestamp: new Date()
      };
    }

    subtask.actionedBy.push(entry);

    // ---- PARENT HISTORY ----
    task.taskHistory.push({
      action: `Subtask Updated (${subtaskId})`,
      timestamp: new Date()
    });

    // ---- SAVE ----
    await task.save();

    return res.json({ success: true, subtask });

  } catch (error) {
    console.error("Error updating subtask:", error);
    return res.status(500).json({
      success: false,
      message: "Error updating subtask",
      error: error.message
    });
  }
};











exports.softDeleteSubtask = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;
    const { subtaskHistory } = req.body; // frontend sends history

    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({ success: false, message: "Task not found" });
    }

    const subtask = task.subtasks.find(st => st.subtask_id === subtaskId);
    if (!subtask) {
      return res.status(404).json({ success: false, message: "Subtask not found" });
    }

    // Soft delete
    subtask.isDeleted = true;

    // ✅ Add ONLY frontend-sent subtaskHistory in exact format
    if (subtaskHistory) {
      const historyArray = Array.isArray(subtaskHistory) ? subtaskHistory : [subtaskHistory];

      historyArray.forEach(h => {
        subtask.subtaskHistory.push({
          performedBy: h.performedBy,
          note: h.note,
          timestamp: h.timestamp
        });
      });
    }

    await task.save();

    res.json({
      success: true,
      message: "Subtask deleted successfully",
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error deleting subtask",
      error: error.message,
    });
  }
};



exports.updateSubtaskStatusById = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;
    const { status, actionedBy } = req.body;

    // Allowed statuses
    const validStatuses = ["Pending", "In Progress", "Completed", "Approved", "Rejected"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status. Must be Pending, In Progress, Completed, Approved, or Rejected.",
      });
    }

    // ----------------------
    // Find parent task
    // ----------------------
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({ success: false, message: "Task not found" });
    }

    // ----------------------
    // Find embedded subtask
    // ----------------------
    const subtask = task.subtasks.find(
      (st) => st.subtask_id === subtaskId && !st.isDeleted
    );

    if (!subtask) {
      return res.status(404).json({ success: false, message: "Subtask not found" });
    }

    // ----------------------
    // Update status
    // ----------------------
    subtask.status = status;

    // Mark as completed/approved
    if (["Completed", "Approved"].includes(status)) {
      if (!subtask.completedAt) {
        subtask.completedAt = new Date();
      }

      subtask.isLate =
        subtask.deadline && new Date() > new Date(subtask.deadline);
    }

    // ----------------------
    // Push History Entry
    // ----------------------
    const historyEntry = {
      performedBy: actionedBy?.performedBy || "System",
      note: actionedBy?.note || `Status updated to ${status}`,
      timestamp: actionedBy?.timestamp ? new Date(actionedBy.timestamp) : new Date(),
      status: status, // 👈 store changed status ALSO
    };

    subtask.subtaskHistory.push(historyEntry);

    // Save the updated task
    await task.save();

    // ----------------------
    // Send Notifications
    // ----------------------
    if (Array.isArray(subtask.assignedTo)) {
      await Promise.all(
        subtask.assignedTo.map(async (m) => {
          const recipientId = m.memberId || m._id;
          if (!recipientId) return;

          const notification = new Notification({
            recipientId,
            message: `Subtask "${subtask.title}" is now ${status}`,
            link: `/tasks/${taskId}/subtasks/${subtaskId}`,
          });

          await notification.save();
        })
      );
    }

    // ----------------------
    // Response
    // ----------------------
    res.status(200).json({
      success: true,
      message: "Subtask status updated successfully",
      subtask,
    });

  } catch (err) {
    console.error("Error updating subtask status:", err);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};







// exports.updateSubtaskStatusById = async (req, res) => {
//   try {
//     const { taskId, subtaskId } = req.params;
//     const { status } = req.body;

//     // Allowed statuses
//     const validStatuses = ['Pending', 'In Progress', 'Completed', 'Approved', 'Rejected'];
//     if (!validStatuses.includes(status)) {
//       return res.status(400).json({
//         success: false,
//         message: 'Invalid status. Must be Pending, In Progress, or Completed.',
//       });
//     }

//     // Find parent task
//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
//     if (!task) {
//       return res.status(404).json({ success: false, message: 'Task not found' });
//     }

//     // Find subtask inside task
//     const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
//     if (!subtask) {
//       return res.status(404).json({ success: false, message: 'Subtask not found' });
//     }

//     // Update subtask status
//     subtask.status = status;

//     // If subtask is marked completed, set completedAt and check if late
//     if (status === 'Approved' || status === 'Completed') {
//       if (!subtask.completedAt) subtask.completedAt = new Date();
//       if (subtask.deadline && new Date() > new Date(subtask.deadline)) {
//         subtask.isLate = true;
//       } else {
//         subtask.isLate = false;
//       }
//     }

//     // Add history entry
//     task.taskHistory.push({ action: `Subtask "${subtask.title}" marked ${status}`, timestamp: new Date() });

//     // Save task updates
//     await task.save();

//     // Create notifications for assigned users (if assignedTo is an array)
//     if (subtask.assignedTo && Array.isArray(subtask.assignedTo) && subtask.assignedTo.length > 0) {
//       for (const user of subtask.assignedTo) {
//         const recipientId = user.memberId || user._id; // pick correct ID
//         if (recipientId) {
//           const notification = new Notification({
//             recipientId,
//             message: `Subtask "${subtask.title}" is now marked as ${status}`,
//             link: `/tasks/${taskId}/subtasks/${subtaskId}`,
//           });
//           await notification.save();
//         }
//       }
//     }

//     res.status(200).json({
//       success: true,
//       message: 'Subtask status updated successfully',
//       subtask,
//     });

//   } catch (err) {
//     console.error('Error updating subtask status:', err);
//     res.status(500).json({
//       success: false,
//       message: 'Internal server error',
//     });
//   }
// };



//  Fetch only subtasks assigned to a user (with task_id & projectName)
exports.getTasksByAssignedTo = async (req, res) => {
  try {
    const { assignedTo } = req.params;

    if (!assignedTo) {
      return res.status(400).json({ message: "assignedTo is required" });
    }

    // Use aggregation to get only matching subtasks + parent info
    const tasks = await Task.aggregate([
      { $match: { "subtasks.assignedTo": assignedTo, isDeleted: false } },
      { $unwind: "$subtasks" },
      { 
        $match: { 
          "subtasks.assignedTo": assignedTo, 
          "subtasks.isDeleted": false 
        } 
      },
      {
        $project: {
          _id: 0,
          task_id: 1,
          projectName: 1,
          projectId: 1,
          subtask: "$subtasks",
        },
      },
      { $sort: { "subtask.createdAt": -1 } },
    ]);

    if (!tasks || tasks.length === 0) {
      return res.status(404).json({ message: "No subtasks found for this user" });
    }

    res.status(200).json({
      success: true,
      count: tasks.length,
      subtasks: tasks.map(t => ({
        task_id: t.task_id,
        projectName: t.projectName,
        projectId: t.projectId,
        ...t.subtask,
      })),
    });
  } catch (error) {
    console.error("Error fetching subtasks by assignedTo:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};