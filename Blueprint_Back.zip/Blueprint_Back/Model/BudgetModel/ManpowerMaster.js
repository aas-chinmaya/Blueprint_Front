const mongoose = require("mongoose");

const manpowerMasterSchema = new mongoose.Schema(
  {
    manpowerId: {
      type: String,
      unique: true,
      trim: true,
    },

    // Example: Developer, Designer, Tester, Project Manager
    department: {
      type: String,
      required: true,
      trim: true,
    },

    // Example: Frontend Developer, Backend Developer, Full Stack Developer
    role: {
      type: String,
      required: true,
      trim: true,
    },

    // Example: Junior, Mid-Level, Senior, Expert
    level: {
      type: String,
      required: true,
      trim: true,
      enum: 
      ["Intern",
  "Trainee",
  "Junior",
  "Senior",
  "Lead",
  "Manager",
  "Executive"],
    },

    // Main technical skill
    primarySkill: {
      type: String,
      required: true,
      trim: true,
    },

    // Experience in years range
    experienceRange: {
      min: { type: Number, required: true },
      max: { type: Number, required: true },
    },

    // Cost type
    costType: {
      type: String,
      required: true,
      enum: ["hourly", "monthly", "fixed"],
      default: "hourly",
    },

    // Rate
    rate: {
      type: Number,
      required: true,
      min: 0,
    },

    // Currency
    currency: {
      type: String,
      default: "INR",
      trim: true,
    },

    // Optional description
    description: {
      type: String,
      trim: true,
    },

    // Status
    isActive: {
      type: Boolean,
      default: true,
    },

    // Soft delete
    isDeleted: {
      type: Boolean,
      default: false,
    },

    // Audit info
    createdBy: {
      type: String,
      default: "System",
    },
    editedBy: {
      type: String,
      default: null,
    },
  },
  { timestamps: true }
);

// ===================================================
// STATIC METHOD — CREATE WITH AUTO manpowerId
// ===================================================
manpowerMasterSchema.statics.createManpowerWithId = async function (data) {
  const lastRecord = await this.findOne().sort({ createdAt: -1 });

  let nextNumber = 1000;
  if (lastRecord && lastRecord.manpowerId) {
    const lastNum = parseInt(lastRecord.manpowerId.split("-")[1]);
    if (!isNaN(lastNum)) nextNumber = lastNum + 1;
  }

  const manpowerId = `WFID-${nextNumber}`;
  const newRecord = new this({
    manpowerId,
    ...data,
  });

  return await newRecord.save();
};

module.exports = mongoose.model("ManpowerMaster", manpowerMasterSchema);
