// const mongoose = require('mongoose');
 
// const bugSchema = new mongoose.Schema({

//   bug_id: { type: String, unique: true },

//   title: { type: String, required: true },

//   description: { type: String },

//   taskRef: { type: String, ref: 'Task' },

//   assignedTo: { type: String, required: true },

//   projectId: { type: String, required: true },

//   deadline: { type: String },

//   priority: { 

//     type: String, 

//     enum: ['Low', 'Medium', 'High', 'Critical'], 

//     default: 'Low' 

//   },

//   status: { 

//     type: String, 

//     enum: ['Open', 'Resolved', 'Closed'], 

//     default: 'Open' 

//   },
//   bugImage: { type: String }  ,

//   createdAt: { type: Date, default: Date.now },

//   delayReason: { type: String },

//   resolvedAt: { type: Date },
 
//   // 🔹 New field to store how the bug was fixed

//   resolutionNote: { type: String }

// });
 
// // Auto-generate Bug ID

// bugSchema.statics.createBugWithId = async function (bugData) {

//   const lastBug = await this.findOne().sort({ createdAt: -1 });

//   let nextId = 1;

//   if (lastBug && lastBug.bug_id) {

//     const lastIdNum = parseInt(lastBug.bug_id.split('-')[1]);

//     nextId = lastIdNum + 1;

//   }

//   const bug_id = `BUG-${String(nextId).padStart(3, '0')}`;

//   const newBug = new this({ bug_id, ...bugData });

//   return newBug.save();

// };
 
// // 🔹 Middleware: if status = Resolved, resolutionNote must be provided

// bugSchema.pre('save', function (next) {

//   if (this.status === 'Resolved' && !this.resolutionNote) {

//     return next(new Error('Resolution note is required when marking bug as Resolved'));

//   }

//   next();

// });
 
// module.exports = mongoose.model('Bug', bugSchema);

 const mongoose = require('mongoose');
 
const bugSchema = new mongoose.Schema({
 
  bug_id: { type: String, unique: true },
 
  title: { type: String, required: true },
 
  description: { type: String },
 
  taskRef: { type: String, ref: 'Task' },
  
  subtaskRef: { type: String, ref: "SubTask" }, 
 
  assignedTo: { type: String},
 
  projectId: { type: String, required: true },
  projectName:{type:String},

 
  deadline: { type: Date },
 
  priority: {
 
    type: String,
 
    enum: ['Low', 'Medium', 'High', 'Critical'],
 
    default: 'Low'
 
  },
 
  status: {
 
    type: String,
 
    enum: ['Open', 'Resolved', 'Closed'],
 
    default: 'Open'
 
  },
 
  createdAt: { type: Date, default: Date.now },
 
  delayReason: { type: String },
 
  resolvedAt: { type: Date },
 
  // 🔹 New field to store how the bug was fixed
 
  resolutionNote: { type: String },
    attachment: { type: String }
 
});
 
// Auto-generate Bug ID
 
bugSchema.statics.createBugWithId = async function (bugData) {
 
  const lastBug = await this.findOne().sort({ createdAt: -1 });
 
  let nextId = 1;
 
  if (lastBug && lastBug.bug_id) {
 
    const lastIdNum = parseInt(lastBug.bug_id.split('-')[1]);
 
    nextId = lastIdNum + 1;
 
  }
 
  const bug_id = `BUG-${String(nextId).padStart(3, '0')}`;
 
  const newBug = new this({ bug_id, ...bugData });
 
  return newBug.save();
 
};
 
// 🔹 Middleware: if status = Resolved, resolutionNote must be provided
 
bugSchema.pre('save', function (next) {
 
  if (this.status === 'Resolved' && !this.resolutionNote) {
 
    return next(new Error('Resolution note is required when marking bug as Resolved'));
 
  }
 
  next();
 
});
 
module.exports = mongoose.model('Bug', bugSchema);
 
 