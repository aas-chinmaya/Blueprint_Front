const Razorpay = require("razorpay");

const razorpay = new Razorpay({
  key_id: "rzp_test_7TwhF26eOldnN8",
  key_secret: "2yBfbwAZSvUNEvrnAppdmB7M"
});

module.exports = razorpay;