
const Notification = require('../../Model/NotificationModel/notificationModel');
 const Task = require('../../Model/TaskModel/Task');
const Bug = require('../../Model/BugModel/Bug');
const Team=require('../../Model/TeamModel/Team')
 
// Create Subtask
// exports.createSubtask = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const { title, description, assignedTo, priority, deadline } = req.body;
 
//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
//     if (!task) {
//       return res.status(404).json({ success: false, message: "Parent task not found" });
//     }
 
//     // Generate subtask_id
//     let nextId = task.subtasks ? task.subtasks.length + 1 : 1;
//     const subtask_id = `${taskId}-${String(nextId).padStart(3, '0')}`;
 
//     const newSubtask = {
//       subtask_id,
//       title,
//       description,
//       assignedTo,
//       priority,
//       deadline,
//       status: "Pending",
//       reviewStatus: "N/A",
//       createdAt: new Date()
//     };
 
//     task.subtasks.push(newSubtask);
 
//     // Add to task history
//     task.taskHistory.push({ action: "Subtask Created", timestamp: new Date() });
 
//     await task.save();
 
//     //  Send notification to the assigned user
//     if (assignedTo) {
//       const notification = new Notification({
//         recipientId: assignedTo,
//         message: `You have been assigned a new subtask "${title}" under task "${task.title}"`,
//         link: `/tasks/${taskId}/${subtask_id}`
//       });
//       await notification.save();
//     }
 
//     res.status(201).json({ success: true, subtask: newSubtask });
//   } catch (error) {
//     console.error("Error creating subtask:", error);
//     res.status(500).json({ success: false, message: "Error creating subtask", error: error.message });
//   }
// };
 

exports.createSubtask = async (req, res) => {
  try {
    const { taskId } = req.params;
    const { title, description, assignedTo, priority, deadline } = req.body;

    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res
        .status(404)
        .json({ success: false, message: "Parent task not found" });
    }

    // Generate subtask_id
    let nextId = task.subtasks ? task.subtasks.length + 1 : 1;
    const subtask_id = `${taskId}-${String(nextId).padStart(3, "0")}`;

    // Ensure assignedTo is an array of objects
    let assignedArray = [];
    if (assignedTo) {
      if (!Array.isArray(assignedTo)) assignedArray = [assignedTo];
      else assignedArray = assignedTo;

      assignedArray = assignedArray.map((user) => ({
        memberId: user.memberId,
        memberName: user.memberName,
        role: user.role,
      }));
    }

    const newSubtask = {
      subtask_id,
      title,
      description,
      assignedTo: assignedArray,
      priority,
      deadline,
      status: "Pending",
      reviewStatus: "N/A",
      createdAt: new Date(),
    };

    task.subtasks.push(newSubtask);

    // Add to task history
    task.taskHistory.push({ action: "Subtask Created", timestamp: new Date() });

    await task.save();

    // Send notification to each assigned user
    for (const user of assignedArray) {
      const notification = new Notification({
        recipientId: user.memberId,
        message: `You have been assigned a new subtask "${title}" under task "${task.title}"`,
        link: `/tasks/${taskId}/${subtask_id}`,
      });
      await notification.save();
    }

    res.status(201).json({ success: true, subtask: newSubtask });
  } catch (error) {
    console.error("Error creating subtask:", error);
    res
      .status(500)
      .json({ success: false, message: "Error creating subtask", error: error.message });
  }
};


// exports.getAllSubtasks = async (req, res) => {
//   try {
//     const { taskId } = req.params;

//     // Find the parent task (full document, no projection)
//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });

//     if (!task) {
//       return res.status(404).json({
//         success: false,
//         message: "Task not found",
//       });
//     }

//     // Filter out deleted subtasks
//     let subtasks = task.subtasks.filter(st => st.isDeleted === false);

//     //  Sort by createdAt descending
//     subtasks.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

//     //  Fetch all bugs for this task
//     const allBugs = await Bug.find({ taskRef: task.task_id }).sort({ createdAt: -1 }).lean();

//     // Enrich each subtask with bugs and isResolved flag
//     const enrichedSubtasks = subtasks.map(subtask => {
//       // Include all bugs related to this subtask
//       const subtaskBugs = allBugs.filter(
//         bug =>
//           (bug.subtaskRef && bug.subtaskRef === subtask.subtask_id) || // bug linked via subtaskRef
//           (!bug.subtaskRef && bug.assignedTo === subtask.assignedTo) // bug linked only via taskRef to this member
//       );

//       // Determine if all bugs are resolved
//       const isResolved =
//         subtaskBugs.length === 0
//           ? true
//           : subtaskBugs.every(
//               bug => bug.status.toLowerCase() === "resolved" || bug.status.toLowerCase() === "closed"
//             );

//       return {
//         ...subtask.toObject(),
//         bugs: subtaskBugs.map(bug => ({
//           _id: bug._id,
//           bug_id: bug.bug_id,
//           title: bug.title,
//           description: bug.description,
//           taskRef: bug.taskRef,
//           subtaskRef: bug.subtaskRef || null,
//           assignedTo: bug.assignedTo,
//           projectId: bug.projectId,
//           deadline: bug.deadline,
//           priority: bug.priority,
//           status: bug.status,
//           attachment: bug.attachment || null,
//           createdAt: bug.createdAt,
//           __v: bug.__v,
//         })),
//         isResolved,
//       };
//     });

//     return res.status(200).json({
//       success: true,
//       count: enrichedSubtasks.length,
//       subtasks: enrichedSubtasks,
//     });

//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: "Error fetching subtasks",
//       error: error.message,
//     });
//   }
// };

exports.getAllSubtasks = async (req, res) => {
  try {
    const { taskId } = req.params;

    // Step 1: Find parent task
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({
        success: false,
        message: "Task not found",
      });
    }

    // Step 2: Filter & sort subtasks
    const subtasks = task.subtasks
      .filter(st => st.isDeleted === false)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    // Step 3: Fetch all bugs for this task
    const allBugs = await Bug.find({ taskRef: task.task_id }).sort({ createdAt: -1 }).lean();

    // Step 4: Enrich subtasks with related bugs and resolve flags
    const enrichedSubtasks = subtasks.map(subtask => {
      // 🔹 Get only bugs related to this specific subtask
      const subtaskBugs = allBugs.filter(bug => bug.subtaskRef === subtask.subtask_id);

      // 🔹 Add isResolved flag for each bug
      const formattedBugs = subtaskBugs.map(bug => ({
        _id: bug._id,
        bug_id: bug.bug_id,
        title: bug.title,
        description: bug.description,
        taskRef: bug.taskRef,
        subtaskRef: bug.subtaskRef || null,
        assignedTo: bug.assignedTo,
        projectId: bug.projectId,
        deadline: bug.deadline,
        priority: bug.priority,
        status: bug.status,
        attachment: bug.attachment || null,
        createdAt: bug.createdAt,
        __v: bug.__v,
        isResolved:
          bug.status?.toLowerCase() === "resolved" ||
          bug.status?.toLowerCase() === "closed"
            ? true
            : false,
      }));

      // 🔹 Subtask-level isResolved (true if all bugs resolved/closed)
      const isResolved =
        formattedBugs.length === 0
          ? true
          : formattedBugs.every(b => b.isResolved === true);

      return {
        ...subtask.toObject(),
        bugs: formattedBugs,
        isResolved,
      };
    });

    // Step 5: Response
    return res.status(200).json({
      success: true,
      count: enrichedSubtasks.length,
      subtasks: enrichedSubtasks,
    });
  } catch (error) {
    console.error("Error fetching subtasks:", error);
    return res.status(500).json({
      success: false,
      message: "Error fetching subtasks",
      error: error.message,
    });
  }
};


exports.getSubtaskById = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;

    // Find the parent task
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({ success: false, message: "Task not found" });
    }

    // Find subtask within the task
    const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
    if (!subtask) {
      return res.status(404).json({ success: false, message: "Subtask not found" });
    }

    // Fetch project teams
    const projectId = task.projectId;
    const teams = await Team.find({ projectId, isDeleted: false });

    // Find assigned member + team
    let assignedMember = null;
    let assignedTeam = null;

    for (const team of teams) {
      const member = team.teamMembers.find(m => m.memberId === subtask.assignedTo);
      if (member) {
        assignedMember = member;
        assignedTeam = team;
        break;
      }
    }

    // Assigned member details
    const assignedToDetails = assignedMember
      ? {
          _id: assignedMember._id,
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
          email: assignedMember.email,
          role: assignedMember.role,
        }
      : null;

    // Assigned by (if exists)
    const assignedBy = task.assignedBy ? { assignedBy: task.assignedBy } : null;

    // Fetch bugs for this specific subtask
    const subtaskBugs = await Bug.find({
      taskRef: task.task_id,
      subtaskRef: subtask.subtask_id, // strict match for subtask
    }).sort({ createdAt: -1 });

    // Determine if subtask is fully resolved
    const isResolved =
      subtaskBugs.length === 0
        ? true
        : subtaskBugs.every(
            bug => bug.status.toLowerCase() === "resolved" || bug.status.toLowerCase() === "closed"
          );

    // Prepare enriched subtask
    const enrichedSubtask = {
      ...subtask.toObject(),
      teamLeadId: assignedTeam ? assignedTeam.teamLeadId : null,
      assignedToDetails,
      assignedBy,
      isResolved,
      bugs: subtaskBugs.map(bug => ({
        _id: bug._id,
        bug_id: bug.bug_id,
        title: bug.title,
        description: bug.description,
        taskRef: bug.taskRef,
        subtaskRef: bug.subtaskRef,
        assignedTo: bug.assignedTo,
        projectId: bug.projectId,
        deadline: bug.deadline,
        priority: bug.priority,
        status: bug.status,
        attachment: bug.attachment || null,
        createdAt: bug.createdAt,
        isResolved:
          bug.status.toLowerCase() === "resolved" || bug.status.toLowerCase() === "closed",
        __v: bug.__v,
      })),
    };

    // Enriched parent task (without subtask-level bugs)
    const enrichedTask = {
      task_id: task.task_id,
      title: task.title,
      description: task.description,
      status: task.status,
      priority: task.priority,
      deadline: task.deadline,
      projectId: task.projectId,
      assignedBy: task.assignedBy,
    };

    // Final response
    res.status(200).json({
      success: true,
      task: enrichedTask,
      subtask: enrichedSubtask,
    });
  } catch (error) {
    console.error("Error in getSubtaskById:", error);
    res.status(500).json({
      success: false,
      message: "Failed to get subtask with task & bugs",
      error: error.message,
    });
  }
};

 exports.editSubtask = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;
    const updates = { ...req.body };

    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task)
      return res.status(404).json({ success: false, message: "Task not found" });

    const subtask = task.subtasks.find(
      (st) => st.subtask_id === subtaskId && !st.isDeleted
    );
    if (!subtask)
      return res
        .status(404)
        .json({ success: false, message: "Subtask not found" });

    // If assignedTo is provided, ensure it's an array of objects
    if (updates.assignedTo) {
      if (!Array.isArray(updates.assignedTo)) {
        updates.assignedTo = [updates.assignedTo]; // wrap single object into array
      }
      updates.assignedTo = updates.assignedTo.map((user) => ({
        memberId: user.memberId,
        memberName: user.memberName,
        role: user.role,
      }));
    }

    Object.assign(subtask, updates, { updatedAt: new Date() });

    // Add history
    task.taskHistory.push({ action: "Subtask Updated", timestamp: new Date() });

    await task.save();

    res.json({ success: true, subtask });
  } catch (error) {
    console.error("Error updating subtask:", error);
    res
      .status(500)
      .json({ success: false, message: "Error updating subtask", error: error.message });
  }
};


// exports.getSubtaskById = async (req, res) => {
//   try {
//     const { taskId, subtaskId } = req.params;
 
//     //  Find the parent task
//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
//     if (!task) {
//       return res.status(404).json({ success: false, message: "Task not found" });
//     }
 
//     //  Find the subtask inside the task
//     const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
//     if (!subtask) {
//       return res.status(404).json({ success: false, message: "Subtask not found" });
//     }
 
//     // Get teams for the project
//     const projectId = task.projectId;
//     const teams = await Team.find({ projectId, isDeleted: false });
 
//     let assignedMember = null;
//     let assignedTeam = null;
 
//     //  Find the assigned member and team
//     for (const team of teams) {
//       const member = team.teamMembers.find(m => m.memberId === subtask.assignedTo);
//       if (member) {
//         assignedMember = member;
//         assignedTeam = team;
//         break;
//       }
//     }
 
//     //  AssignedTo Details
//     const assignedToDetails = assignedMember
//       ? {
//           _id: assignedMember._id,
//           memberId: assignedMember.memberId,
//           memberName: assignedMember.memberName,
//           email: assignedMember.email,
//           role: assignedMember.role,
//         }
//       : null;
 
//     //  AssignedBy details
//     const assignedBy = task.assignedBy ? { assignedBy: task.assignedBy } : null;
 
//     //  Fetch all bugs related to this parent task
//     const allTaskBugs = await Bug.find({ taskRef: task.task_id }).sort({ createdAt: -1 });
 
//     // Separate subtask-level and task-level bugs
//     // (Later when you add `subtaskRef` in Bug model, replace this logic with: { subtaskRef: subtask.subtask_id })
//     const subtaskBugs = allTaskBugs.filter(bug => bug.taskRef === task.task_id && bug.assignedTo === subtask.assignedTo);
//     const taskBugs = allTaskBugs.filter(bug => bug.taskRef === task.task_id && bug.assignedTo !== subtask.assignedTo);
 
//     //  Prepare enriched subtask data
//     const enrichedSubtask = {
//       ...subtask.toObject(),
//       teamLeadId: assignedTeam ? assignedTeam.teamLeadId : null,
//       assignedToDetails,
//       assignedBy,
//       bugs: subtaskBugs.map(bug => ({
//         _id: bug._id,
//         bug_id: bug.bug_id,
//         title: bug.title,
//         description: bug.description,
//         taskRef: bug.taskRef,
//         assignedTo: bug.assignedTo,
//         projectId: bug.projectId,
//         deadline: bug.deadline,
//         priority: bug.priority,
//         status: bug.status,
//         attachment: bug.attachment || null,
//         createdAt: bug.createdAt,
//         __v: bug.__v,
//       })),
//     };
 
//     // Prepare enriched task data
//     const enrichedTask = {
//       task_id: task.task_id,
//       title: task.title,
//       description: task.description,
//       status: task.status,
//       priority: task.priority,
//       deadline: task.deadline,
//       projectId: task.projectId,
//       assignedBy: task.assignedBy,
//       assignedTo: task.memberId,
//       bugs: taskBugs.map(bug => ({
//         _id: bug._id,
//         bug_id: bug.bug_id,
//         title: bug.title,
//         description: bug.description,
//         taskRef: bug.taskRef,
//         assignedTo: bug.assignedTo,
//         projectId: bug.projectId,
//         deadline: bug.deadline,
//         priority: bug.priority,
//         status: bug.status,
//         attachment: bug.attachment || null,
//         createdAt: bug.createdAt,
//         __v: bug.__v,
//       })),
//     };
 
//     //  Final Response
//     res.status(200).json({
//       success: true,
//       task: enrichedTask,
//       subtask: enrichedSubtask,
//     });
 
//   } catch (error) {
//     console.error("Error in getSubtaskById:", error);
//     res.status(500).json({
//       success: false,
//       message: "Failed to get subtask with task & bugs",
//       error: error.message,
//     });
//   }
// };
 
 
// Edit subtask
// exports.editSubtask = async (req, res) => {
//   try {
//     const { taskId, subtaskId } = req.params;
//     const updates = req.body;
 
//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
//     if (!task) return res.status(404).json({ success: false, message: "Task not found" });
 
//     const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
//     if (!subtask) return res.status(404).json({ success: false, message: "Subtask not found" });
 
//     Object.assign(subtask, updates, { updatedAt: new Date() });
 
//     // Add history
//     task.taskHistory.push({ action: "Subtask Updated", timestamp: new Date() });
 
//     await task.save();
 
//     res.json({ success: true, subtask });
//   } catch (error) {
//     res.status(500).json({ success: false, message: "Error updating subtask", error: error.message });
//   }
// };
 
// Soft delete subtask
exports.softDeleteSubtask = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;
 
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) return res.status(404).json({ success: false, message: "Task not found" });
 
    const subtask = task.subtasks.find(st => st.subtask_id === subtaskId);
    if (!subtask) return res.status(404).json({ success: false, message: "Subtask not found" });
 
    subtask.isDeleted = true;
 
    // Add history
    task.taskHistory.push({ action: "Subtask Deleted", timestamp: new Date() });
 
    await task.save();
 
    res.json({ success: true, message: "Subtask deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error deleting subtask", error: error.message });
  }
};
 
 
// Update Subtask Status by subtask_id
exports.updateSubtaskStatusById = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;
    const { status } = req.body;
 
    // Allowed statuses
    const validStatuses = ['Pending', 'In Progress', 'Completed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be Pending, In Progress, or Completed.',
      });
    }
 
    // Find parent task
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({ success: false, message: 'Task not found' });
    }
 
    // Find subtask inside task
    const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
    if (!subtask) {
      return res.status(404).json({ success: false, message: 'Subtask not found' });
    }
 
    // Update subtask status
    subtask.status = status;
 
    // If subtask is marked completed, set completedAt
    if (status === 'Completed' && !subtask.completedAt) {
      subtask.completedAt = new Date();
 
      if (subtask.deadline && new Date() > new Date(subtask.deadline)) {
        subtask.isLate = true;
      }
    }
 
    // Add history entry
    task.taskHistory.push({ action: `Subtask ${status}`, timestamp: new Date() });
 
    await task.save();
 
    //  Create notification for assigned user
    if (subtask.assignedTo) {
      const notification = new Notification({
        recipientId: subtask.assignedTo,
        message: `Subtask "${subtask.title}" is now marked as ${status}`,
        link: `/tasks/${taskId}/subtasks/${subtaskId}` // optional frontend link
      });
      await notification.save();
    }
 
    res.status(200).json({
      success: true,
      message: 'Subtask status updated successfully',
      subtask,
    });
  } catch (err) {
    console.error('Error updating subtask status:', err);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};



//  Fetch only subtasks assigned to a user (with task_id & projectName)
exports.getTasksByAssignedTo = async (req, res) => {
  try {
    const { assignedTo } = req.params;

    if (!assignedTo) {
      return res.status(400).json({ message: "assignedTo is required" });
    }

    // Use aggregation to get only matching subtasks + parent info
    const tasks = await Task.aggregate([
      { $match: { "subtasks.assignedTo": assignedTo, isDeleted: false } },
      { $unwind: "$subtasks" },
      { 
        $match: { 
          "subtasks.assignedTo": assignedTo, 
          "subtasks.isDeleted": false 
        } 
      },
      {
        $project: {
          _id: 0,
          task_id: 1,
          projectName: 1,
          projectId: 1,
          subtask: "$subtasks",
        },
      },
      { $sort: { "subtask.createdAt": -1 } },
    ]);

    if (!tasks || tasks.length === 0) {
      return res.status(404).json({ message: "No subtasks found for this user" });
    }

    res.status(200).json({
      success: true,
      count: tasks.length,
      subtasks: tasks.map(t => ({
        task_id: t.task_id,
        projectName: t.projectName,
        projectId: t.projectId,
        ...t.subtask,
      })),
    });
  } catch (error) {
    console.error("Error fetching subtasks by assignedTo:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};