const Bug = require('../../Model/BugModel/Bugs');
const path = require('path');
const fs = require('fs');

// 🔹 Create a new Bug (manual project-wise)
// 🔹 Create a new Bug (without assignment)
exports.createBug = async (req, res) => {
  try {
    const { projectId, projectName, title, description, deadline, priority } = req.body;

    if (!projectId || !projectName || !title) {
      return res.status(400).json({
        message: 'Project ID, Project Name, and Title are required.',
      });
    }

    // Handle multiple file uploads
    let attachments = [];
    if (req.files && req.files.length > 0) {
      attachments = req.files.map(file => `/uploads/bugs/${file.filename}`);
    }

    // Create bug with auto-generated ID
    const newBug = await Bug.createBugWithId({
      projectId,
      projectName,
      title,
      description,
      deadline,
      priority,
      attachments,
      status: 'Open',
    });

    res.status(201).json({
      message: 'Bug created successfully (unassigned).',
      data: newBug,
    });
  } catch (error) {
    console.error('❌ Error creating bug:', error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

// 🔹 Get all bugs (optionally by project)
// exports.getAllBugs = async (req, res) => {
//   try {
//     const { projectId } = req.query;
//     const filter = projectId ? { projectId } : {};
//     const bugs = await Bug.find(filter).sort({ createdAt: -1 });
//     res.status(200).json(bugs);
//   } catch (error) {
//     console.error('❌ Error fetching bugs:', error);
//     res.status(500).json({ message: 'Error fetching bugs', error: error.message });
//   }
// };

// 🔹 Get all bugs for a specific project (using params)
exports.getAllBugs = async (req, res) => {
  try {
    const { projectId } = req.params;

    if (!projectId) {
      return res.status(400).json({ message: 'Project ID is required in the URL.' });
    }

    // Fetch bugs for the given projectId
    const bugs = await Bug.find({ projectId }).sort({ createdAt: -1 });

    if (!bugs || bugs.length === 0) {
      return res.status(404).json({ message: `No bugs found for Project ID: ${projectId}` });
    }

    res.status(200).json({
      message: `Bugs fetched successfully for Project ID: ${projectId}`,
      total: bugs.length,
      data: bugs,
    });
  } catch (error) {
    console.error('❌ Error fetching bugs:', error);
    res.status(500).json({
      message: 'Error fetching bugs',
      error: error.message,
    });
  }
};


// 🔹 Get a single bug by ID
exports.getBugById = async (req, res) => {
  try {
    const bug = await Bug.findById(req.params.id);
    if (!bug) return res.status(404).json({ message: 'Bug not found.' });
    res.status(200).json(bug);
  } catch (error) {
    console.error('❌ Error fetching bug:', error);
    res.status(500).json({ message: 'Error fetching bug', error: error.message });
  }
};

// 🔹 Update a bug
exports.updateBug = async (req, res) => {
  try {
    const { status, resolutionNote } = req.body;
    const updateData = { ...req.body };

    // Handle attachment update
    if (req.file) {
      updateData.attachment = `/uploads/bugs/${req.file.filename}`;
    }

    // If status = Resolved, require resolutionNote
    if (status === 'Resolved' && !resolutionNote) {
      return res.status(400).json({
        message: 'Resolution note is required when marking bug as Resolved.',
      });
    }

    // If status = Resolved, set resolvedAt
    if (status === 'Resolved') {
      updateData.resolvedAt = new Date();
    }

    const updatedBug = await Bug.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
    });

    if (!updatedBug) {
      return res.status(404).json({ message: 'Bug not found.' });
    }

    res.status(200).json({
      message: 'Bug updated successfully.',
      data: updatedBug,
    });
  } catch (error) {
    console.error('❌ Error updating bug:', error);
    res.status(500).json({ message: 'Error updating bug', error: error.message });
  }
};

// 🔹 Delete a bug
exports.deleteBug = async (req, res) => {
  try {
    const bug = await Bug.findByIdAndDelete(req.params.id);
    if (!bug) return res.status(404).json({ message: 'Bug not found.' });

    // Delete the attachment file (if exists)
    if (bug.attachment) {
      const filePath = path.join(__dirname, '..', bug.attachment);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }

    res.status(200).json({ message: 'Bug deleted successfully.' });
  } catch (error) {
    console.error('❌ Error deleting bug:', error);
    res.status(500).json({ message: 'Error deleting bug', error: error.message });
  }
};
