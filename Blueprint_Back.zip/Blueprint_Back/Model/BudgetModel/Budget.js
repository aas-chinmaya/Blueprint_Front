const mongoose = require('mongoose');
const { Schema } = mongoose;

/* -------------------------
   Action History Schema
------------------------- */
const ActionHistorySchema = new Schema({
  action: { type: String, required: true }, // "created", "edited", "deleted", "submitted", etc.
  by: { type: String }, // userId as string
  remarks: { type: String }, // optional comment
  at: { type: Date, default: Date.now },
}, { _id: false });

/* -------------------------
   Status History Schema
------------------------- */
const StatusHistorySchema = new Schema({
  status: { 
    type: String, 
    enum: ["created", "pending", "approved", "deleted", "revision","rejected"], 
    required: true 
  },
  by: { type: String }, // userId as string
  remarks: { type: String },
  at: { type: Date, default: Date.now },
}, { _id: false });

/* -------------------------
   Budget Request + Team Combined Schema
------------------------- */
const budgetRequestSchema = new Schema({
  // Budget Request Info
  projectId: { type: String, required: true },
   requestId: { type: String, unique: true },
  requestType: { type: String, required: true }, // e.g., "Material Request", "Fund Request"
  title: { type: String, required: true },
  description: { type: String },
  requestedAmount: { type: Number, required: true },
  currency: { type: String, default: "INR" },

  // Current Status
  status: {
    type: String,
    enum: ["created", "pending", "approved", "deleted", "rejected", "revision"],
    default: "created",
  },

  // History
  statusHistory: [StatusHistorySchema],
  actionHistory: [ActionHistorySchema],

  // Team Info (from Team model)
  teamId: { type: String },
  teamName: { type: String },
  teamLeadId: { type: String },
  teamLeadName: { type: String },
  teamMembers: [{
    memberId: { type: String },
    role: { type: String },
    memberName: { type: String },
    email: { type: String },
  }],

  // Optional Metadata
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  isDeleted: { type: Boolean, default: false }
});

/* -------------------------
   Export Model
------------------------- */
module.exports = mongoose.model('BudgetRequest', budgetRequestSchema);
