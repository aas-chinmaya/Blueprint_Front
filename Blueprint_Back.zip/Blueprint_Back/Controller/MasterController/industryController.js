 const industry = require('../../Model/Master/Industry');

exports.createIndustry = async (req, res) => {
  try {
    const industryData = req.body;
    const newIndustry = await industry.createServiceWithId(industryData);
    res.status(201).json(newIndustry);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};  
exports.getIndustries = async (req, res) => {
  try {
    const industries = await industry.find();
    res.status(200).json(industries);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getIndustryById = async (req, res) => {
  try {
    const Industry = await industry.findOne({ industryId: req.params.id });
   
    if (!Industry) {
      return res.status(404).json({ error: 'Industry not found' });
    }
 
    res.json(Industry);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};
 
 
exports.updateIndustry = async (req, res) => {
  try {
    const updated = await industry.findOneAndUpdate(
      { industryId: req.params.id },
      req.body,
      { new: true }
    );
    if (!updated) return res.status(404).json({ error: "Industry not found" });
    res.json(updated);
  } catch (error) {
    res.status(400).json({ error: "Failed to update Industry", details: error.message });
  }
};
 
// DELETE
exports.deleteIndustry = async (req, res) => {
  try {
    const deleted = await industry.findOneAndDelete({ industryId: req.params.id });
    if (!deleted) return res.status(404).json({ error: "Industry not found" });
    res.json({ message: "Industry deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete Industry", details: error.message });
  }
};