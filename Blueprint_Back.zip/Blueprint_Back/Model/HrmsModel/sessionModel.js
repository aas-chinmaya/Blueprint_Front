const mongoose = require("mongoose");

module.exports = (connection) => {
  const sessionSchema = new mongoose.Schema(
    {
      email: {
        type: String, 
        required: true,
        index: true, 
      },
      sessionToken: { type: String, required: true },
      deviceInfo: { type: String },
      ipAddress: { type: String },
      expiresAt: { type: Date, required: true },
    },
    { timestamps: true }
  );

  // Index for sessionToken (unique)
  sessionSchema.index({ sessionToken: 1 }, { unique: true });

  // TTL index for automatic expiration
  sessionSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

  return connection.model("Session", sessionSchema, "sessions");
};