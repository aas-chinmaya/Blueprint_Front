const Notification = require('../../Model/NotificationModel/notificationModel');
const mongoose = require('mongoose');

//  Get notifications by recipientId (excluding soft-deleted)
exports.getNotificationsByRecipient = async (req, res) => {
  try {
    const { recipientId } = req.params;
    // console.log(recipientId);
    

    const notifications = await Notification.find({ recipientId, isDeleted: false }).sort({ createdAt: -1 });
//    console.log(notifications);
   
    if (notifications.length === 0) {
      return res.status(200).json({
        success: true,
        message: 'No notifications found for this user',
        data: []
      });
    }

    res.status(200).json({
      success: true,
      message: `${notifications.length} notifications fetched successfully`,
      data: notifications
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching notifications', error: error.message });
  }
};

//  Soft delete single notification
exports.softDeleteNotification = async (req, res) => {
  try {
    const { id } = req.params;
    const notification = await Notification.findByIdAndUpdate(id, { isDeleted: true }, { new: true });

    if (!notification) {
      return res.status(404).json({ success: false, message: 'Notification not found' });
    }

    res.status(200).json({ success: true, message: 'Notification deleted (soft)', data: notification });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting notification', error: error.message });
  }
};

// Soft delete all notifications for a user
exports.softDeleteAllNotifications = async (req, res) => {
  try {
    const { recipientId } = req.params;
    const result = await Notification.updateMany(
      { recipientId, isDeleted: false },
      { $set: { isDeleted: true } }
    );

    res.status(200).json({ success: true, message: `Deleted ${result.modifiedCount} notifications (soft)` });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting all notifications', error: error.message });
  }
};
//  Get all unread notifications
exports.getUnreadNotifications = async (req, res) => {
  try {
    const { recipientId } = req.params;
 
    const notifications = await Notification.find({
      recipientId,
      read: false,
      isDeleted: false,
    }).sort({ createdAt: -1 }); // newest first
 
    res.status(200).json({
      success: true,
      count: notifications.length,
      notifications,
    });
  } catch (error) {
    console.error("Error fetching notifications:", error);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};

// Mark a single notification as read
exports.markAsRead = async (req, res) => {
  try {
    const { id } = req.params;

    // Convert to ObjectId
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: "Invalid notification ID" });
    }

    const notification = await Notification.findByIdAndUpdate(
      new mongoose.Types.ObjectId(id),
      { read: true },
      { new: true }
    );

    if (!notification) {
      return res
        .status(404)
        .json({ success: false, message: "Notification not found" });
    }

    res.status(200).json({
      success: true,
      message: "Notification marked as read",
      notification,
    });
  } catch (error) {
    console.error("Error marking notification as read:", error);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};

// Mark all notifications of a user as read
exports.markAllAsRead = async (req, res) => {
  try {
    const { recipientId } = req.params;
 
    await Notification.updateMany(
      { recipientId, read: false, isDeleted: false },
      { $set: { read: true } }
    );
 
    res.status(200).json({
      success: true,
      message: "All notifications marked as read",
    });
  } catch (error) {
    console.error("Error marking all notifications as read:", error);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};
