const express = require('express');
const router = express.Router();
const notificationController = require('../../Controller/NotificationController/notificationController');
const validateToken=require("../../middlewares/authMiddleware")


//  Get notifications for a user
router.get('/getnotications/:recipientId',validateToken, notificationController.getNotificationsByRecipient);

//  Soft delete one notification
router.delete('/soft/:id', validateToken,notificationController.softDeleteNotification);

// Soft delete all notifications for a user
router.delete('/softdeleteall/:recipientId',validateToken, notificationController.softDeleteAllNotifications);
router.get("/getallnotification/:recipientId", notificationController.getUnreadNotifications);

router.put('/markasread/:id',notificationController.markAsRead)

router.put('/markallasread/:recipientId',notificationController.markAllAsRead)

module.exports = router;
