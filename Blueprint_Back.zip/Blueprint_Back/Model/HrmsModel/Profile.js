const mongoose = require("mongoose");

const ProfileSchema = new mongoose.Schema(
  {
    employeeID: {
      type:String, // Ref to User collection
    //   ref: "User",
      required: true,
      unique:true
    },
    imagePath: {
      type: String, // File path or URL of uploaded image
      required: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
    updatedAt: {
      type: Date,
      default: Date.now,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Profile", ProfileSchema);
