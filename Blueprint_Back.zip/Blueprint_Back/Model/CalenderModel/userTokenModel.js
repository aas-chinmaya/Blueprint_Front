const mongoose = require('mongoose');

const tokenSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  tokens: { type: Object, required: true }, // Contains access_token, refresh_token, etc.
});

module.exports = mongoose.model('UserToken', tokenSchema);
